let window = self;

/*! For license information please see jsencrypt.min.js.LICENSE.txt */
!function(t,e){"object"==typeof exports&&"object"==typeof module?module.exports=e():"function"==typeof define&&define.amd?define([],e):"object"==typeof exports?exports.JSEncrypt=e():t.JSEncrypt=e()}(window,(function(){return(()=>{"use strict";var t=[,(t,e,i)=>{function r(t){return"0123456789abcdefghijklmnopqrstuvwxyz".charAt(t)}function n(t,e){return t&e}function s(t,e){return t|e}function o(t,e){return t^e}function h(t,e){return t&~e}function a(t){if(0==t)return-1;var e=0;return 0==(65535&t)&&(t>>=16,e+=16),0==(255&t)&&(t>>=8,e+=8),0==(15&t)&&(t>>=4,e+=4),0==(3&t)&&(t>>=2,e+=2),0==(1&t)&&++e,e}function u(t){for(var e=0;0!=t;)t&=t-1,++e;return e}i.d(e,{default:()=>nt});var c,f="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";function l(t){var e,i,r="";for(e=0;e+3<=t.length;e+=3)i=parseInt(t.substring(e,e+3),16),r+=f.charAt(i>>6)+f.charAt(63&i);for(e+1==t.length?(i=parseInt(t.substring(e,e+1),16),r+=f.charAt(i<<2)):e+2==t.length&&(i=parseInt(t.substring(e,e+2),16),r+=f.charAt(i>>2)+f.charAt((3&i)<<4));(3&r.length)>0;)r+="=";return r}function p(t){var e,i="",n=0,s=0;for(e=0;e<t.length&&"="!=t.charAt(e);++e){var o=f.indexOf(t.charAt(e));o<0||(0==n?(i+=r(o>>2),s=3&o,n=1):1==n?(i+=r(s<<2|o>>4),s=15&o,n=2):2==n?(i+=r(s),i+=r(o>>2),s=3&o,n=3):(i+=r(s<<2|o>>4),i+=r(15&o),n=0))}return 1==n&&(i+=r(s<<2)),i}var g,d={decode:function(t){var e;if(void 0===g){var i="= \f\n\r\t \u2028\u2029";for(g=Object.create(null),e=0;e<64;++e)g["ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(e)]=e;for(g["-"]=62,g._=63,e=0;e<i.length;++e)g[i.charAt(e)]=-1}var r=[],n=0,s=0;for(e=0;e<t.length;++e){var o=t.charAt(e);if("="==o)break;if(-1!=(o=g[o])){if(void 0===o)throw new Error("Illegal character at offset "+e);n|=o,++s>=4?(r[r.length]=n>>16,r[r.length]=n>>8&255,r[r.length]=255&n,n=0,s=0):n<<=6}}switch(s){case 1:throw new Error("Base64 encoding incomplete: at least 2 bits missing");case 2:r[r.length]=n>>10;break;case 3:r[r.length]=n>>16,r[r.length]=n>>8&255}return r},re:/-----BEGIN [^-]+-----([A-Za-z0-9+\/=\s]+)-----END [^-]+-----|begin-base64[^\n]+\n([A-Za-z0-9+\/=\s]+)====/,unarmor:function(t){var e=d.re.exec(t);if(e)if(e[1])t=e[1];else{if(!e[2])throw new Error("RegExp out of sync");t=e[2]}return d.decode(t)}},v=1e13,m=function(){function t(t){this.buf=[+t||0]}return t.prototype.mulAdd=function(t,e){var i,r,n=this.buf,s=n.length;for(i=0;i<s;++i)(r=n[i]*t+e)<v?e=0:r-=(e=0|r/v)*v,n[i]=r;e>0&&(n[i]=e)},t.prototype.sub=function(t){var e,i,r=this.buf,n=r.length;for(e=0;e<n;++e)(i=r[e]-t)<0?(i+=v,t=1):t=0,r[e]=i;for(;0===r[r.length-1];)r.pop()},t.prototype.toString=function(t){if(10!=(t||10))throw new Error("only base 10 is supported");for(var e=this.buf,i=e[e.length-1].toString(),r=e.length-2;r>=0;--r)i+=(v+e[r]).toString().substring(1);return i},t.prototype.valueOf=function(){for(var t=this.buf,e=0,i=t.length-1;i>=0;--i)e=e*v+t[i];return e},t.prototype.simplify=function(){var t=this.buf;return 1==t.length?t[0]:this},t}(),y=/^(\d\d)(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])([01]\d|2[0-3])(?:([0-5]\d)(?:([0-5]\d)(?:[.,](\d{1,3}))?)?)?(Z|[-+](?:[0]\d|1[0-2])([0-5]\d)?)?$/,b=/^(\d\d\d\d)(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])([01]\d|2[0-3])(?:([0-5]\d)(?:([0-5]\d)(?:[.,](\d{1,3}))?)?)?(Z|[-+](?:[0]\d|1[0-2])([0-5]\d)?)?$/;function T(t,e){return t.length>e&&(t=t.substring(0,e)+"…"),t}var S,E=function(){function t(e,i){this.hexDigits="0123456789ABCDEF",e instanceof t?(this.enc=e.enc,this.pos=e.pos):(this.enc=e,this.pos=i)}return t.prototype.get=function(t){if(void 0===t&&(t=this.pos++),t>=this.enc.length)throw new Error("Requesting byte offset "+t+" on a stream of length "+this.enc.length);return"string"==typeof this.enc?this.enc.charCodeAt(t):this.enc[t]},t.prototype.hexByte=function(t){return this.hexDigits.charAt(t>>4&15)+this.hexDigits.charAt(15&t)},t.prototype.hexDump=function(t,e,i){for(var r="",n=t;n<e;++n)if(r+=this.hexByte(this.get(n)),!0!==i)switch(15&n){case 7:r+="  ";break;case 15:r+="\n";break;default:r+=" "}return r},t.prototype.isASCII=function(t,e){for(var i=t;i<e;++i){var r=this.get(i);if(r<32||r>176)return!1}return!0},t.prototype.parseStringISO=function(t,e){for(var i="",r=t;r<e;++r)i+=String.fromCharCode(this.get(r));return i},t.prototype.parseStringUTF=function(t,e){for(var i="",r=t;r<e;){var n=this.get(r++);i+=n<128?String.fromCharCode(n):n>191&&n<224?String.fromCharCode((31&n)<<6|63&this.get(r++)):String.fromCharCode((15&n)<<12|(63&this.get(r++))<<6|63&this.get(r++))}return i},t.prototype.parseStringBMP=function(t,e){for(var i,r,n="",s=t;s<e;)i=this.get(s++),r=this.get(s++),n+=String.fromCharCode(i<<8|r);return n},t.prototype.parseTime=function(t,e,i){var r=this.parseStringISO(t,e),n=(i?y:b).exec(r);return n?(i&&(n[1]=+n[1],n[1]+=+n[1]<70?2e3:1900),r=n[1]+"-"+n[2]+"-"+n[3]+" "+n[4],n[5]&&(r+=":"+n[5],n[6]&&(r+=":"+n[6],n[7]&&(r+="."+n[7]))),n[8]&&(r+=" UTC","Z"!=n[8]&&(r+=n[8],n[9]&&(r+=":"+n[9]))),r):"Unrecognized time: "+r},t.prototype.parseInteger=function(t,e){for(var i,r=this.get(t),n=r>127,s=n?255:0,o="";r==s&&++t<e;)r=this.get(t);if(0==(i=e-t))return n?-1:0;if(i>4){for(o=r,i<<=3;0==(128&(+o^s));)o=+o<<1,--i;o="("+i+" bit)\n"}n&&(r-=256);for(var h=new m(r),a=t+1;a<e;++a)h.mulAdd(256,this.get(a));return o+h.toString()},t.prototype.parseBitString=function(t,e,i){for(var r=this.get(t),n="("+((e-t-1<<3)-r)+" bit)\n",s="",o=t+1;o<e;++o){for(var h=this.get(o),a=o==e-1?r:0,u=7;u>=a;--u)s+=h>>u&1?"1":"0";if(s.length>i)return n+T(s,i)}return n+s},t.prototype.parseOctetString=function(t,e,i){if(this.isASCII(t,e))return T(this.parseStringISO(t,e),i);var r=e-t,n="("+r+" byte)\n";r>(i/=2)&&(e=t+i);for(var s=t;s<e;++s)n+=this.hexByte(this.get(s));return r>i&&(n+="…"),n},t.prototype.parseOID=function(t,e,i){for(var r="",n=new m,s=0,o=t;o<e;++o){var h=this.get(o);if(n.mulAdd(128,127&h),s+=7,!(128&h)){if(""===r)if((n=n.simplify())instanceof m)n.sub(80),r="2."+n.toString();else{var a=n<80?n<40?0:1:2;r=a+"."+(n-40*a)}else r+="."+n.toString();if(r.length>i)return T(r,i);n=new m,s=0}}return s>0&&(r+=".incomplete"),r},t}(),w=function(){function t(t,e,i,r,n){if(!(r instanceof D))throw new Error("Invalid tag value.");this.stream=t,this.header=e,this.length=i,this.tag=r,this.sub=n}return t.prototype.typeName=function(){switch(this.tag.tagClass){case 0:switch(this.tag.tagNumber){case 0:return"EOC";case 1:return"BOOLEAN";case 2:return"INTEGER";case 3:return"BIT_STRING";case 4:return"OCTET_STRING";case 5:return"NULL";case 6:return"OBJECT_IDENTIFIER";case 7:return"ObjectDescriptor";case 8:return"EXTERNAL";case 9:return"REAL";case 10:return"ENUMERATED";case 11:return"EMBEDDED_PDV";case 12:return"UTF8String";case 16:return"SEQUENCE";case 17:return"SET";case 18:return"NumericString";case 19:return"PrintableString";case 20:return"TeletexString";case 21:return"VideotexString";case 22:return"IA5String";case 23:return"UTCTime";case 24:return"GeneralizedTime";case 25:return"GraphicString";case 26:return"VisibleString";case 27:return"GeneralString";case 28:return"UniversalString";case 30:return"BMPString"}return"Universal_"+this.tag.tagNumber.toString();case 1:return"Application_"+this.tag.tagNumber.toString();case 2:return"["+this.tag.tagNumber.toString()+"]";case 3:return"Private_"+this.tag.tagNumber.toString()}},t.prototype.content=function(t){if(void 0===this.tag)return null;void 0===t&&(t=1/0);var e=this.posContent(),i=Math.abs(this.length);if(!this.tag.isUniversal())return null!==this.sub?"("+this.sub.length+" elem)":this.stream.parseOctetString(e,e+i,t);switch(this.tag.tagNumber){case 1:return 0===this.stream.get(e)?"false":"true";case 2:return this.stream.parseInteger(e,e+i);case 3:return this.sub?"("+this.sub.length+" elem)":this.stream.parseBitString(e,e+i,t);case 4:return this.sub?"("+this.sub.length+" elem)":this.stream.parseOctetString(e,e+i,t);case 6:return this.stream.parseOID(e,e+i,t);case 16:case 17:return null!==this.sub?"("+this.sub.length+" elem)":"(no elem)";case 12:return T(this.stream.parseStringUTF(e,e+i),t);case 18:case 19:case 20:case 21:case 22:case 26:return T(this.stream.parseStringISO(e,e+i),t);case 30:return T(this.stream.parseStringBMP(e,e+i),t);case 23:case 24:return this.stream.parseTime(e,e+i,23==this.tag.tagNumber)}return null},t.prototype.toString=function(){return this.typeName()+"@"+this.stream.pos+"[header:"+this.header+",length:"+this.length+",sub:"+(null===this.sub?"null":this.sub.length)+"]"},t.prototype.toPrettyString=function(t){void 0===t&&(t="");var e=t+this.typeName()+" @"+this.stream.pos;if(this.length>=0&&(e+="+"),e+=this.length,this.tag.tagConstructed?e+=" (constructed)":!this.tag.isUniversal()||3!=this.tag.tagNumber&&4!=this.tag.tagNumber||null===this.sub||(e+=" (encapsulates)"),e+="\n",null!==this.sub){t+="  ";for(var i=0,r=this.sub.length;i<r;++i)e+=this.sub[i].toPrettyString(t)}return e},t.prototype.posStart=function(){return this.stream.pos},t.prototype.posContent=function(){return this.stream.pos+this.header},t.prototype.posEnd=function(){return this.stream.pos+this.header+Math.abs(this.length)},t.prototype.toHexString=function(){return this.stream.hexDump(this.posStart(),this.posEnd(),!0)},t.decodeLength=function(t){var e=t.get(),i=127&e;if(i==e)return i;if(i>6)throw new Error("Length over 48 bits not supported at position "+(t.pos-1));if(0===i)return null;e=0;for(var r=0;r<i;++r)e=256*e+t.get();return e},t.prototype.getHexStringValue=function(){var t=this.toHexString(),e=2*this.header,i=2*this.length;return t.substr(e,i)},t.decode=function(e){var i;i=e instanceof E?e:new E(e,0);var r=new E(i),n=new D(i),s=t.decodeLength(i),o=i.pos,h=o-r.pos,a=null,u=function(){var e=[];if(null!==s){for(var r=o+s;i.pos<r;)e[e.length]=t.decode(i);if(i.pos!=r)throw new Error("Content size is not correct for container starting at offset "+o)}else try{for(;;){var n=t.decode(i);if(n.tag.isEOC())break;e[e.length]=n}s=o-i.pos}catch(t){throw new Error("Exception while decoding undefined length content: "+t)}return e};if(n.tagConstructed)a=u();else if(n.isUniversal()&&(3==n.tagNumber||4==n.tagNumber))try{if(3==n.tagNumber&&0!=i.get())throw new Error("BIT STRINGs with unused bits cannot encapsulate.");a=u();for(var c=0;c<a.length;++c)if(a[c].tag.isEOC())throw new Error("EOC is not supposed to be actual content.")}catch(t){a=null}if(null===a){if(null===s)throw new Error("We can't skip over an invalid tag with undefined length at offset "+o);i.pos=o+Math.abs(s)}return new t(r,h,s,n,a)},t}(),D=function(){function t(t){var e=t.get();if(this.tagClass=e>>6,this.tagConstructed=0!=(32&e),this.tagNumber=31&e,31==this.tagNumber){var i=new m;do{e=t.get(),i.mulAdd(128,127&e)}while(128&e);this.tagNumber=i.simplify()}}return t.prototype.isUniversal=function(){return 0===this.tagClass},t.prototype.isEOC=function(){return 0===this.tagClass&&0===this.tagNumber},t}(),x=[2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97,101,103,107,109,113,127,131,137,139,149,151,157,163,167,173,179,181,191,193,197,199,211,223,227,229,233,239,241,251,257,263,269,271,277,281,283,293,307,311,313,317,331,337,347,349,353,359,367,373,379,383,389,397,401,409,419,421,431,433,439,443,449,457,461,463,467,479,487,491,499,503,509,521,523,541,547,557,563,569,571,577,587,593,599,601,607,613,617,619,631,641,643,647,653,659,661,673,677,683,691,701,709,719,727,733,739,743,751,757,761,769,773,787,797,809,811,821,823,827,829,839,853,857,859,863,877,881,883,887,907,911,919,929,937,941,947,953,967,971,977,983,991,997],R=(1<<26)/x[x.length-1],B=function(){function t(t,e,i){null!=t&&("number"==typeof t?this.fromNumber(t,e,i):null==e&&"string"!=typeof t?this.fromString(t,256):this.fromString(t,e))}return t.prototype.toString=function(t){if(this.s<0)return"-"+this.negate().toString(t);var e;if(16==t)e=4;else if(8==t)e=3;else if(2==t)e=1;else if(32==t)e=5;else{if(4!=t)return this.toRadix(t);e=2}var i,n=(1<<e)-1,s=!1,o="",h=this.t,a=this.DB-h*this.DB%e;if(h-- >0)for(a<this.DB&&(i=this[h]>>a)>0&&(s=!0,o=r(i));h>=0;)a<e?(i=(this[h]&(1<<a)-1)<<e-a,i|=this[--h]>>(a+=this.DB-e)):(i=this[h]>>(a-=e)&n,a<=0&&(a+=this.DB,--h)),i>0&&(s=!0),s&&(o+=r(i));return s?o:"0"},t.prototype.negate=function(){var e=N();return t.ZERO.subTo(this,e),e},t.prototype.abs=function(){return this.s<0?this.negate():this},t.prototype.compareTo=function(t){var e=this.s-t.s;if(0!=e)return e;var i=this.t;if(0!=(e=i-t.t))return this.s<0?-e:e;for(;--i>=0;)if(0!=(e=this[i]-t[i]))return e;return 0},t.prototype.bitLength=function(){return this.t<=0?0:this.DB*(this.t-1)+F(this[this.t-1]^this.s&this.DM)},t.prototype.mod=function(e){var i=N();return this.abs().divRemTo(e,null,i),this.s<0&&i.compareTo(t.ZERO)>0&&e.subTo(i,i),i},t.prototype.modPowInt=function(t,e){var i;return i=t<256||e.isEven()?new A(e):new V(e),this.exp(t,i)},t.prototype.clone=function(){var t=N();return this.copyTo(t),t},t.prototype.intValue=function(){if(this.s<0){if(1==this.t)return this[0]-this.DV;if(0==this.t)return-1}else{if(1==this.t)return this[0];if(0==this.t)return 0}return(this[1]&(1<<32-this.DB)-1)<<this.DB|this[0]},t.prototype.byteValue=function(){return 0==this.t?this.s:this[0]<<24>>24},t.prototype.shortValue=function(){return 0==this.t?this.s:this[0]<<16>>16},t.prototype.signum=function(){return this.s<0?-1:this.t<=0||1==this.t&&this[0]<=0?0:1},t.prototype.toByteArray=function(){var t=this.t,e=[];e[0]=this.s;var i,r=this.DB-t*this.DB%8,n=0;if(t-- >0)for(r<this.DB&&(i=this[t]>>r)!=(this.s&this.DM)>>r&&(e[n++]=i|this.s<<this.DB-r);t>=0;)r<8?(i=(this[t]&(1<<r)-1)<<8-r,i|=this[--t]>>(r+=this.DB-8)):(i=this[t]>>(r-=8)&255,r<=0&&(r+=this.DB,--t)),0!=(128&i)&&(i|=-256),0==n&&(128&this.s)!=(128&i)&&++n,(n>0||i!=this.s)&&(e[n++]=i);return e},t.prototype.equals=function(t){return 0==this.compareTo(t)},t.prototype.min=function(t){return this.compareTo(t)<0?this:t},t.prototype.max=function(t){return this.compareTo(t)>0?this:t},t.prototype.and=function(t){var e=N();return this.bitwiseTo(t,n,e),e},t.prototype.or=function(t){var e=N();return this.bitwiseTo(t,s,e),e},t.prototype.xor=function(t){var e=N();return this.bitwiseTo(t,o,e),e},t.prototype.andNot=function(t){var e=N();return this.bitwiseTo(t,h,e),e},t.prototype.not=function(){for(var t=N(),e=0;e<this.t;++e)t[e]=this.DM&~this[e];return t.t=this.t,t.s=~this.s,t},t.prototype.shiftLeft=function(t){var e=N();return t<0?this.rShiftTo(-t,e):this.lShiftTo(t,e),e},t.prototype.shiftRight=function(t){var e=N();return t<0?this.lShiftTo(-t,e):this.rShiftTo(t,e),e},t.prototype.getLowestSetBit=function(){for(var t=0;t<this.t;++t)if(0!=this[t])return t*this.DB+a(this[t]);return this.s<0?this.t*this.DB:-1},t.prototype.bitCount=function(){for(var t=0,e=this.s&this.DM,i=0;i<this.t;++i)t+=u(this[i]^e);return t},t.prototype.testBit=function(t){var e=Math.floor(t/this.DB);return e>=this.t?0!=this.s:0!=(this[e]&1<<t%this.DB)},t.prototype.setBit=function(t){return this.changeBit(t,s)},t.prototype.clearBit=function(t){return this.changeBit(t,h)},t.prototype.flipBit=function(t){return this.changeBit(t,o)},t.prototype.add=function(t){var e=N();return this.addTo(t,e),e},t.prototype.subtract=function(t){var e=N();return this.subTo(t,e),e},t.prototype.multiply=function(t){var e=N();return this.multiplyTo(t,e),e},t.prototype.divide=function(t){var e=N();return this.divRemTo(t,e,null),e},t.prototype.remainder=function(t){var e=N();return this.divRemTo(t,null,e),e},t.prototype.divideAndRemainder=function(t){var e=N(),i=N();return this.divRemTo(t,e,i),[e,i]},t.prototype.modPow=function(t,e){var i,r,n=t.bitLength(),s=C(1);if(n<=0)return s;i=n<18?1:n<48?3:n<144?4:n<768?5:6,r=n<8?new A(e):e.isEven()?new I(e):new V(e);var o=[],h=3,a=i-1,u=(1<<i)-1;if(o[1]=r.convert(this),i>1){var c=N();for(r.sqrTo(o[1],c);h<=u;)o[h]=N(),r.mulTo(c,o[h-2],o[h]),h+=2}var f,l,p=t.t-1,g=!0,d=N();for(n=F(t[p])-1;p>=0;){for(n>=a?f=t[p]>>n-a&u:(f=(t[p]&(1<<n+1)-1)<<a-n,p>0&&(f|=t[p-1]>>this.DB+n-a)),h=i;0==(1&f);)f>>=1,--h;if((n-=h)<0&&(n+=this.DB,--p),g)o[f].copyTo(s),g=!1;else{for(;h>1;)r.sqrTo(s,d),r.sqrTo(d,s),h-=2;h>0?r.sqrTo(s,d):(l=s,s=d,d=l),r.mulTo(d,o[f],s)}for(;p>=0&&0==(t[p]&1<<n);)r.sqrTo(s,d),l=s,s=d,d=l,--n<0&&(n=this.DB-1,--p)}return r.revert(s)},t.prototype.modInverse=function(e){var i=e.isEven();if(this.isEven()&&i||0==e.signum())return t.ZERO;for(var r=e.clone(),n=this.clone(),s=C(1),o=C(0),h=C(0),a=C(1);0!=r.signum();){for(;r.isEven();)r.rShiftTo(1,r),i?(s.isEven()&&o.isEven()||(s.addTo(this,s),o.subTo(e,o)),s.rShiftTo(1,s)):o.isEven()||o.subTo(e,o),o.rShiftTo(1,o);for(;n.isEven();)n.rShiftTo(1,n),i?(h.isEven()&&a.isEven()||(h.addTo(this,h),a.subTo(e,a)),h.rShiftTo(1,h)):a.isEven()||a.subTo(e,a),a.rShiftTo(1,a);r.compareTo(n)>=0?(r.subTo(n,r),i&&s.subTo(h,s),o.subTo(a,o)):(n.subTo(r,n),i&&h.subTo(s,h),a.subTo(o,a))}return 0!=n.compareTo(t.ONE)?t.ZERO:a.compareTo(e)>=0?a.subtract(e):a.signum()<0?(a.addTo(e,a),a.signum()<0?a.add(e):a):a},t.prototype.pow=function(t){return this.exp(t,new O)},t.prototype.gcd=function(t){var e=this.s<0?this.negate():this.clone(),i=t.s<0?t.negate():t.clone();if(e.compareTo(i)<0){var r=e;e=i,i=r}var n=e.getLowestSetBit(),s=i.getLowestSetBit();if(s<0)return e;for(n<s&&(s=n),s>0&&(e.rShiftTo(s,e),i.rShiftTo(s,i));e.signum()>0;)(n=e.getLowestSetBit())>0&&e.rShiftTo(n,e),(n=i.getLowestSetBit())>0&&i.rShiftTo(n,i),e.compareTo(i)>=0?(e.subTo(i,e),e.rShiftTo(1,e)):(i.subTo(e,i),i.rShiftTo(1,i));return s>0&&i.lShiftTo(s,i),i},t.prototype.isProbablePrime=function(t){var e,i=this.abs();if(1==i.t&&i[0]<=x[x.length-1]){for(e=0;e<x.length;++e)if(i[0]==x[e])return!0;return!1}if(i.isEven())return!1;for(e=1;e<x.length;){for(var r=x[e],n=e+1;n<x.length&&r<R;)r*=x[n++];for(r=i.modInt(r);e<n;)if(r%x[e++]==0)return!1}return i.millerRabin(t)},t.prototype.copyTo=function(t){for(var e=this.t-1;e>=0;--e)t[e]=this[e];t.t=this.t,t.s=this.s},t.prototype.fromInt=function(t){this.t=1,this.s=t<0?-1:0,t>0?this[0]=t:t<-1?this[0]=t+this.DV:this.t=0},t.prototype.fromString=function(e,i){var r;if(16==i)r=4;else if(8==i)r=3;else if(256==i)r=8;else if(2==i)r=1;else if(32==i)r=5;else{if(4!=i)return void this.fromRadix(e,i);r=2}this.t=0,this.s=0;for(var n=e.length,s=!1,o=0;--n>=0;){var h=8==r?255&+e[n]:H(e,n);h<0?"-"==e.charAt(n)&&(s=!0):(s=!1,0==o?this[this.t++]=h:o+r>this.DB?(this[this.t-1]|=(h&(1<<this.DB-o)-1)<<o,this[this.t++]=h>>this.DB-o):this[this.t-1]|=h<<o,(o+=r)>=this.DB&&(o-=this.DB))}8==r&&0!=(128&+e[0])&&(this.s=-1,o>0&&(this[this.t-1]|=(1<<this.DB-o)-1<<o)),this.clamp(),s&&t.ZERO.subTo(this,this)},t.prototype.clamp=function(){for(var t=this.s&this.DM;this.t>0&&this[this.t-1]==t;)--this.t},t.prototype.dlShiftTo=function(t,e){var i;for(i=this.t-1;i>=0;--i)e[i+t]=this[i];for(i=t-1;i>=0;--i)e[i]=0;e.t=this.t+t,e.s=this.s},t.prototype.drShiftTo=function(t,e){for(var i=t;i<this.t;++i)e[i-t]=this[i];e.t=Math.max(this.t-t,0),e.s=this.s},t.prototype.lShiftTo=function(t,e){for(var i=t%this.DB,r=this.DB-i,n=(1<<r)-1,s=Math.floor(t/this.DB),o=this.s<<i&this.DM,h=this.t-1;h>=0;--h)e[h+s+1]=this[h]>>r|o,o=(this[h]&n)<<i;for(h=s-1;h>=0;--h)e[h]=0;e[s]=o,e.t=this.t+s+1,e.s=this.s,e.clamp()},t.prototype.rShiftTo=function(t,e){e.s=this.s;var i=Math.floor(t/this.DB);if(i>=this.t)e.t=0;else{var r=t%this.DB,n=this.DB-r,s=(1<<r)-1;e[0]=this[i]>>r;for(var o=i+1;o<this.t;++o)e[o-i-1]|=(this[o]&s)<<n,e[o-i]=this[o]>>r;r>0&&(e[this.t-i-1]|=(this.s&s)<<n),e.t=this.t-i,e.clamp()}},t.prototype.subTo=function(t,e){for(var i=0,r=0,n=Math.min(t.t,this.t);i<n;)r+=this[i]-t[i],e[i++]=r&this.DM,r>>=this.DB;if(t.t<this.t){for(r-=t.s;i<this.t;)r+=this[i],e[i++]=r&this.DM,r>>=this.DB;r+=this.s}else{for(r+=this.s;i<t.t;)r-=t[i],e[i++]=r&this.DM,r>>=this.DB;r-=t.s}e.s=r<0?-1:0,r<-1?e[i++]=this.DV+r:r>0&&(e[i++]=r),e.t=i,e.clamp()},t.prototype.multiplyTo=function(e,i){var r=this.abs(),n=e.abs(),s=r.t;for(i.t=s+n.t;--s>=0;)i[s]=0;for(s=0;s<n.t;++s)i[s+r.t]=r.am(0,n[s],i,s,0,r.t);i.s=0,i.clamp(),this.s!=e.s&&t.ZERO.subTo(i,i)},t.prototype.squareTo=function(t){for(var e=this.abs(),i=t.t=2*e.t;--i>=0;)t[i]=0;for(i=0;i<e.t-1;++i){var r=e.am(i,e[i],t,2*i,0,1);(t[i+e.t]+=e.am(i+1,2*e[i],t,2*i+1,r,e.t-i-1))>=e.DV&&(t[i+e.t]-=e.DV,t[i+e.t+1]=1)}t.t>0&&(t[t.t-1]+=e.am(i,e[i],t,2*i,0,1)),t.s=0,t.clamp()},t.prototype.divRemTo=function(e,i,r){var n=e.abs();if(!(n.t<=0)){var s=this.abs();if(s.t<n.t)return null!=i&&i.fromInt(0),void(null!=r&&this.copyTo(r));null==r&&(r=N());var o=N(),h=this.s,a=e.s,u=this.DB-F(n[n.t-1]);u>0?(n.lShiftTo(u,o),s.lShiftTo(u,r)):(n.copyTo(o),s.copyTo(r));var c=o.t,f=o[c-1];if(0!=f){var l=f*(1<<this.F1)+(c>1?o[c-2]>>this.F2:0),p=this.FV/l,g=(1<<this.F1)/l,d=1<<this.F2,v=r.t,m=v-c,y=null==i?N():i;for(o.dlShiftTo(m,y),r.compareTo(y)>=0&&(r[r.t++]=1,r.subTo(y,r)),t.ONE.dlShiftTo(c,y),y.subTo(o,o);o.t<c;)o[o.t++]=0;for(;--m>=0;){var b=r[--v]==f?this.DM:Math.floor(r[v]*p+(r[v-1]+d)*g);if((r[v]+=o.am(0,b,r,m,0,c))<b)for(o.dlShiftTo(m,y),r.subTo(y,r);r[v]<--b;)r.subTo(y,r)}null!=i&&(r.drShiftTo(c,i),h!=a&&t.ZERO.subTo(i,i)),r.t=c,r.clamp(),u>0&&r.rShiftTo(u,r),h<0&&t.ZERO.subTo(r,r)}}},t.prototype.invDigit=function(){if(this.t<1)return 0;var t=this[0];if(0==(1&t))return 0;var e=3&t;return(e=(e=(e=(e=e*(2-(15&t)*e)&15)*(2-(255&t)*e)&255)*(2-((65535&t)*e&65535))&65535)*(2-t*e%this.DV)%this.DV)>0?this.DV-e:-e},t.prototype.isEven=function(){return 0==(this.t>0?1&this[0]:this.s)},t.prototype.exp=function(e,i){if(e>4294967295||e<1)return t.ONE;var r=N(),n=N(),s=i.convert(this),o=F(e)-1;for(s.copyTo(r);--o>=0;)if(i.sqrTo(r,n),(e&1<<o)>0)i.mulTo(n,s,r);else{var h=r;r=n,n=h}return i.revert(r)},t.prototype.chunkSize=function(t){return Math.floor(Math.LN2*this.DB/Math.log(t))},t.prototype.toRadix=function(t){if(null==t&&(t=10),0==this.signum()||t<2||t>36)return"0";var e=this.chunkSize(t),i=Math.pow(t,e),r=C(i),n=N(),s=N(),o="";for(this.divRemTo(r,n,s);n.signum()>0;)o=(i+s.intValue()).toString(t).substr(1)+o,n.divRemTo(r,n,s);return s.intValue().toString(t)+o},t.prototype.fromRadix=function(e,i){this.fromInt(0),null==i&&(i=10);for(var r=this.chunkSize(i),n=Math.pow(i,r),s=!1,o=0,h=0,a=0;a<e.length;++a){var u=H(e,a);u<0?"-"==e.charAt(a)&&0==this.signum()&&(s=!0):(h=i*h+u,++o>=r&&(this.dMultiply(n),this.dAddOffset(h,0),o=0,h=0))}o>0&&(this.dMultiply(Math.pow(i,o)),this.dAddOffset(h,0)),s&&t.ZERO.subTo(this,this)},t.prototype.fromNumber=function(e,i,r){if("number"==typeof i)if(e<2)this.fromInt(1);else for(this.fromNumber(e,r),this.testBit(e-1)||this.bitwiseTo(t.ONE.shiftLeft(e-1),s,this),this.isEven()&&this.dAddOffset(1,0);!this.isProbablePrime(i);)this.dAddOffset(2,0),this.bitLength()>e&&this.subTo(t.ONE.shiftLeft(e-1),this);else{var n=[],o=7&e;n.length=1+(e>>3),i.nextBytes(n),o>0?n[0]&=(1<<o)-1:n[0]=0,this.fromString(n,256)}},t.prototype.bitwiseTo=function(t,e,i){var r,n,s=Math.min(t.t,this.t);for(r=0;r<s;++r)i[r]=e(this[r],t[r]);if(t.t<this.t){for(n=t.s&this.DM,r=s;r<this.t;++r)i[r]=e(this[r],n);i.t=this.t}else{for(n=this.s&this.DM,r=s;r<t.t;++r)i[r]=e(n,t[r]);i.t=t.t}i.s=e(this.s,t.s),i.clamp()},t.prototype.changeBit=function(e,i){var r=t.ONE.shiftLeft(e);return this.bitwiseTo(r,i,r),r},t.prototype.addTo=function(t,e){for(var i=0,r=0,n=Math.min(t.t,this.t);i<n;)r+=this[i]+t[i],e[i++]=r&this.DM,r>>=this.DB;if(t.t<this.t){for(r+=t.s;i<this.t;)r+=this[i],e[i++]=r&this.DM,r>>=this.DB;r+=this.s}else{for(r+=this.s;i<t.t;)r+=t[i],e[i++]=r&this.DM,r>>=this.DB;r+=t.s}e.s=r<0?-1:0,r>0?e[i++]=r:r<-1&&(e[i++]=this.DV+r),e.t=i,e.clamp()},t.prototype.dMultiply=function(t){this[this.t]=this.am(0,t-1,this,0,0,this.t),++this.t,this.clamp()},t.prototype.dAddOffset=function(t,e){if(0!=t){for(;this.t<=e;)this[this.t++]=0;for(this[e]+=t;this[e]>=this.DV;)this[e]-=this.DV,++e>=this.t&&(this[this.t++]=0),++this[e]}},t.prototype.multiplyLowerTo=function(t,e,i){var r=Math.min(this.t+t.t,e);for(i.s=0,i.t=r;r>0;)i[--r]=0;for(var n=i.t-this.t;r<n;++r)i[r+this.t]=this.am(0,t[r],i,r,0,this.t);for(n=Math.min(t.t,e);r<n;++r)this.am(0,t[r],i,r,0,e-r);i.clamp()},t.prototype.multiplyUpperTo=function(t,e,i){--e;var r=i.t=this.t+t.t-e;for(i.s=0;--r>=0;)i[r]=0;for(r=Math.max(e-this.t,0);r<t.t;++r)i[this.t+r-e]=this.am(e-r,t[r],i,0,0,this.t+r-e);i.clamp(),i.drShiftTo(1,i)},t.prototype.modInt=function(t){if(t<=0)return 0;var e=this.DV%t,i=this.s<0?t-1:0;if(this.t>0)if(0==e)i=this[0]%t;else for(var r=this.t-1;r>=0;--r)i=(e*i+this[r])%t;return i},t.prototype.millerRabin=function(e){var i=this.subtract(t.ONE),r=i.getLowestSetBit();if(r<=0)return!1;var n=i.shiftRight(r);(e=e+1>>1)>x.length&&(e=x.length);for(var s=N(),o=0;o<e;++o){s.fromInt(x[Math.floor(Math.random()*x.length)]);var h=s.modPow(n,this);if(0!=h.compareTo(t.ONE)&&0!=h.compareTo(i)){for(var a=1;a++<r&&0!=h.compareTo(i);)if(0==(h=h.modPowInt(2,this)).compareTo(t.ONE))return!1;if(0!=h.compareTo(i))return!1}}return!0},t.prototype.square=function(){var t=N();return this.squareTo(t),t},t.prototype.gcda=function(t,e){var i=this.s<0?this.negate():this.clone(),r=t.s<0?t.negate():t.clone();if(i.compareTo(r)<0){var n=i;i=r,r=n}var s=i.getLowestSetBit(),o=r.getLowestSetBit();if(o<0)e(i);else{s<o&&(o=s),o>0&&(i.rShiftTo(o,i),r.rShiftTo(o,r));var h=function(){(s=i.getLowestSetBit())>0&&i.rShiftTo(s,i),(s=r.getLowestSetBit())>0&&r.rShiftTo(s,r),i.compareTo(r)>=0?(i.subTo(r,i),i.rShiftTo(1,i)):(r.subTo(i,r),r.rShiftTo(1,r)),i.signum()>0?setTimeout(h,0):(o>0&&r.lShiftTo(o,r),setTimeout((function(){e(r)}),0))};setTimeout(h,10)}},t.prototype.fromNumberAsync=function(e,i,r,n){if("number"==typeof i)if(e<2)this.fromInt(1);else{this.fromNumber(e,r),this.testBit(e-1)||this.bitwiseTo(t.ONE.shiftLeft(e-1),s,this),this.isEven()&&this.dAddOffset(1,0);var o=this,h=function(){o.dAddOffset(2,0),o.bitLength()>e&&o.subTo(t.ONE.shiftLeft(e-1),o),o.isProbablePrime(i)?setTimeout((function(){n()}),0):setTimeout(h,0)};setTimeout(h,0)}else{var a=[],u=7&e;a.length=1+(e>>3),i.nextBytes(a),u>0?a[0]&=(1<<u)-1:a[0]=0,this.fromString(a,256)}},t}(),O=function(){function t(){}return t.prototype.convert=function(t){return t},t.prototype.revert=function(t){return t},t.prototype.mulTo=function(t,e,i){t.multiplyTo(e,i)},t.prototype.sqrTo=function(t,e){t.squareTo(e)},t}(),A=function(){function t(t){this.m=t}return t.prototype.convert=function(t){return t.s<0||t.compareTo(this.m)>=0?t.mod(this.m):t},t.prototype.revert=function(t){return t},t.prototype.reduce=function(t){t.divRemTo(this.m,null,t)},t.prototype.mulTo=function(t,e,i){t.multiplyTo(e,i),this.reduce(i)},t.prototype.sqrTo=function(t,e){t.squareTo(e),this.reduce(e)},t}(),V=function(){function t(t){this.m=t,this.mp=t.invDigit(),this.mpl=32767&this.mp,this.mph=this.mp>>15,this.um=(1<<t.DB-15)-1,this.mt2=2*t.t}return t.prototype.convert=function(t){var e=N();return t.abs().dlShiftTo(this.m.t,e),e.divRemTo(this.m,null,e),t.s<0&&e.compareTo(B.ZERO)>0&&this.m.subTo(e,e),e},t.prototype.revert=function(t){var e=N();return t.copyTo(e),this.reduce(e),e},t.prototype.reduce=function(t){for(;t.t<=this.mt2;)t[t.t++]=0;for(var e=0;e<this.m.t;++e){var i=32767&t[e],r=i*this.mpl+((i*this.mph+(t[e]>>15)*this.mpl&this.um)<<15)&t.DM;for(t[i=e+this.m.t]+=this.m.am(0,r,t,e,0,this.m.t);t[i]>=t.DV;)t[i]-=t.DV,t[++i]++}t.clamp(),t.drShiftTo(this.m.t,t),t.compareTo(this.m)>=0&&t.subTo(this.m,t)},t.prototype.mulTo=function(t,e,i){t.multiplyTo(e,i),this.reduce(i)},t.prototype.sqrTo=function(t,e){t.squareTo(e),this.reduce(e)},t}(),I=function(){function t(t){this.m=t,this.r2=N(),this.q3=N(),B.ONE.dlShiftTo(2*t.t,this.r2),this.mu=this.r2.divide(t)}return t.prototype.convert=function(t){if(t.s<0||t.t>2*this.m.t)return t.mod(this.m);if(t.compareTo(this.m)<0)return t;var e=N();return t.copyTo(e),this.reduce(e),e},t.prototype.revert=function(t){return t},t.prototype.reduce=function(t){for(t.drShiftTo(this.m.t-1,this.r2),t.t>this.m.t+1&&(t.t=this.m.t+1,t.clamp()),this.mu.multiplyUpperTo(this.r2,this.m.t+1,this.q3),this.m.multiplyLowerTo(this.q3,this.m.t+1,this.r2);t.compareTo(this.r2)<0;)t.dAddOffset(1,this.m.t+1);for(t.subTo(this.r2,t);t.compareTo(this.m)>=0;)t.subTo(this.m,t)},t.prototype.mulTo=function(t,e,i){t.multiplyTo(e,i),this.reduce(i)},t.prototype.sqrTo=function(t,e){t.squareTo(e),this.reduce(e)},t}();function N(){return new B(null)}function P(t,e){return new B(t,e)}var M="undefined"!=typeof navigator;M&&"Microsoft Internet Explorer"==navigator.appName?(B.prototype.am=function(t,e,i,r,n,s){for(var o=32767&e,h=e>>15;--s>=0;){var a=32767&this[t],u=this[t++]>>15,c=h*a+u*o;n=((a=o*a+((32767&c)<<15)+i[r]+(1073741823&n))>>>30)+(c>>>15)+h*u+(n>>>30),i[r++]=1073741823&a}return n},S=30):M&&"Netscape"!=navigator.appName?(B.prototype.am=function(t,e,i,r,n,s){for(;--s>=0;){var o=e*this[t++]+i[r]+n;n=Math.floor(o/67108864),i[r++]=67108863&o}return n},S=26):(B.prototype.am=function(t,e,i,r,n,s){for(var o=16383&e,h=e>>14;--s>=0;){var a=16383&this[t],u=this[t++]>>14,c=h*a+u*o;n=((a=o*a+((16383&c)<<14)+i[r]+n)>>28)+(c>>14)+h*u,i[r++]=268435455&a}return n},S=28),B.prototype.DB=S,B.prototype.DM=(1<<S)-1,B.prototype.DV=1<<S,B.prototype.FV=Math.pow(2,52),B.prototype.F1=52-S,B.prototype.F2=2*S-52;var j,q,L=[];for(j="0".charCodeAt(0),q=0;q<=9;++q)L[j++]=q;for(j="a".charCodeAt(0),q=10;q<36;++q)L[j++]=q;for(j="A".charCodeAt(0),q=10;q<36;++q)L[j++]=q;function H(t,e){var i=L[t.charCodeAt(e)];return null==i?-1:i}function C(t){var e=N();return e.fromInt(t),e}function F(t){var e,i=1;return 0!=(e=t>>>16)&&(t=e,i+=16),0!=(e=t>>8)&&(t=e,i+=8),0!=(e=t>>4)&&(t=e,i+=4),0!=(e=t>>2)&&(t=e,i+=2),0!=(e=t>>1)&&(t=e,i+=1),i}B.ZERO=C(0),B.ONE=C(1);var U,K,k=function(){function t(){this.i=0,this.j=0,this.S=[]}return t.prototype.init=function(t){var e,i,r;for(e=0;e<256;++e)this.S[e]=e;for(i=0,e=0;e<256;++e)i=i+this.S[e]+t[e%t.length]&255,r=this.S[e],this.S[e]=this.S[i],this.S[i]=r;this.i=0,this.j=0},t.prototype.next=function(){var t;return this.i=this.i+1&255,this.j=this.j+this.S[this.i]&255,t=this.S[this.i],this.S[this.i]=this.S[this.j],this.S[this.j]=t,this.S[t+this.S[this.i]&255]},t}(),_=null;if(null==_){_=[],K=0;var z=void 0;if(window.crypto&&window.crypto.getRandomValues){var Z=new Uint32Array(256);for(window.crypto.getRandomValues(Z),z=0;z<Z.length;++z)_[K++]=255&Z[z]}var G=0,$=function(t){if((G=G||0)>=256||K>=256)window.removeEventListener?window.removeEventListener("mousemove",$,!1):window.detachEvent&&window.detachEvent("onmousemove",$);else try{var e=t.x+t.y;_[K++]=255&e,G+=1}catch(t){}};window.addEventListener?window.addEventListener("mousemove",$,!1):window.attachEvent&&window.attachEvent("onmousemove",$)}function Y(){if(null==U){for(U=new k;K<256;){var t=Math.floor(65536*Math.random());_[K++]=255&t}for(U.init(_),K=0;K<_.length;++K)_[K]=0;K=0}return U.next()}var J=function(){function t(){}return t.prototype.nextBytes=function(t){for(var e=0;e<t.length;++e)t[e]=Y()},t}(),X=function(){function t(){this.n=null,this.e=0,this.d=null,this.p=null,this.q=null,this.dmp1=null,this.dmq1=null,this.coeff=null}return t.prototype.doPublic=function(t){return t.modPowInt(this.e,this.n)},t.prototype.doPrivate=function(t){if(null==this.p||null==this.q)return t.modPow(this.d,this.n);for(var e=t.mod(this.p).modPow(this.dmp1,this.p),i=t.mod(this.q).modPow(this.dmq1,this.q);e.compareTo(i)<0;)e=e.add(this.p);return e.subtract(i).multiply(this.coeff).mod(this.p).multiply(this.q).add(i)},t.prototype.setPublic=function(t,e){null!=t&&null!=e&&t.length>0&&e.length>0?(this.n=P(t,16),this.e=parseInt(e,16)):console.error("Invalid RSA public key")},t.prototype.encrypt=function(t){var e=this.n.bitLength()+7>>3,i=function(t,e){if(e<t.length+11)return console.error("Message too long for RSA"),null;for(var i=[],r=t.length-1;r>=0&&e>0;){var n=t.charCodeAt(r--);n<128?i[--e]=n:n>127&&n<2048?(i[--e]=63&n|128,i[--e]=n>>6|192):(i[--e]=63&n|128,i[--e]=n>>6&63|128,i[--e]=n>>12|224)}i[--e]=0;for(var s=new J,o=[];e>2;){for(o[0]=0;0==o[0];)s.nextBytes(o);i[--e]=o[0]}return i[--e]=2,i[--e]=0,new B(i)}(t,e);if(null==i)return null;var r=this.doPublic(i);if(null==r)return null;for(var n=r.toString(16),s=n.length,o=0;o<2*e-s;o++)n="0"+n;return n},t.prototype.setPrivate=function(t,e,i){null!=t&&null!=e&&t.length>0&&e.length>0?(this.n=P(t,16),this.e=parseInt(e,16),this.d=P(i,16)):console.error("Invalid RSA private key")},t.prototype.setPrivateEx=function(t,e,i,r,n,s,o,h){null!=t&&null!=e&&t.length>0&&e.length>0?(this.n=P(t,16),this.e=parseInt(e,16),this.d=P(i,16),this.p=P(r,16),this.q=P(n,16),this.dmp1=P(s,16),this.dmq1=P(o,16),this.coeff=P(h,16)):console.error("Invalid RSA private key")},t.prototype.generate=function(t,e){var i=new J,r=t>>1;this.e=parseInt(e,16);for(var n=new B(e,16);;){for(;this.p=new B(t-r,1,i),0!=this.p.subtract(B.ONE).gcd(n).compareTo(B.ONE)||!this.p.isProbablePrime(10););for(;this.q=new B(r,1,i),0!=this.q.subtract(B.ONE).gcd(n).compareTo(B.ONE)||!this.q.isProbablePrime(10););if(this.p.compareTo(this.q)<=0){var s=this.p;this.p=this.q,this.q=s}var o=this.p.subtract(B.ONE),h=this.q.subtract(B.ONE),a=o.multiply(h);if(0==a.gcd(n).compareTo(B.ONE)){this.n=this.p.multiply(this.q),this.d=n.modInverse(a),this.dmp1=this.d.mod(o),this.dmq1=this.d.mod(h),this.coeff=this.q.modInverse(this.p);break}}},t.prototype.decrypt=function(t){var e=P(t,16),i=this.doPrivate(e);return null==i?null:function(t,e){for(var i=t.toByteArray(),r=0;r<i.length&&0==i[r];)++r;if(i.length-r!=e-1||2!=i[r])return null;for(++r;0!=i[r];)if(++r>=i.length)return null;for(var n="";++r<i.length;){var s=255&i[r];s<128?n+=String.fromCharCode(s):s>191&&s<224?(n+=String.fromCharCode((31&s)<<6|63&i[r+1]),++r):(n+=String.fromCharCode((15&s)<<12|(63&i[r+1])<<6|63&i[r+2]),r+=2)}return n}(i,this.n.bitLength()+7>>3)},t.prototype.generateAsync=function(t,e,i){var r=new J,n=t>>1;this.e=parseInt(e,16);var s=new B(e,16),o=this,h=function(){var e=function(){if(o.p.compareTo(o.q)<=0){var t=o.p;o.p=o.q,o.q=t}var e=o.p.subtract(B.ONE),r=o.q.subtract(B.ONE),n=e.multiply(r);0==n.gcd(s).compareTo(B.ONE)?(o.n=o.p.multiply(o.q),o.d=s.modInverse(n),o.dmp1=o.d.mod(e),o.dmq1=o.d.mod(r),o.coeff=o.q.modInverse(o.p),setTimeout((function(){i()}),0)):setTimeout(h,0)},a=function(){o.q=N(),o.q.fromNumberAsync(n,1,r,(function(){o.q.subtract(B.ONE).gcda(s,(function(t){0==t.compareTo(B.ONE)&&o.q.isProbablePrime(10)?setTimeout(e,0):setTimeout(a,0)}))}))},u=function(){o.p=N(),o.p.fromNumberAsync(t-n,1,r,(function(){o.p.subtract(B.ONE).gcda(s,(function(t){0==t.compareTo(B.ONE)&&o.p.isProbablePrime(10)?setTimeout(a,0):setTimeout(u,0)}))}))};setTimeout(u,0)};setTimeout(h,0)},t.prototype.sign=function(t,e,i){var r=function(t,e){if(e<t.length+22)return console.error("Message too long for RSA"),null;for(var i=e-t.length-6,r="",n=0;n<i;n+=2)r+="ff";return P("0001"+r+"00"+t,16)}((Q[i]||"")+e(t).toString(),this.n.bitLength()/4);if(null==r)return null;var n=this.doPrivate(r);if(null==n)return null;var s=n.toString(16);return 0==(1&s.length)?s:"0"+s},t.prototype.verify=function(t,e,i){var r=P(e,16),n=this.doPublic(r);return null==n?null:function(t){for(var e in Q)if(Q.hasOwnProperty(e)){var i=Q[e],r=i.length;if(t.substr(0,r)==i)return t.substr(r)}return t}(n.toString(16).replace(/^1f+00/,""))==i(t).toString()},t}(),Q={md2:"3020300c06082a864886f70d020205000410",md5:"3020300c06082a864886f70d020505000410",sha1:"3021300906052b0e03021a05000414",sha224:"302d300d06096086480165030402040500041c",sha256:"3031300d060960864801650304020105000420",sha384:"3041300d060960864801650304020205000430",sha512:"3051300d060960864801650304020305000440",ripemd160:"3021300906052b2403020105000414"},W={};W.lang={extend:function(t,e,i){if(!e||!t)throw new Error("YAHOO.lang.extend failed, please check that all dependencies are included.");var r=function(){};if(r.prototype=e.prototype,t.prototype=new r,t.prototype.constructor=t,t.superclass=e.prototype,e.prototype.constructor==Object.prototype.constructor&&(e.prototype.constructor=e),i){var n;for(n in i)t.prototype[n]=i[n];var s=function(){},o=["toString","valueOf"];try{/MSIE/.test(navigator.userAgent)&&(s=function(t,e){for(n=0;n<o.length;n+=1){var i=o[n],r=e[i];"function"==typeof r&&r!=Object.prototype[i]&&(t[i]=r)}})}catch(t){}s(t.prototype,i)}}};var tt={};void 0!==tt.asn1&&tt.asn1||(tt.asn1={}),tt.asn1.ASN1Util=new function(){this.integerToByteHex=function(t){var e=t.toString(16);return e.length%2==1&&(e="0"+e),e},this.bigIntToMinTwosComplementsHex=function(t){var e=t.toString(16);if("-"!=e.substr(0,1))e.length%2==1?e="0"+e:e.match(/^[0-7]/)||(e="00"+e);else{var i=e.substr(1).length;i%2==1?i+=1:e.match(/^[0-7]/)||(i+=2);for(var r="",n=0;n<i;n++)r+="f";e=new B(r,16).xor(t).add(B.ONE).toString(16).replace(/^-/,"")}return e},this.getPEMStringFromHex=function(t,e){return hextopem(t,e)},this.newObject=function(t){var e=tt.asn1,i=e.DERBoolean,r=e.DERInteger,n=e.DERBitString,s=e.DEROctetString,o=e.DERNull,h=e.DERObjectIdentifier,a=e.DEREnumerated,u=e.DERUTF8String,c=e.DERNumericString,f=e.DERPrintableString,l=e.DERTeletexString,p=e.DERIA5String,g=e.DERUTCTime,d=e.DERGeneralizedTime,v=e.DERSequence,m=e.DERSet,y=e.DERTaggedObject,b=e.ASN1Util.newObject,T=Object.keys(t);if(1!=T.length)throw"key of param shall be only one.";var S=T[0];if(-1==":bool:int:bitstr:octstr:null:oid:enum:utf8str:numstr:prnstr:telstr:ia5str:utctime:gentime:seq:set:tag:".indexOf(":"+S+":"))throw"undefined key: "+S;if("bool"==S)return new i(t[S]);if("int"==S)return new r(t[S]);if("bitstr"==S)return new n(t[S]);if("octstr"==S)return new s(t[S]);if("null"==S)return new o(t[S]);if("oid"==S)return new h(t[S]);if("enum"==S)return new a(t[S]);if("utf8str"==S)return new u(t[S]);if("numstr"==S)return new c(t[S]);if("prnstr"==S)return new f(t[S]);if("telstr"==S)return new l(t[S]);if("ia5str"==S)return new p(t[S]);if("utctime"==S)return new g(t[S]);if("gentime"==S)return new d(t[S]);if("seq"==S){for(var E=t[S],w=[],D=0;D<E.length;D++){var x=b(E[D]);w.push(x)}return new v({array:w})}if("set"==S){for(E=t[S],w=[],D=0;D<E.length;D++)x=b(E[D]),w.push(x);return new m({array:w})}if("tag"==S){var R=t[S];if("[object Array]"===Object.prototype.toString.call(R)&&3==R.length){var B=b(R[2]);return new y({tag:R[0],explicit:R[1],obj:B})}var O={};if(void 0!==R.explicit&&(O.explicit=R.explicit),void 0!==R.tag&&(O.tag=R.tag),void 0===R.obj)throw"obj shall be specified for 'tag'.";return O.obj=b(R.obj),new y(O)}},this.jsonToASN1HEX=function(t){return this.newObject(t).getEncodedHex()}},tt.asn1.ASN1Util.oidHexToInt=function(t){for(var e="",i=parseInt(t.substr(0,2),16),r=(e=Math.floor(i/40)+"."+i%40,""),n=2;n<t.length;n+=2){var s=("00000000"+parseInt(t.substr(n,2),16).toString(2)).slice(-8);r+=s.substr(1,7),"0"==s.substr(0,1)&&(e=e+"."+new B(r,2).toString(10),r="")}return e},tt.asn1.ASN1Util.oidIntToHex=function(t){var e=function(t){var e=t.toString(16);return 1==e.length&&(e="0"+e),e},i=function(t){var i="",r=new B(t,10).toString(2),n=7-r.length%7;7==n&&(n=0);for(var s="",o=0;o<n;o++)s+="0";for(r=s+r,o=0;o<r.length-1;o+=7){var h=r.substr(o,7);o!=r.length-7&&(h="1"+h),i+=e(parseInt(h,2))}return i};if(!t.match(/^[0-9.]+$/))throw"malformed oid string: "+t;var r="",n=t.split("."),s=40*parseInt(n[0])+parseInt(n[1]);r+=e(s),n.splice(0,2);for(var o=0;o<n.length;o++)r+=i(n[o]);return r},tt.asn1.ASN1Object=function(){this.getLengthHexFromValue=function(){if(void 0===this.hV||null==this.hV)throw"this.hV is null or undefined.";if(this.hV.length%2==1)throw"value hex must be even length: n="+"".length+",v="+this.hV;var t=this.hV.length/2,e=t.toString(16);if(e.length%2==1&&(e="0"+e),t<128)return e;var i=e.length/2;if(i>15)throw"ASN.1 length too long to represent by 8x: n = "+t.toString(16);return(128+i).toString(16)+e},this.getEncodedHex=function(){return(null==this.hTLV||this.isModified)&&(this.hV=this.getFreshValueHex(),this.hL=this.getLengthHexFromValue(),this.hTLV=this.hT+this.hL+this.hV,this.isModified=!1),this.hTLV},this.getValueHex=function(){return this.getEncodedHex(),this.hV},this.getFreshValueHex=function(){return""}},tt.asn1.DERAbstractString=function(t){tt.asn1.DERAbstractString.superclass.constructor.call(this),this.getString=function(){return this.s},this.setString=function(t){this.hTLV=null,this.isModified=!0,this.s=t,this.hV=stohex(this.s)},this.setStringHex=function(t){this.hTLV=null,this.isModified=!0,this.s=null,this.hV=t},this.getFreshValueHex=function(){return this.hV},void 0!==t&&("string"==typeof t?this.setString(t):void 0!==t.str?this.setString(t.str):void 0!==t.hex&&this.setStringHex(t.hex))},W.lang.extend(tt.asn1.DERAbstractString,tt.asn1.ASN1Object),tt.asn1.DERAbstractTime=function(t){tt.asn1.DERAbstractTime.superclass.constructor.call(this),this.localDateToUTC=function(t){return utc=t.getTime()+6e4*t.getTimezoneOffset(),new Date(utc)},this.formatDate=function(t,e,i){var r=this.zeroPadding,n=this.localDateToUTC(t),s=String(n.getFullYear());"utc"==e&&(s=s.substr(2,2));var o=s+r(String(n.getMonth()+1),2)+r(String(n.getDate()),2)+r(String(n.getHours()),2)+r(String(n.getMinutes()),2)+r(String(n.getSeconds()),2);if(!0===i){var h=n.getMilliseconds();if(0!=h){var a=r(String(h),3);o=o+"."+(a=a.replace(/[0]+$/,""))}}return o+"Z"},this.zeroPadding=function(t,e){return t.length>=e?t:new Array(e-t.length+1).join("0")+t},this.getString=function(){return this.s},this.setString=function(t){this.hTLV=null,this.isModified=!0,this.s=t,this.hV=stohex(t)},this.setByDateValue=function(t,e,i,r,n,s){var o=new Date(Date.UTC(t,e-1,i,r,n,s,0));this.setByDate(o)},this.getFreshValueHex=function(){return this.hV}},W.lang.extend(tt.asn1.DERAbstractTime,tt.asn1.ASN1Object),tt.asn1.DERAbstractStructured=function(t){tt.asn1.DERAbstractString.superclass.constructor.call(this),this.setByASN1ObjectArray=function(t){this.hTLV=null,this.isModified=!0,this.asn1Array=t},this.appendASN1Object=function(t){this.hTLV=null,this.isModified=!0,this.asn1Array.push(t)},this.asn1Array=new Array,void 0!==t&&void 0!==t.array&&(this.asn1Array=t.array)},W.lang.extend(tt.asn1.DERAbstractStructured,tt.asn1.ASN1Object),tt.asn1.DERBoolean=function(){tt.asn1.DERBoolean.superclass.constructor.call(this),this.hT="01",this.hTLV="0101ff"},W.lang.extend(tt.asn1.DERBoolean,tt.asn1.ASN1Object),tt.asn1.DERInteger=function(t){tt.asn1.DERInteger.superclass.constructor.call(this),this.hT="02",this.setByBigInteger=function(t){this.hTLV=null,this.isModified=!0,this.hV=tt.asn1.ASN1Util.bigIntToMinTwosComplementsHex(t)},this.setByInteger=function(t){var e=new B(String(t),10);this.setByBigInteger(e)},this.setValueHex=function(t){this.hV=t},this.getFreshValueHex=function(){return this.hV},void 0!==t&&(void 0!==t.bigint?this.setByBigInteger(t.bigint):void 0!==t.int?this.setByInteger(t.int):"number"==typeof t?this.setByInteger(t):void 0!==t.hex&&this.setValueHex(t.hex))},W.lang.extend(tt.asn1.DERInteger,tt.asn1.ASN1Object),tt.asn1.DERBitString=function(t){if(void 0!==t&&void 0!==t.obj){var e=tt.asn1.ASN1Util.newObject(t.obj);t.hex="00"+e.getEncodedHex()}tt.asn1.DERBitString.superclass.constructor.call(this),this.hT="03",this.setHexValueIncludingUnusedBits=function(t){this.hTLV=null,this.isModified=!0,this.hV=t},this.setUnusedBitsAndHexValue=function(t,e){if(t<0||7<t)throw"unused bits shall be from 0 to 7: u = "+t;var i="0"+t;this.hTLV=null,this.isModified=!0,this.hV=i+e},this.setByBinaryString=function(t){var e=8-(t=t.replace(/0+$/,"")).length%8;8==e&&(e=0);for(var i=0;i<=e;i++)t+="0";var r="";for(i=0;i<t.length-1;i+=8){var n=t.substr(i,8),s=parseInt(n,2).toString(16);1==s.length&&(s="0"+s),r+=s}this.hTLV=null,this.isModified=!0,this.hV="0"+e+r},this.setByBooleanArray=function(t){for(var e="",i=0;i<t.length;i++)1==t[i]?e+="1":e+="0";this.setByBinaryString(e)},this.newFalseArray=function(t){for(var e=new Array(t),i=0;i<t;i++)e[i]=!1;return e},this.getFreshValueHex=function(){return this.hV},void 0!==t&&("string"==typeof t&&t.toLowerCase().match(/^[0-9a-f]+$/)?this.setHexValueIncludingUnusedBits(t):void 0!==t.hex?this.setHexValueIncludingUnusedBits(t.hex):void 0!==t.bin?this.setByBinaryString(t.bin):void 0!==t.array&&this.setByBooleanArray(t.array))},W.lang.extend(tt.asn1.DERBitString,tt.asn1.ASN1Object),tt.asn1.DEROctetString=function(t){if(void 0!==t&&void 0!==t.obj){var e=tt.asn1.ASN1Util.newObject(t.obj);t.hex=e.getEncodedHex()}tt.asn1.DEROctetString.superclass.constructor.call(this,t),this.hT="04"},W.lang.extend(tt.asn1.DEROctetString,tt.asn1.DERAbstractString),tt.asn1.DERNull=function(){tt.asn1.DERNull.superclass.constructor.call(this),this.hT="05",this.hTLV="0500"},W.lang.extend(tt.asn1.DERNull,tt.asn1.ASN1Object),tt.asn1.DERObjectIdentifier=function(t){var e=function(t){var e=t.toString(16);return 1==e.length&&(e="0"+e),e},i=function(t){var i="",r=new B(t,10).toString(2),n=7-r.length%7;7==n&&(n=0);for(var s="",o=0;o<n;o++)s+="0";for(r=s+r,o=0;o<r.length-1;o+=7){var h=r.substr(o,7);o!=r.length-7&&(h="1"+h),i+=e(parseInt(h,2))}return i};tt.asn1.DERObjectIdentifier.superclass.constructor.call(this),this.hT="06",this.setValueHex=function(t){this.hTLV=null,this.isModified=!0,this.s=null,this.hV=t},this.setValueOidString=function(t){if(!t.match(/^[0-9.]+$/))throw"malformed oid string: "+t;var r="",n=t.split("."),s=40*parseInt(n[0])+parseInt(n[1]);r+=e(s),n.splice(0,2);for(var o=0;o<n.length;o++)r+=i(n[o]);this.hTLV=null,this.isModified=!0,this.s=null,this.hV=r},this.setValueName=function(t){var e=tt.asn1.x509.OID.name2oid(t);if(""===e)throw"DERObjectIdentifier oidName undefined: "+t;this.setValueOidString(e)},this.getFreshValueHex=function(){return this.hV},void 0!==t&&("string"==typeof t?t.match(/^[0-2].[0-9.]+$/)?this.setValueOidString(t):this.setValueName(t):void 0!==t.oid?this.setValueOidString(t.oid):void 0!==t.hex?this.setValueHex(t.hex):void 0!==t.name&&this.setValueName(t.name))},W.lang.extend(tt.asn1.DERObjectIdentifier,tt.asn1.ASN1Object),tt.asn1.DEREnumerated=function(t){tt.asn1.DEREnumerated.superclass.constructor.call(this),this.hT="0a",this.setByBigInteger=function(t){this.hTLV=null,this.isModified=!0,this.hV=tt.asn1.ASN1Util.bigIntToMinTwosComplementsHex(t)},this.setByInteger=function(t){var e=new B(String(t),10);this.setByBigInteger(e)},this.setValueHex=function(t){this.hV=t},this.getFreshValueHex=function(){return this.hV},void 0!==t&&(void 0!==t.int?this.setByInteger(t.int):"number"==typeof t?this.setByInteger(t):void 0!==t.hex&&this.setValueHex(t.hex))},W.lang.extend(tt.asn1.DEREnumerated,tt.asn1.ASN1Object),tt.asn1.DERUTF8String=function(t){tt.asn1.DERUTF8String.superclass.constructor.call(this,t),this.hT="0c"},W.lang.extend(tt.asn1.DERUTF8String,tt.asn1.DERAbstractString),tt.asn1.DERNumericString=function(t){tt.asn1.DERNumericString.superclass.constructor.call(this,t),this.hT="12"},W.lang.extend(tt.asn1.DERNumericString,tt.asn1.DERAbstractString),tt.asn1.DERPrintableString=function(t){tt.asn1.DERPrintableString.superclass.constructor.call(this,t),this.hT="13"},W.lang.extend(tt.asn1.DERPrintableString,tt.asn1.DERAbstractString),tt.asn1.DERTeletexString=function(t){tt.asn1.DERTeletexString.superclass.constructor.call(this,t),this.hT="14"},W.lang.extend(tt.asn1.DERTeletexString,tt.asn1.DERAbstractString),tt.asn1.DERIA5String=function(t){tt.asn1.DERIA5String.superclass.constructor.call(this,t),this.hT="16"},W.lang.extend(tt.asn1.DERIA5String,tt.asn1.DERAbstractString),tt.asn1.DERUTCTime=function(t){tt.asn1.DERUTCTime.superclass.constructor.call(this,t),this.hT="17",this.setByDate=function(t){this.hTLV=null,this.isModified=!0,this.date=t,this.s=this.formatDate(this.date,"utc"),this.hV=stohex(this.s)},this.getFreshValueHex=function(){return void 0===this.date&&void 0===this.s&&(this.date=new Date,this.s=this.formatDate(this.date,"utc"),this.hV=stohex(this.s)),this.hV},void 0!==t&&(void 0!==t.str?this.setString(t.str):"string"==typeof t&&t.match(/^[0-9]{12}Z$/)?this.setString(t):void 0!==t.hex?this.setStringHex(t.hex):void 0!==t.date&&this.setByDate(t.date))},W.lang.extend(tt.asn1.DERUTCTime,tt.asn1.DERAbstractTime),tt.asn1.DERGeneralizedTime=function(t){tt.asn1.DERGeneralizedTime.superclass.constructor.call(this,t),this.hT="18",this.withMillis=!1,this.setByDate=function(t){this.hTLV=null,this.isModified=!0,this.date=t,this.s=this.formatDate(this.date,"gen",this.withMillis),this.hV=stohex(this.s)},this.getFreshValueHex=function(){return void 0===this.date&&void 0===this.s&&(this.date=new Date,this.s=this.formatDate(this.date,"gen",this.withMillis),this.hV=stohex(this.s)),this.hV},void 0!==t&&(void 0!==t.str?this.setString(t.str):"string"==typeof t&&t.match(/^[0-9]{14}Z$/)?this.setString(t):void 0!==t.hex?this.setStringHex(t.hex):void 0!==t.date&&this.setByDate(t.date),!0===t.millis&&(this.withMillis=!0))},W.lang.extend(tt.asn1.DERGeneralizedTime,tt.asn1.DERAbstractTime),tt.asn1.DERSequence=function(t){tt.asn1.DERSequence.superclass.constructor.call(this,t),this.hT="30",this.getFreshValueHex=function(){for(var t="",e=0;e<this.asn1Array.length;e++)t+=this.asn1Array[e].getEncodedHex();return this.hV=t,this.hV}},W.lang.extend(tt.asn1.DERSequence,tt.asn1.DERAbstractStructured),tt.asn1.DERSet=function(t){tt.asn1.DERSet.superclass.constructor.call(this,t),this.hT="31",this.sortFlag=!0,this.getFreshValueHex=function(){for(var t=new Array,e=0;e<this.asn1Array.length;e++){var i=this.asn1Array[e];t.push(i.getEncodedHex())}return 1==this.sortFlag&&t.sort(),this.hV=t.join(""),this.hV},void 0!==t&&void 0!==t.sortflag&&0==t.sortflag&&(this.sortFlag=!1)},W.lang.extend(tt.asn1.DERSet,tt.asn1.DERAbstractStructured),tt.asn1.DERTaggedObject=function(t){tt.asn1.DERTaggedObject.superclass.constructor.call(this),this.hT="a0",this.hV="",this.isExplicit=!0,this.asn1Object=null,this.setASN1Object=function(t,e,i){this.hT=e,this.isExplicit=t,this.asn1Object=i,this.isExplicit?(this.hV=this.asn1Object.getEncodedHex(),this.hTLV=null,this.isModified=!0):(this.hV=null,this.hTLV=i.getEncodedHex(),this.hTLV=this.hTLV.replace(/^../,e),this.isModified=!1)},this.getFreshValueHex=function(){return this.hV},void 0!==t&&(void 0!==t.tag&&(this.hT=t.tag),void 0!==t.explicit&&(this.isExplicit=t.explicit),void 0!==t.obj&&(this.asn1Object=t.obj,this.setASN1Object(this.isExplicit,this.hT,this.asn1Object)))},W.lang.extend(tt.asn1.DERTaggedObject,tt.asn1.ASN1Object);var et,it=(et=function(t,e){return(et=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(t[i]=e[i])})(t,e)},function(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Class extends value "+String(e)+" is not a constructor or null");function i(){this.constructor=t}et(t,e),t.prototype=null===e?Object.create(e):(i.prototype=e.prototype,new i)}),rt=function(t){function e(i){var r=t.call(this)||this;return i&&("string"==typeof i?r.parseKey(i):(e.hasPrivateKeyProperty(i)||e.hasPublicKeyProperty(i))&&r.parsePropertiesFrom(i)),r}return it(e,t),e.prototype.parseKey=function(t){try{var e=0,i=0,r=/^\s*(?:[0-9A-Fa-f][0-9A-Fa-f]\s*)+$/.test(t)?function(t){var e;if(void 0===c){var i="0123456789ABCDEF",r=" \f\n\r\t \u2028\u2029";for(c={},e=0;e<16;++e)c[i.charAt(e)]=e;for(i=i.toLowerCase(),e=10;e<16;++e)c[i.charAt(e)]=e;for(e=0;e<r.length;++e)c[r.charAt(e)]=-1}var n=[],s=0,o=0;for(e=0;e<t.length;++e){var h=t.charAt(e);if("="==h)break;if(-1!=(h=c[h])){if(void 0===h)throw new Error("Illegal character at offset "+e);s|=h,++o>=2?(n[n.length]=s,s=0,o=0):s<<=4}}if(o)throw new Error("Hex encoding incomplete: 4 bits missing");return n}(t):d.unarmor(t),n=w.decode(r);if(3===n.sub.length&&(n=n.sub[2].sub[0]),9===n.sub.length){e=n.sub[1].getHexStringValue(),this.n=P(e,16),i=n.sub[2].getHexStringValue(),this.e=parseInt(i,16);var s=n.sub[3].getHexStringValue();this.d=P(s,16);var o=n.sub[4].getHexStringValue();this.p=P(o,16);var h=n.sub[5].getHexStringValue();this.q=P(h,16);var a=n.sub[6].getHexStringValue();this.dmp1=P(a,16);var u=n.sub[7].getHexStringValue();this.dmq1=P(u,16);var f=n.sub[8].getHexStringValue();this.coeff=P(f,16)}else{if(2!==n.sub.length)return!1;var l=n.sub[1].sub[0];e=l.sub[0].getHexStringValue(),this.n=P(e,16),i=l.sub[1].getHexStringValue(),this.e=parseInt(i,16)}return!0}catch(t){return!1}},e.prototype.getPrivateBaseKey=function(){var t={array:[new tt.asn1.DERInteger({int:0}),new tt.asn1.DERInteger({bigint:this.n}),new tt.asn1.DERInteger({int:this.e}),new tt.asn1.DERInteger({bigint:this.d}),new tt.asn1.DERInteger({bigint:this.p}),new tt.asn1.DERInteger({bigint:this.q}),new tt.asn1.DERInteger({bigint:this.dmp1}),new tt.asn1.DERInteger({bigint:this.dmq1}),new tt.asn1.DERInteger({bigint:this.coeff})]};return new tt.asn1.DERSequence(t).getEncodedHex()},e.prototype.getPrivateBaseKeyB64=function(){return l(this.getPrivateBaseKey())},e.prototype.getPublicBaseKey=function(){var t=new tt.asn1.DERSequence({array:[new tt.asn1.DERObjectIdentifier({oid:"1.2.840.113549.1.1.1"}),new tt.asn1.DERNull]}),e=new tt.asn1.DERSequence({array:[new tt.asn1.DERInteger({bigint:this.n}),new tt.asn1.DERInteger({int:this.e})]}),i=new tt.asn1.DERBitString({hex:"00"+e.getEncodedHex()});return new tt.asn1.DERSequence({array:[t,i]}).getEncodedHex()},e.prototype.getPublicBaseKeyB64=function(){return l(this.getPublicBaseKey())},e.wordwrap=function(t,e){if(!t)return t;var i="(.{1,"+(e=e||64)+"})( +|$\n?)|(.{1,"+e+"})";return t.match(RegExp(i,"g")).join("\n")},e.prototype.getPrivateKey=function(){var t="-----BEGIN RSA PRIVATE KEY-----\n";return(t+=e.wordwrap(this.getPrivateBaseKeyB64())+"\n")+"-----END RSA PRIVATE KEY-----"},e.prototype.getPublicKey=function(){var t="-----BEGIN PUBLIC KEY-----\n";return(t+=e.wordwrap(this.getPublicBaseKeyB64())+"\n")+"-----END PUBLIC KEY-----"},e.hasPublicKeyProperty=function(t){return(t=t||{}).hasOwnProperty("n")&&t.hasOwnProperty("e")},e.hasPrivateKeyProperty=function(t){return(t=t||{}).hasOwnProperty("n")&&t.hasOwnProperty("e")&&t.hasOwnProperty("d")&&t.hasOwnProperty("p")&&t.hasOwnProperty("q")&&t.hasOwnProperty("dmp1")&&t.hasOwnProperty("dmq1")&&t.hasOwnProperty("coeff")},e.prototype.parsePropertiesFrom=function(t){this.n=t.n,this.e=t.e,t.hasOwnProperty("d")&&(this.d=t.d,this.p=t.p,this.q=t.q,this.dmp1=t.dmp1,this.dmq1=t.dmq1,this.coeff=t.coeff)},e}(X);const nt=function(){function t(t){void 0===t&&(t={}),t=t||{},this.default_key_size=t.default_key_size?parseInt(t.default_key_size,10):1024,this.default_public_exponent=t.default_public_exponent||"010001",this.log=t.log||!1,this.key=null}return t.prototype.setKey=function(t){this.log&&this.key&&console.warn("A key was already set, overriding existing."),this.key=new rt(t)},t.prototype.setPrivateKey=function(t){this.setKey(t)},t.prototype.setPublicKey=function(t){this.setKey(t)},t.prototype.decrypt=function(t){try{return this.getKey().decrypt(p(t))}catch(t){return!1}},t.prototype.encrypt=function(t){try{return l(this.getKey().encrypt(t))}catch(t){return!1}},t.prototype.sign=function(t,e,i){try{return l(this.getKey().sign(t,e,i))}catch(t){return!1}},t.prototype.verify=function(t,e,i){try{return this.getKey().verify(t,p(e),i)}catch(t){return!1}},t.prototype.getKey=function(t){if(!this.key){if(this.key=new rt,t&&"[object Function]"==={}.toString.call(t))return void this.key.generateAsync(this.default_key_size,this.default_public_exponent,t);this.key.generate(this.default_key_size,this.default_public_exponent)}return this.key},t.prototype.getPrivateKey=function(){return this.getKey().getPrivateKey()},t.prototype.getPrivateKeyB64=function(){return this.getKey().getPrivateBaseKeyB64()},t.prototype.getPublicKey=function(){return this.getKey().getPublicKey()},t.prototype.getPublicKeyB64=function(){return this.getKey().getPublicBaseKeyB64()},t.version="3.2.1",t}()}],e={d:(t,i)=>{for(var r in i)e.o(i,r)&&!e.o(t,r)&&Object.defineProperty(t,r,{enumerable:!0,get:i[r]})},o:(t,e)=>Object.prototype.hasOwnProperty.call(t,e)},i={};return t[1](0,i,e),i.default})()}));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
	typeof define === 'function' && define.amd ? define(['exports'], factory) :
	(global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global.acorn = {}));
})(this, (function (exports) { 'use strict';

	// Reserved word lists for various dialects of the language

	var reservedWords = {
		3: "abstract boolean byte char class double enum export extends final float goto implements import int interface long native package private protected public short static super synchronized throws transient volatile",
		5: "class enum extends super const export import",
		6: "enum",
		strict: "implements interface let package private protected public static yield",
		strictBind: "eval arguments"
	};

	// And the keywords

	var ecma5AndLessKeywords = "break case catch continue debugger default do else finally for function if return switch throw try var while with null true false instanceof typeof void delete new in this";

	var keywords$1 = {
		5: ecma5AndLessKeywords,
		"5module": ecma5AndLessKeywords + " export import",
		6: ecma5AndLessKeywords + " const class extends export import super"
	};

	var keywordRelationalOperator = /^in(stanceof)?$/;

	// ## Character categories

	// Big ugly regular expressions that match characters in the
	// whitespace, identifier, and identifier-start categories. These
	// are only applied when a character is found to actually have a
	// code point above 128.
	// Generated by `bin/generate-identifier-regex.js`.
	var nonASCIIidentifierStartChars = "\xaa\xb5\xba\xc0-\xd6\xd8-\xf6\xf8-\u02c1\u02c6-\u02d1\u02e0-\u02e4\u02ec\u02ee\u0370-\u0374\u0376\u0377\u037a-\u037d\u037f\u0386\u0388-\u038a\u038c\u038e-\u03a1\u03a3-\u03f5\u03f7-\u0481\u048a-\u052f\u0531-\u0556\u0559\u0560-\u0588\u05d0-\u05ea\u05ef-\u05f2\u0620-\u064a\u066e\u066f\u0671-\u06d3\u06d5\u06e5\u06e6\u06ee\u06ef\u06fa-\u06fc\u06ff\u0710\u0712-\u072f\u074d-\u07a5\u07b1\u07ca-\u07ea\u07f4\u07f5\u07fa\u0800-\u0815\u081a\u0824\u0828\u0840-\u0858\u0860-\u086a\u0870-\u0887\u0889-\u088e\u08a0-\u08c9\u0904-\u0939\u093d\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098c\u098f\u0990\u0993-\u09a8\u09aa-\u09b0\u09b2\u09b6-\u09b9\u09bd\u09ce\u09dc\u09dd\u09df-\u09e1\u09f0\u09f1\u09fc\u0a05-\u0a0a\u0a0f\u0a10\u0a13-\u0a28\u0a2a-\u0a30\u0a32\u0a33\u0a35\u0a36\u0a38\u0a39\u0a59-\u0a5c\u0a5e\u0a72-\u0a74\u0a85-\u0a8d\u0a8f-\u0a91\u0a93-\u0aa8\u0aaa-\u0ab0\u0ab2\u0ab3\u0ab5-\u0ab9\u0abd\u0ad0\u0ae0\u0ae1\u0af9\u0b05-\u0b0c\u0b0f\u0b10\u0b13-\u0b28\u0b2a-\u0b30\u0b32\u0b33\u0b35-\u0b39\u0b3d\u0b5c\u0b5d\u0b5f-\u0b61\u0b71\u0b83\u0b85-\u0b8a\u0b8e-\u0b90\u0b92-\u0b95\u0b99\u0b9a\u0b9c\u0b9e\u0b9f\u0ba3\u0ba4\u0ba8-\u0baa\u0bae-\u0bb9\u0bd0\u0c05-\u0c0c\u0c0e-\u0c10\u0c12-\u0c28\u0c2a-\u0c39\u0c3d\u0c58-\u0c5a\u0c5d\u0c60\u0c61\u0c80\u0c85-\u0c8c\u0c8e-\u0c90\u0c92-\u0ca8\u0caa-\u0cb3\u0cb5-\u0cb9\u0cbd\u0cdd\u0cde\u0ce0\u0ce1\u0cf1\u0cf2\u0d04-\u0d0c\u0d0e-\u0d10\u0d12-\u0d3a\u0d3d\u0d4e\u0d54-\u0d56\u0d5f-\u0d61\u0d7a-\u0d7f\u0d85-\u0d96\u0d9a-\u0db1\u0db3-\u0dbb\u0dbd\u0dc0-\u0dc6\u0e01-\u0e30\u0e32\u0e33\u0e40-\u0e46\u0e81\u0e82\u0e84\u0e86-\u0e8a\u0e8c-\u0ea3\u0ea5\u0ea7-\u0eb0\u0eb2\u0eb3\u0ebd\u0ec0-\u0ec4\u0ec6\u0edc-\u0edf\u0f00\u0f40-\u0f47\u0f49-\u0f6c\u0f88-\u0f8c\u1000-\u102a\u103f\u1050-\u1055\u105a-\u105d\u1061\u1065\u1066\u106e-\u1070\u1075-\u1081\u108e\u10a0-\u10c5\u10c7\u10cd\u10d0-\u10fa\u10fc-\u1248\u124a-\u124d\u1250-\u1256\u1258\u125a-\u125d\u1260-\u1288\u128a-\u128d\u1290-\u12b0\u12b2-\u12b5\u12b8-\u12be\u12c0\u12c2-\u12c5\u12c8-\u12d6\u12d8-\u1310\u1312-\u1315\u1318-\u135a\u1380-\u138f\u13a0-\u13f5\u13f8-\u13fd\u1401-\u166c\u166f-\u167f\u1681-\u169a\u16a0-\u16ea\u16ee-\u16f8\u1700-\u1711\u171f-\u1731\u1740-\u1751\u1760-\u176c\u176e-\u1770\u1780-\u17b3\u17d7\u17dc\u1820-\u1878\u1880-\u18a8\u18aa\u18b0-\u18f5\u1900-\u191e\u1950-\u196d\u1970-\u1974\u1980-\u19ab\u19b0-\u19c9\u1a00-\u1a16\u1a20-\u1a54\u1aa7\u1b05-\u1b33\u1b45-\u1b4c\u1b83-\u1ba0\u1bae\u1baf\u1bba-\u1be5\u1c00-\u1c23\u1c4d-\u1c4f\u1c5a-\u1c7d\u1c80-\u1c88\u1c90-\u1cba\u1cbd-\u1cbf\u1ce9-\u1cec\u1cee-\u1cf3\u1cf5\u1cf6\u1cfa\u1d00-\u1dbf\u1e00-\u1f15\u1f18-\u1f1d\u1f20-\u1f45\u1f48-\u1f4d\u1f50-\u1f57\u1f59\u1f5b\u1f5d\u1f5f-\u1f7d\u1f80-\u1fb4\u1fb6-\u1fbc\u1fbe\u1fc2-\u1fc4\u1fc6-\u1fcc\u1fd0-\u1fd3\u1fd6-\u1fdb\u1fe0-\u1fec\u1ff2-\u1ff4\u1ff6-\u1ffc\u2071\u207f\u2090-\u209c\u2102\u2107\u210a-\u2113\u2115\u2118-\u211d\u2124\u2126\u2128\u212a-\u2139\u213c-\u213f\u2145-\u2149\u214e\u2160-\u2188\u2c00-\u2ce4\u2ceb-\u2cee\u2cf2\u2cf3\u2d00-\u2d25\u2d27\u2d2d\u2d30-\u2d67\u2d6f\u2d80-\u2d96\u2da0-\u2da6\u2da8-\u2dae\u2db0-\u2db6\u2db8-\u2dbe\u2dc0-\u2dc6\u2dc8-\u2dce\u2dd0-\u2dd6\u2dd8-\u2dde\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303c\u3041-\u3096\u309b-\u309f\u30a1-\u30fa\u30fc-\u30ff\u3105-\u312f\u3131-\u318e\u31a0-\u31bf\u31f0-\u31ff\u3400-\u4dbf\u4e00-\ua48c\ua4d0-\ua4fd\ua500-\ua60c\ua610-\ua61f\ua62a\ua62b\ua640-\ua66e\ua67f-\ua69d\ua6a0-\ua6ef\ua717-\ua71f\ua722-\ua788\ua78b-\ua7ca\ua7d0\ua7d1\ua7d3\ua7d5-\ua7d9\ua7f2-\ua801\ua803-\ua805\ua807-\ua80a\ua80c-\ua822\ua840-\ua873\ua882-\ua8b3\ua8f2-\ua8f7\ua8fb\ua8fd\ua8fe\ua90a-\ua925\ua930-\ua946\ua960-\ua97c\ua984-\ua9b2\ua9cf\ua9e0-\ua9e4\ua9e6-\ua9ef\ua9fa-\ua9fe\uaa00-\uaa28\uaa40-\uaa42\uaa44-\uaa4b\uaa60-\uaa76\uaa7a\uaa7e-\uaaaf\uaab1\uaab5\uaab6\uaab9-\uaabd\uaac0\uaac2\uaadb-\uaadd\uaae0-\uaaea\uaaf2-\uaaf4\uab01-\uab06\uab09-\uab0e\uab11-\uab16\uab20-\uab26\uab28-\uab2e\uab30-\uab5a\uab5c-\uab69\uab70-\uabe2\uac00-\ud7a3\ud7b0-\ud7c6\ud7cb-\ud7fb\uf900-\ufa6d\ufa70-\ufad9\ufb00-\ufb06\ufb13-\ufb17\ufb1d\ufb1f-\ufb28\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40\ufb41\ufb43\ufb44\ufb46-\ufbb1\ufbd3-\ufd3d\ufd50-\ufd8f\ufd92-\ufdc7\ufdf0-\ufdfb\ufe70-\ufe74\ufe76-\ufefc\uff21-\uff3a\uff41-\uff5a\uff66-\uffbe\uffc2-\uffc7\uffca-\uffcf\uffd2-\uffd7\uffda-\uffdc";
	var nonASCIIidentifierChars = "\u200c\u200d\xb7\u0300-\u036f\u0387\u0483-\u0487\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7\u0610-\u061a\u064b-\u0669\u0670\u06d6-\u06dc\u06df-\u06e4\u06e7\u06e8\u06ea-\u06ed\u06f0-\u06f9\u0711\u0730-\u074a\u07a6-\u07b0\u07c0-\u07c9\u07eb-\u07f3\u07fd\u0816-\u0819\u081b-\u0823\u0825-\u0827\u0829-\u082d\u0859-\u085b\u0898-\u089f\u08ca-\u08e1\u08e3-\u0903\u093a-\u093c\u093e-\u094f\u0951-\u0957\u0962\u0963\u0966-\u096f\u0981-\u0983\u09bc\u09be-\u09c4\u09c7\u09c8\u09cb-\u09cd\u09d7\u09e2\u09e3\u09e6-\u09ef\u09fe\u0a01-\u0a03\u0a3c\u0a3e-\u0a42\u0a47\u0a48\u0a4b-\u0a4d\u0a51\u0a66-\u0a71\u0a75\u0a81-\u0a83\u0abc\u0abe-\u0ac5\u0ac7-\u0ac9\u0acb-\u0acd\u0ae2\u0ae3\u0ae6-\u0aef\u0afa-\u0aff\u0b01-\u0b03\u0b3c\u0b3e-\u0b44\u0b47\u0b48\u0b4b-\u0b4d\u0b55-\u0b57\u0b62\u0b63\u0b66-\u0b6f\u0b82\u0bbe-\u0bc2\u0bc6-\u0bc8\u0bca-\u0bcd\u0bd7\u0be6-\u0bef\u0c00-\u0c04\u0c3c\u0c3e-\u0c44\u0c46-\u0c48\u0c4a-\u0c4d\u0c55\u0c56\u0c62\u0c63\u0c66-\u0c6f\u0c81-\u0c83\u0cbc\u0cbe-\u0cc4\u0cc6-\u0cc8\u0cca-\u0ccd\u0cd5\u0cd6\u0ce2\u0ce3\u0ce6-\u0cef\u0d00-\u0d03\u0d3b\u0d3c\u0d3e-\u0d44\u0d46-\u0d48\u0d4a-\u0d4d\u0d57\u0d62\u0d63\u0d66-\u0d6f\u0d81-\u0d83\u0dca\u0dcf-\u0dd4\u0dd6\u0dd8-\u0ddf\u0de6-\u0def\u0df2\u0df3\u0e31\u0e34-\u0e3a\u0e47-\u0e4e\u0e50-\u0e59\u0eb1\u0eb4-\u0ebc\u0ec8-\u0ecd\u0ed0-\u0ed9\u0f18\u0f19\u0f20-\u0f29\u0f35\u0f37\u0f39\u0f3e\u0f3f\u0f71-\u0f84\u0f86\u0f87\u0f8d-\u0f97\u0f99-\u0fbc\u0fc6\u102b-\u103e\u1040-\u1049\u1056-\u1059\u105e-\u1060\u1062-\u1064\u1067-\u106d\u1071-\u1074\u1082-\u108d\u108f-\u109d\u135d-\u135f\u1369-\u1371\u1712-\u1715\u1732-\u1734\u1752\u1753\u1772\u1773\u17b4-\u17d3\u17dd\u17e0-\u17e9\u180b-\u180d\u180f-\u1819\u18a9\u1920-\u192b\u1930-\u193b\u1946-\u194f\u19d0-\u19da\u1a17-\u1a1b\u1a55-\u1a5e\u1a60-\u1a7c\u1a7f-\u1a89\u1a90-\u1a99\u1ab0-\u1abd\u1abf-\u1ace\u1b00-\u1b04\u1b34-\u1b44\u1b50-\u1b59\u1b6b-\u1b73\u1b80-\u1b82\u1ba1-\u1bad\u1bb0-\u1bb9\u1be6-\u1bf3\u1c24-\u1c37\u1c40-\u1c49\u1c50-\u1c59\u1cd0-\u1cd2\u1cd4-\u1ce8\u1ced\u1cf4\u1cf7-\u1cf9\u1dc0-\u1dff\u203f\u2040\u2054\u20d0-\u20dc\u20e1\u20e5-\u20f0\u2cef-\u2cf1\u2d7f\u2de0-\u2dff\u302a-\u302f\u3099\u309a\ua620-\ua629\ua66f\ua674-\ua67d\ua69e\ua69f\ua6f0\ua6f1\ua802\ua806\ua80b\ua823-\ua827\ua82c\ua880\ua881\ua8b4-\ua8c5\ua8d0-\ua8d9\ua8e0-\ua8f1\ua8ff-\ua909\ua926-\ua92d\ua947-\ua953\ua980-\ua983\ua9b3-\ua9c0\ua9d0-\ua9d9\ua9e5\ua9f0-\ua9f9\uaa29-\uaa36\uaa43\uaa4c\uaa4d\uaa50-\uaa59\uaa7b-\uaa7d\uaab0\uaab2-\uaab4\uaab7\uaab8\uaabe\uaabf\uaac1\uaaeb-\uaaef\uaaf5\uaaf6\uabe3-\uabea\uabec\uabed\uabf0-\uabf9\ufb1e\ufe00-\ufe0f\ufe20-\ufe2f\ufe33\ufe34\ufe4d-\ufe4f\uff10-\uff19\uff3f";

	var nonASCIIidentifierStart = new RegExp("[" + nonASCIIidentifierStartChars + "]");
	var nonASCIIidentifier = new RegExp("[" + nonASCIIidentifierStartChars + nonASCIIidentifierChars + "]");

	nonASCIIidentifierStartChars = nonASCIIidentifierChars = null;

	// These are a run-length and offset encoded representation of the
	// >0xffff code points that are a valid part of identifiers. The
	// offset starts at 0x10000, and each pair of numbers represents an
	// offset to the next range, and then a size of the range. They were
	// generated by bin/generate-identifier-regex.js

	// eslint-disable-next-line comma-spacing
	var astralIdentifierStartCodes = [0,11,2,25,2,18,2,1,2,14,3,13,35,122,70,52,268,28,4,48,48,31,14,29,6,37,11,29,3,35,5,7,2,4,43,157,19,35,5,35,5,39,9,51,13,10,2,14,2,6,2,1,2,10,2,14,2,6,2,1,68,310,10,21,11,7,25,5,2,41,2,8,70,5,3,0,2,43,2,1,4,0,3,22,11,22,10,30,66,18,2,1,11,21,11,25,71,55,7,1,65,0,16,3,2,2,2,28,43,28,4,28,36,7,2,27,28,53,11,21,11,18,14,17,111,72,56,50,14,50,14,35,349,41,7,1,79,28,11,0,9,21,43,17,47,20,28,22,13,52,58,1,3,0,14,44,33,24,27,35,30,0,3,0,9,34,4,0,13,47,15,3,22,0,2,0,36,17,2,24,85,6,2,0,2,3,2,14,2,9,8,46,39,7,3,1,3,21,2,6,2,1,2,4,4,0,19,0,13,4,159,52,19,3,21,2,31,47,21,1,2,0,185,46,42,3,37,47,21,0,60,42,14,0,72,26,38,6,186,43,117,63,32,7,3,0,3,7,2,1,2,23,16,0,2,0,95,7,3,38,17,0,2,0,29,0,11,39,8,0,22,0,12,45,20,0,19,72,264,8,2,36,18,0,50,29,113,6,2,1,2,37,22,0,26,5,2,1,2,31,15,0,328,18,190,0,80,921,103,110,18,195,2637,96,16,1070,4050,582,8634,568,8,30,18,78,18,29,19,47,17,3,32,20,6,18,689,63,129,74,6,0,67,12,65,1,2,0,29,6135,9,1237,43,8,8936,3,2,6,2,1,2,290,46,2,18,3,9,395,2309,106,6,12,4,8,8,9,5991,84,2,70,2,1,3,0,3,1,3,3,2,11,2,0,2,6,2,64,2,3,3,7,2,6,2,27,2,3,2,4,2,0,4,6,2,339,3,24,2,24,2,30,2,24,2,30,2,24,2,30,2,24,2,30,2,24,2,7,1845,30,482,44,11,6,17,0,322,29,19,43,1269,6,2,3,2,1,2,14,2,196,60,67,8,0,1205,3,2,26,2,1,2,0,3,0,2,9,2,3,2,0,2,0,7,0,5,0,2,0,2,0,2,2,2,1,2,0,3,0,2,0,2,0,2,0,2,0,2,1,2,0,3,3,2,6,2,3,2,3,2,0,2,9,2,16,6,2,2,4,2,16,4421,42719,33,4152,8,221,3,5761,15,7472,3104,541,1507,4938];

	// eslint-disable-next-line comma-spacing
	var astralIdentifierCodes = [509,0,227,0,150,4,294,9,1368,2,2,1,6,3,41,2,5,0,166,1,574,3,9,9,370,1,154,10,50,3,123,2,54,14,32,10,3,1,11,3,46,10,8,0,46,9,7,2,37,13,2,9,6,1,45,0,13,2,49,13,9,3,2,11,83,11,7,0,161,11,6,9,7,3,56,1,2,6,3,1,3,2,10,0,11,1,3,6,4,4,193,17,10,9,5,0,82,19,13,9,214,6,3,8,28,1,83,16,16,9,82,12,9,9,84,14,5,9,243,14,166,9,71,5,2,1,3,3,2,0,2,1,13,9,120,6,3,6,4,0,29,9,41,6,2,3,9,0,10,10,47,15,406,7,2,7,17,9,57,21,2,13,123,5,4,0,2,1,2,6,2,0,9,9,49,4,2,1,2,4,9,9,330,3,19306,9,87,9,39,4,60,6,26,9,1014,0,2,54,8,3,82,0,12,1,19628,1,4706,45,3,22,543,4,4,5,9,7,3,6,31,3,149,2,1418,49,513,54,5,49,9,0,15,0,23,4,2,14,1361,6,2,16,3,6,2,1,2,4,262,6,10,9,357,0,62,13,1495,6,110,6,6,9,4759,9,787719,239];

	// This has a complexity linear to the value of the code. The
	// assumption is that looking up astral identifier characters is
	// rare.
	function isInAstralSet(code, set) {
		var pos = 0x10000;
		for (var i = 0; i < set.length; i += 2) {
			pos += set[i];
			if (pos > code) { return false }
			pos += set[i + 1];
			if (pos >= code) { return true }
		}
	}

	// Test whether a given character code starts an identifier.

	function isIdentifierStart(code, astral) {
		if (code < 65) { return code === 36 }
		if (code < 91) { return true }
		if (code < 97) { return code === 95 }
		if (code < 123) { return true }
		if (code <= 0xffff) { return code >= 0xaa && nonASCIIidentifierStart.test(String.fromCharCode(code)) }
		if (astral === false) { return false }
		return isInAstralSet(code, astralIdentifierStartCodes)
	}

	// Test whether a given character is part of an identifier.

	function isIdentifierChar(code, astral) {
		if (code < 48) { return code === 36 }
		if (code < 58) { return true }
		if (code < 65) { return false }
		if (code < 91) { return true }
		if (code < 97) { return code === 95 }
		if (code < 123) { return true }
		if (code <= 0xffff) { return code >= 0xaa && nonASCIIidentifier.test(String.fromCharCode(code)) }
		if (astral === false) { return false }
		return isInAstralSet(code, astralIdentifierStartCodes) || isInAstralSet(code, astralIdentifierCodes)
	}

	// ## Token types

	// The assignment of fine-grained, information-carrying type objects
	// allows the tokenizer to store the information it has about a
	// token in a way that is very cheap for the parser to look up.

	// All token type variables start with an underscore, to make them
	// easy to recognize.

	// The `beforeExpr` property is used to disambiguate between regular
	// expressions and divisions. It is set on all token types that can
	// be followed by an expression (thus, a slash after them would be a
	// regular expression).
	//
	// The `startsExpr` property is used to check if the token ends a
	// `yield` expression. It is set on all token types that either can
	// directly start an expression (like a quotation mark) or can
	// continue an expression (like the body of a string).
	//
	// `isLoop` marks a keyword as starting a loop, which is important
	// to know when parsing a label, in order to allow or disallow
	// continue jumps to that label.

	var TokenType = function TokenType(label, conf) {
		if ( conf === void 0 ) conf = {};

		this.label = label;
		this.keyword = conf.keyword;
		this.beforeExpr = !!conf.beforeExpr;
		this.startsExpr = !!conf.startsExpr;
		this.isLoop = !!conf.isLoop;
		this.isAssign = !!conf.isAssign;
		this.prefix = !!conf.prefix;
		this.postfix = !!conf.postfix;
		this.binop = conf.binop || null;
		this.updateContext = null;
	};

	function binop(name, prec) {
		return new TokenType(name, {beforeExpr: true, binop: prec})
	}
	var beforeExpr = {beforeExpr: true}, startsExpr = {startsExpr: true};

	// Map keyword names to token types.

	var keywords = {};

	// Succinct definitions of keyword token types
	function kw(name, options) {
		if ( options === void 0 ) options = {};

		options.keyword = name;
		return keywords[name] = new TokenType(name, options)
	}

	var types$1 = {
		num: new TokenType("num", startsExpr),
		regexp: new TokenType("regexp", startsExpr),
		string: new TokenType("string", startsExpr),
		name: new TokenType("name", startsExpr),
		privateId: new TokenType("privateId", startsExpr),
		eof: new TokenType("eof"),

		// Punctuation token types.
		bracketL: new TokenType("[", {beforeExpr: true, startsExpr: true}),
		bracketR: new TokenType("]"),
		braceL: new TokenType("{", {beforeExpr: true, startsExpr: true}),
		braceR: new TokenType("}"),
		parenL: new TokenType("(", {beforeExpr: true, startsExpr: true}),
		parenR: new TokenType(")"),
		comma: new TokenType(",", beforeExpr),
		semi: new TokenType(";", beforeExpr),
		colon: new TokenType(":", beforeExpr),
		dot: new TokenType("."),
		question: new TokenType("?", beforeExpr),
		questionDot: new TokenType("?."),
		arrow: new TokenType("=>", beforeExpr),
		template: new TokenType("template"),
		invalidTemplate: new TokenType("invalidTemplate"),
		ellipsis: new TokenType("...", beforeExpr),
		backQuote: new TokenType("`", startsExpr),
		dollarBraceL: new TokenType("${", {beforeExpr: true, startsExpr: true}),

		// Operators. These carry several kinds of properties to help the
		// parser use them properly (the presence of these properties is
		// what categorizes them as operators).
		//
		// `binop`, when present, specifies that this operator is a binary
		// operator, and will refer to its precedence.
		//
		// `prefix` and `postfix` mark the operator as a prefix or postfix
		// unary operator.
		//
		// `isAssign` marks all of `=`, `+=`, `-=` etcetera, which act as
		// binary operators with a very low precedence, that should result
		// in AssignmentExpression nodes.

		eq: new TokenType("=", {beforeExpr: true, isAssign: true}),
		assign: new TokenType("_=", {beforeExpr: true, isAssign: true}),
		incDec: new TokenType("++/--", {prefix: true, postfix: true, startsExpr: true}),
		prefix: new TokenType("!/~", {beforeExpr: true, prefix: true, startsExpr: true}),
		logicalOR: binop("||", 1),
		logicalAND: binop("&&", 2),
		bitwiseOR: binop("|", 3),
		bitwiseXOR: binop("^", 4),
		bitwiseAND: binop("&", 5),
		equality: binop("==/!=/===/!==", 6),
		relational: binop("</>/<=/>=", 7),
		bitShift: binop("<</>>/>>>", 8),
		plusMin: new TokenType("+/-", {beforeExpr: true, binop: 9, prefix: true, startsExpr: true}),
		modulo: binop("%", 10),
		star: binop("*", 10),
		slash: binop("/", 10),
		starstar: new TokenType("**", {beforeExpr: true}),
		coalesce: binop("??", 1),

		// Keyword token types.
		_break: kw("break"),
		_case: kw("case", beforeExpr),
		_catch: kw("catch"),
		_continue: kw("continue"),
		_debugger: kw("debugger"),
		_default: kw("default", beforeExpr),
		_do: kw("do", {isLoop: true, beforeExpr: true}),
		_else: kw("else", beforeExpr),
		_finally: kw("finally"),
		_for: kw("for", {isLoop: true}),
		_function: kw("function", startsExpr),
		_if: kw("if"),
		_return: kw("return", beforeExpr),
		_switch: kw("switch"),
		_throw: kw("throw", beforeExpr),
		_try: kw("try"),
		_var: kw("var"),
		_const: kw("const"),
		_while: kw("while", {isLoop: true}),
		_with: kw("with"),
		_new: kw("new", {beforeExpr: true, startsExpr: true}),
		_this: kw("this", startsExpr),
		_super: kw("super", startsExpr),
		_class: kw("class", startsExpr),
		_extends: kw("extends", beforeExpr),
		_export: kw("export"),
		_import: kw("import", startsExpr),
		_null: kw("null", startsExpr),
		_true: kw("true", startsExpr),
		_false: kw("false", startsExpr),
		_in: kw("in", {beforeExpr: true, binop: 7}),
		_instanceof: kw("instanceof", {beforeExpr: true, binop: 7}),
		_typeof: kw("typeof", {beforeExpr: true, prefix: true, startsExpr: true}),
		_void: kw("void", {beforeExpr: true, prefix: true, startsExpr: true}),
		_delete: kw("delete", {beforeExpr: true, prefix: true, startsExpr: true})
	};

	// Matches a whole line break (where CRLF is considered a single
	// line break). Used to count lines.

	var lineBreak = /\r\n?|\n|\u2028|\u2029/;
	var lineBreakG = new RegExp(lineBreak.source, "g");

	function isNewLine(code) {
		return code === 10 || code === 13 || code === 0x2028 || code === 0x2029
	}

	function nextLineBreak(code, from, end) {
		if ( end === void 0 ) end = code.length;

		for (var i = from; i < end; i++) {
			var next = code.charCodeAt(i);
			if (isNewLine(next))
				{ return i < end - 1 && next === 13 && code.charCodeAt(i + 1) === 10 ? i + 2 : i + 1 }
		}
		return -1
	}

	var nonASCIIwhitespace = /[\u1680\u2000-\u200a\u202f\u205f\u3000\ufeff]/;

	var skipWhiteSpace = /(?:\s|\/\/.*|\/\*[^]*?\*\/)*/g;

	var ref = Object.prototype;
	var hasOwnProperty = ref.hasOwnProperty;
	var toString = ref.toString;

	var hasOwn = Object.hasOwn || (function (obj, propName) { return (
		hasOwnProperty.call(obj, propName)
	); });

	var isArray = Array.isArray || (function (obj) { return (
		toString.call(obj) === "[object Array]"
	); });

	function wordsRegexp(words) {
		return new RegExp("^(?:" + words.replace(/ /g, "|") + ")$")
	}

	var loneSurrogate = /(?:[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])/;

	// These are used when `options.locations` is on, for the
	// `startLoc` and `endLoc` properties.

	var Position = function Position(line, col) {
		this.line = line;
		this.column = col;
	};

	Position.prototype.offset = function offset (n) {
		return new Position(this.line, this.column + n)
	};

	var SourceLocation = function SourceLocation(p, start, end) {
		this.start = start;
		this.end = end;
		if (p.sourceFile !== null) { this.source = p.sourceFile; }
	};

	// The `getLineInfo` function is mostly useful when the
	// `locations` option is off (for performance reasons) and you
	// want to find the line/column position for a given character
	// offset. `input` should be the code string that the offset refers
	// into.

	function getLineInfo(input, offset) {
		for (var line = 1, cur = 0;;) {
			var nextBreak = nextLineBreak(input, cur, offset);
			if (nextBreak < 0) { return new Position(line, offset - cur) }
			++line;
			cur = nextBreak;
		}
	}

	// A second argument must be given to configure the parser process.
	// These options are recognized (only `ecmaVersion` is required):

	var defaultOptions = {
		// `ecmaVersion` indicates the ECMAScript version to parse. Must be
		// either 3, 5, 6 (or 2015), 7 (2016), 8 (2017), 9 (2018), 10
		// (2019), 11 (2020), 12 (2021), 13 (2022), or `"latest"` (the
		// latest version the library supports). This influences support
		// for strict mode, the set of reserved words, and support for
		// new syntax features.
		ecmaVersion: null,
		// `sourceType` indicates the mode the code should be parsed in.
		// Can be either `"script"` or `"module"`. This influences global
		// strict mode and parsing of `import` and `export` declarations.
		sourceType: "script",
		// `onInsertedSemicolon` can be a callback that will be called
		// when a semicolon is automatically inserted. It will be passed
		// the position of the comma as an offset, and if `locations` is
		// enabled, it is given the location as a `{line, column}` object
		// as second argument.
		onInsertedSemicolon: null,
		// `onTrailingComma` is similar to `onInsertedSemicolon`, but for
		// trailing commas.
		onTrailingComma: null,
		// By default, reserved words are only enforced if ecmaVersion >= 5.
		// Set `allowReserved` to a boolean value to explicitly turn this on
		// an off. When this option has the value "never", reserved words
		// and keywords can also not be used as property names.
		allowReserved: null,
		// When enabled, a return at the top level is not considered an
		// error.
		allowReturnOutsideFunction: false,
		// When enabled, import/export statements are not constrained to
		// appearing at the top of the program, and an import.meta expression
		// in a script isn't considered an error.
		allowImportExportEverywhere: false,
		// By default, await identifiers are allowed to appear at the top-level scope only if ecmaVersion >= 2022.
		// When enabled, await identifiers are allowed to appear at the top-level scope,
		// but they are still not allowed in non-async functions.
		allowAwaitOutsideFunction: null,
		// When enabled, super identifiers are not constrained to
		// appearing in methods and do not raise an error when they appear elsewhere.
		allowSuperOutsideMethod: null,
		// When enabled, hashbang directive in the beginning of file
		// is allowed and treated as a line comment.
		allowHashBang: false,
		// When `locations` is on, `loc` properties holding objects with
		// `start` and `end` properties in `{line, column}` form (with
		// line being 1-based and column 0-based) will be attached to the
		// nodes.
		locations: false,
		// A function can be passed as `onToken` option, which will
		// cause Acorn to call that function with object in the same
		// format as tokens returned from `tokenizer().getToken()`. Note
		// that you are not allowed to call the parser from the
		// callback—that will corrupt its internal state.
		onToken: null,
		// A function can be passed as `onComment` option, which will
		// cause Acorn to call that function with `(block, text, start,
		// end)` parameters whenever a comment is skipped. `block` is a
		// boolean indicating whether this is a block (`/* */`) comment,
		// `text` is the content of the comment, and `start` and `end` are
		// character offsets that denote the start and end of the comment.
		// When the `locations` option is on, two more parameters are
		// passed, the full `{line, column}` locations of the start and
		// end of the comments. Note that you are not allowed to call the
		// parser from the callback—that will corrupt its internal state.
		onComment: null,
		// Nodes have their start and end characters offsets recorded in
		// `start` and `end` properties (directly on the node, rather than
		// the `loc` object, which holds line/column data. To also add a
		// [semi-standardized][range] `range` property holding a `[start,
		// end]` array with the same numbers, set the `ranges` option to
		// `true`.
		//
		// [range]: https://bugzilla.mozilla.org/show_bug.cgi?id=745678
		ranges: false,
		// It is possible to parse multiple files into a single AST by
		// passing the tree produced by parsing the first file as
		// `program` option in subsequent parses. This will add the
		// toplevel forms of the parsed file to the `Program` (top) node
		// of an existing parse tree.
		program: null,
		// When `locations` is on, you can pass this to record the source
		// file in every node's `loc` object.
		sourceFile: null,
		// This value, if given, is stored in every node, whether
		// `locations` is on or off.
		directSourceFile: null,
		// When enabled, parenthesized expressions are represented by
		// (non-standard) ParenthesizedExpression nodes
		preserveParens: false
	};

	// Interpret and default an options object

	var warnedAboutEcmaVersion = false;

	function getOptions(opts) {
		var options = {};

		for (var opt in defaultOptions)
			{ options[opt] = opts && hasOwn(opts, opt) ? opts[opt] : defaultOptions[opt]; }

		if (options.ecmaVersion === "latest") {
			options.ecmaVersion = 1e8;
		} else if (options.ecmaVersion == null) {
			if (!warnedAboutEcmaVersion && typeof console === "object" && console.warn) {
				warnedAboutEcmaVersion = true;
				console.warn("Since Acorn 8.0.0, options.ecmaVersion is required.\nDefaulting to 2020, but this will stop working in the future.");
			}
			options.ecmaVersion = 11;
		} else if (options.ecmaVersion >= 2015) {
			options.ecmaVersion -= 2009;
		}

		if (options.allowReserved == null)
			{ options.allowReserved = options.ecmaVersion < 5; }

		if (isArray(options.onToken)) {
			var tokens = options.onToken;
			options.onToken = function (token) { return tokens.push(token); };
		}
		if (isArray(options.onComment))
			{ options.onComment = pushComment(options, options.onComment); }

		return options
	}

	function pushComment(options, array) {
		return function(block, text, start, end, startLoc, endLoc) {
			var comment = {
				type: block ? "Block" : "Line",
				value: text,
				start: start,
				end: end
			};
			if (options.locations)
				{ comment.loc = new SourceLocation(this, startLoc, endLoc); }
			if (options.ranges)
				{ comment.range = [start, end]; }
			array.push(comment);
		}
	}

	// Each scope gets a bitset that may contain these flags
	var
			SCOPE_TOP = 1,
			SCOPE_FUNCTION = 2,
			SCOPE_ASYNC = 4,
			SCOPE_GENERATOR = 8,
			SCOPE_ARROW = 16,
			SCOPE_SIMPLE_CATCH = 32,
			SCOPE_SUPER = 64,
			SCOPE_DIRECT_SUPER = 128,
			SCOPE_CLASS_STATIC_BLOCK = 256,
			SCOPE_VAR = SCOPE_TOP | SCOPE_FUNCTION | SCOPE_CLASS_STATIC_BLOCK;

	function functionFlags(async, generator) {
		return SCOPE_FUNCTION | (async ? SCOPE_ASYNC : 0) | (generator ? SCOPE_GENERATOR : 0)
	}

	// Used in checkLVal* and declareName to determine the type of a binding
	var
			BIND_NONE = 0, // Not a binding
			BIND_VAR = 1, // Var-style binding
			BIND_LEXICAL = 2, // Let- or const-style binding
			BIND_FUNCTION = 3, // Function declaration
			BIND_SIMPLE_CATCH = 4, // Simple (identifier pattern) catch binding
			BIND_OUTSIDE = 5; // Special case for function names as bound inside the function

	var Parser = function Parser(options, input, startPos) {
		this.options = options = getOptions(options);
		this.sourceFile = options.sourceFile;
		this.keywords = wordsRegexp(keywords$1[options.ecmaVersion >= 6 ? 6 : options.sourceType === "module" ? "5module" : 5]);
		var reserved = "";
		if (options.allowReserved !== true) {
			reserved = reservedWords[options.ecmaVersion >= 6 ? 6 : options.ecmaVersion === 5 ? 5 : 3];
			if (options.sourceType === "module") { reserved += " await"; }
		}
		this.reservedWords = wordsRegexp(reserved);
		var reservedStrict = (reserved ? reserved + " " : "") + reservedWords.strict;
		this.reservedWordsStrict = wordsRegexp(reservedStrict);
		this.reservedWordsStrictBind = wordsRegexp(reservedStrict + " " + reservedWords.strictBind);
		this.input = String(input);

		// Used to signal to callers of `readWord1` whether the word
		// contained any escape sequences. This is needed because words with
		// escape sequences must not be interpreted as keywords.
		this.containsEsc = false;

		// Set up token state

		// The current position of the tokenizer in the input.
		if (startPos) {
			this.pos = startPos;
			this.lineStart = this.input.lastIndexOf("\n", startPos - 1) + 1;
			this.curLine = this.input.slice(0, this.lineStart).split(lineBreak).length;
		} else {
			this.pos = this.lineStart = 0;
			this.curLine = 1;
		}

		// Properties of the current token:
		// Its type
		this.type = types$1.eof;
		// For tokens that include more information than their type, the value
		this.value = null;
		// Its start and end offset
		this.start = this.end = this.pos;
		// And, if locations are used, the {line, column} object
		// corresponding to those offsets
		this.startLoc = this.endLoc = this.curPosition();

		// Position information for the previous token
		this.lastTokEndLoc = this.lastTokStartLoc = null;
		this.lastTokStart = this.lastTokEnd = this.pos;

		// The context stack is used to superficially track syntactic
		// context to predict whether a regular expression is allowed in a
		// given position.
		this.context = this.initialContext();
		this.exprAllowed = true;

		// Figure out if it's a module code.
		this.inModule = options.sourceType === "module";
		this.strict = this.inModule || this.strictDirective(this.pos);

		// Used to signify the start of a potential arrow function
		this.potentialArrowAt = -1;
		this.potentialArrowInForAwait = false;

		// Positions to delayed-check that yield/await does not exist in default parameters.
		this.yieldPos = this.awaitPos = this.awaitIdentPos = 0;
		// Labels in scope.
		this.labels = [];
		// Thus-far undefined exports.
		this.undefinedExports = Object.create(null);

		// If enabled, skip leading hashbang line.
		if (this.pos === 0 && options.allowHashBang && this.input.slice(0, 2) === "#!")
			{ this.skipLineComment(2); }

		// Scope tracking for duplicate variable names (see scope.js)
		this.scopeStack = [];
		this.enterScope(SCOPE_TOP);

		// For RegExp validation
		this.regexpState = null;

		// The stack of private names.
		// Each element has two properties: 'declared' and 'used'.
		// When it exited from the outermost class definition, all used private names must be declared.
		this.privateNameStack = [];
	};

	var prototypeAccessors = { inFunction: { configurable: true },inGenerator: { configurable: true },inAsync: { configurable: true },canAwait: { configurable: true },allowSuper: { configurable: true },allowDirectSuper: { configurable: true },treatFunctionsAsVar: { configurable: true },allowNewDotTarget: { configurable: true },inClassStaticBlock: { configurable: true } };

	Parser.prototype.parse = function parse () {
		var node = this.options.program || this.startNode();
		this.nextToken();
		return this.parseTopLevel(node)
	};

	prototypeAccessors.inFunction.get = function () { return (this.currentVarScope().flags & SCOPE_FUNCTION) > 0 };

	prototypeAccessors.inGenerator.get = function () { return (this.currentVarScope().flags & SCOPE_GENERATOR) > 0 && !this.currentVarScope().inClassFieldInit };

	prototypeAccessors.inAsync.get = function () { return (this.currentVarScope().flags & SCOPE_ASYNC) > 0 && !this.currentVarScope().inClassFieldInit };

	prototypeAccessors.canAwait.get = function () {
		for (var i = this.scopeStack.length - 1; i >= 0; i--) {
			var scope = this.scopeStack[i];
			if (scope.inClassFieldInit || scope.flags & SCOPE_CLASS_STATIC_BLOCK) { return false }
			if (scope.flags & SCOPE_FUNCTION) { return (scope.flags & SCOPE_ASYNC) > 0 }
		}
		return (this.inModule && this.options.ecmaVersion >= 13) || this.options.allowAwaitOutsideFunction
	};

	prototypeAccessors.allowSuper.get = function () {
		var ref = this.currentThisScope();
			var flags = ref.flags;
			var inClassFieldInit = ref.inClassFieldInit;
		return (flags & SCOPE_SUPER) > 0 || inClassFieldInit || this.options.allowSuperOutsideMethod
	};

	prototypeAccessors.allowDirectSuper.get = function () { return (this.currentThisScope().flags & SCOPE_DIRECT_SUPER) > 0 };

	prototypeAccessors.treatFunctionsAsVar.get = function () { return this.treatFunctionsAsVarInScope(this.currentScope()) };

	prototypeAccessors.allowNewDotTarget.get = function () {
		var ref = this.currentThisScope();
			var flags = ref.flags;
			var inClassFieldInit = ref.inClassFieldInit;
		return (flags & (SCOPE_FUNCTION | SCOPE_CLASS_STATIC_BLOCK)) > 0 || inClassFieldInit
	};

	prototypeAccessors.inClassStaticBlock.get = function () {
		return (this.currentVarScope().flags & SCOPE_CLASS_STATIC_BLOCK) > 0
	};

	Parser.extend = function extend () {
			var plugins = [], len = arguments.length;
			while ( len-- ) plugins[ len ] = arguments[ len ];

		var cls = this;
		for (var i = 0; i < plugins.length; i++) { cls = plugins[i](cls); }
		return cls
	};

	Parser.parse = function parse (input, options) {
		return new this(options, input).parse()
	};

	Parser.parseExpressionAt = function parseExpressionAt (input, pos, options) {
		var parser = new this(options, input, pos);
		parser.nextToken();
		return parser.parseExpression()
	};

	Parser.tokenizer = function tokenizer (input, options) {
		return new this(options, input)
	};

	Object.defineProperties( Parser.prototype, prototypeAccessors );

	var pp$9 = Parser.prototype;

	// ## Parser utilities

	var literal = /^(?:'((?:\\.|[^'\\])*?)'|"((?:\\.|[^"\\])*?)")/;
	pp$9.strictDirective = function(start) {
		for (;;) {
			// Try to find string literal.
			skipWhiteSpace.lastIndex = start;
			start += skipWhiteSpace.exec(this.input)[0].length;
			var match = literal.exec(this.input.slice(start));
			if (!match) { return false }
			if ((match[1] || match[2]) === "use strict") {
				skipWhiteSpace.lastIndex = start + match[0].length;
				var spaceAfter = skipWhiteSpace.exec(this.input), end = spaceAfter.index + spaceAfter[0].length;
				var next = this.input.charAt(end);
				return next === ";" || next === "}" ||
					(lineBreak.test(spaceAfter[0]) &&
					!(/[(`.[+\-/*%<>=,?^&]/.test(next) || next === "!" && this.input.charAt(end + 1) === "="))
			}
			start += match[0].length;

			// Skip semicolon, if any.
			skipWhiteSpace.lastIndex = start;
			start += skipWhiteSpace.exec(this.input)[0].length;
			if (this.input[start] === ";")
				{ start++; }
		}
	};

	// Predicate that tests whether the next token is of the given
	// type, and if yes, consumes it as a side effect.

	pp$9.eat = function(type) {
		if (this.type === type) {
			this.next();
			return true
		} else {
			return false
		}
	};

	// Tests whether parsed token is a contextual keyword.

	pp$9.isContextual = function(name) {
		return this.type === types$1.name && this.value === name && !this.containsEsc
	};

	// Consumes contextual keyword if possible.

	pp$9.eatContextual = function(name) {
		if (!this.isContextual(name)) { return false }
		this.next();
		return true
	};

	// Asserts that following token is given contextual keyword.

	pp$9.expectContextual = function(name) {
		if (!this.eatContextual(name)) { this.unexpected(); }
	};

	// Test whether a semicolon can be inserted at the current position.

	pp$9.canInsertSemicolon = function() {
		return this.type === types$1.eof ||
			this.type === types$1.braceR ||
			lineBreak.test(this.input.slice(this.lastTokEnd, this.start))
	};

	pp$9.insertSemicolon = function() {
		if (this.canInsertSemicolon()) {
			if (this.options.onInsertedSemicolon)
				{ this.options.onInsertedSemicolon(this.lastTokEnd, this.lastTokEndLoc); }
			return true
		}
	};

	// Consume a semicolon, or, failing that, see if we are allowed to
	// pretend that there is a semicolon at this position.

	pp$9.semicolon = function() {
		if (!this.eat(types$1.semi) && !this.insertSemicolon()) { this.unexpected(); }
	};

	pp$9.afterTrailingComma = function(tokType, notNext) {
		if (this.type === tokType) {
			if (this.options.onTrailingComma)
				{ this.options.onTrailingComma(this.lastTokStart, this.lastTokStartLoc); }
			if (!notNext)
				{ this.next(); }
			return true
		}
	};

	// Expect a token of a given type. If found, consume it, otherwise,
	// raise an unexpected token error.

	pp$9.expect = function(type) {
		this.eat(type) || this.unexpected();
	};

	// Raise an unexpected token error.

	pp$9.unexpected = function(pos) {
		this.raise(pos != null ? pos : this.start, "Unexpected token");
	};

	function DestructuringErrors() {
		this.shorthandAssign =
		this.trailingComma =
		this.parenthesizedAssign =
		this.parenthesizedBind =
		this.doubleProto =
			-1;
	}

	pp$9.checkPatternErrors = function(refDestructuringErrors, isAssign) {
		if (!refDestructuringErrors) { return }
		if (refDestructuringErrors.trailingComma > -1)
			{ this.raiseRecoverable(refDestructuringErrors.trailingComma, "Comma is not permitted after the rest element"); }
		var parens = isAssign ? refDestructuringErrors.parenthesizedAssign : refDestructuringErrors.parenthesizedBind;
		if (parens > -1) { this.raiseRecoverable(parens, "Parenthesized pattern"); }
	};

	pp$9.checkExpressionErrors = function(refDestructuringErrors, andThrow) {
		if (!refDestructuringErrors) { return false }
		var shorthandAssign = refDestructuringErrors.shorthandAssign;
		var doubleProto = refDestructuringErrors.doubleProto;
		if (!andThrow) { return shorthandAssign >= 0 || doubleProto >= 0 }
		if (shorthandAssign >= 0)
			{ this.raise(shorthandAssign, "Shorthand property assignments are valid only in destructuring patterns"); }
		if (doubleProto >= 0)
			{ this.raiseRecoverable(doubleProto, "Redefinition of __proto__ property"); }
	};

	pp$9.checkYieldAwaitInDefaultParams = function() {
		if (this.yieldPos && (!this.awaitPos || this.yieldPos < this.awaitPos))
			{ this.raise(this.yieldPos, "Yield expression cannot be a default value"); }
		if (this.awaitPos)
			{ this.raise(this.awaitPos, "Await expression cannot be a default value"); }
	};

	pp$9.isSimpleAssignTarget = function(expr) {
		if (expr.type === "ParenthesizedExpression")
			{ return this.isSimpleAssignTarget(expr.expression) }
		return expr.type === "Identifier" || expr.type === "MemberExpression"
	};

	var pp$8 = Parser.prototype;

	// ### Statement parsing

	// Parse a program. Initializes the parser, reads any number of
	// statements, and wraps them in a Program node.  Optionally takes a
	// `program` argument.  If present, the statements will be appended
	// to its body instead of creating a new node.

	pp$8.parseTopLevel = function(node) {
		var exports = Object.create(null);
		if (!node.body) { node.body = []; }
		while (this.type !== types$1.eof) {
			var stmt = this.parseStatement(null, true, exports);
			node.body.push(stmt);
		}
		if (this.inModule)
			{ for (var i = 0, list = Object.keys(this.undefinedExports); i < list.length; i += 1)
				{
					var name = list[i];

					this.raiseRecoverable(this.undefinedExports[name].start, ("Export '" + name + "' is not defined"));
				} }
		this.adaptDirectivePrologue(node.body);
		this.next();
		node.sourceType = this.options.sourceType;
		return this.finishNode(node, "Program")
	};

	var loopLabel = {kind: "loop"}, switchLabel = {kind: "switch"};

	pp$8.isLet = function(context) {
		if (this.options.ecmaVersion < 6 || !this.isContextual("let")) { return false }
		skipWhiteSpace.lastIndex = this.pos;
		var skip = skipWhiteSpace.exec(this.input);
		var next = this.pos + skip[0].length, nextCh = this.input.charCodeAt(next);
		// For ambiguous cases, determine if a LexicalDeclaration (or only a
		// Statement) is allowed here. If context is not empty then only a Statement
		// is allowed. However, `let [` is an explicit negative lookahead for
		// ExpressionStatement, so special-case it first.
		if (nextCh === 91 || nextCh === 92 || nextCh > 0xd7ff && nextCh < 0xdc00) { return true } // '[', '/', astral
		if (context) { return false }

		if (nextCh === 123) { return true } // '{'
		if (isIdentifierStart(nextCh, true)) {
			var pos = next + 1;
			while (isIdentifierChar(nextCh = this.input.charCodeAt(pos), true)) { ++pos; }
			if (nextCh === 92 || nextCh > 0xd7ff && nextCh < 0xdc00) { return true }
			var ident = this.input.slice(next, pos);
			if (!keywordRelationalOperator.test(ident)) { return true }
		}
		return false
	};

	// check 'async [no LineTerminator here] function'
	// - 'async /*foo*/ function' is OK.
	// - 'async /*\n*/ function' is invalid.
	pp$8.isAsyncFunction = function() {
		if (this.options.ecmaVersion < 8 || !this.isContextual("async"))
			{ return false }

		skipWhiteSpace.lastIndex = this.pos;
		var skip = skipWhiteSpace.exec(this.input);
		var next = this.pos + skip[0].length, after;
		return !lineBreak.test(this.input.slice(this.pos, next)) &&
			this.input.slice(next, next + 8) === "function" &&
			(next + 8 === this.input.length ||
			!(isIdentifierChar(after = this.input.charCodeAt(next + 8)) || after > 0xd7ff && after < 0xdc00))
	};

	// Parse a single statement.
	//
	// If expecting a statement and finding a slash operator, parse a
	// regular expression literal. This is to handle cases like
	// `if (foo) /blah/.exec(foo)`, where looking at the previous token
	// does not help.

	pp$8.parseStatement = function(context, topLevel, exports) {
		var starttype = this.type, node = this.startNode(), kind;

		if (this.isLet(context)) {
			starttype = types$1._var;
			kind = "let";
		}

		// Most types of statements are recognized by the keyword they
		// start with. Many are trivial to parse, some require a bit of
		// complexity.

		switch (starttype) {
		case types$1._break: case types$1._continue: return this.parseBreakContinueStatement(node, starttype.keyword)
		case types$1._debugger: return this.parseDebuggerStatement(node)
		case types$1._do: return this.parseDoStatement(node)
		case types$1._for: return this.parseForStatement(node)
		case types$1._function:
			// Function as sole body of either an if statement or a labeled statement
			// works, but not when it is part of a labeled statement that is the sole
			// body of an if statement.
			if ((context && (this.strict || context !== "if" && context !== "label")) && this.options.ecmaVersion >= 6) { this.unexpected(); }
			return this.parseFunctionStatement(node, false, !context)
		case types$1._class:
			if (context) { this.unexpected(); }
			return this.parseClass(node, true)
		case types$1._if: return this.parseIfStatement(node)
		case types$1._return: return this.parseReturnStatement(node)
		case types$1._switch: return this.parseSwitchStatement(node)
		case types$1._throw: return this.parseThrowStatement(node)
		case types$1._try: return this.parseTryStatement(node)
		case types$1._const: case types$1._var:
			kind = kind || this.value;
			if (context && kind !== "var") { this.unexpected(); }
			return this.parseVarStatement(node, kind)
		case types$1._while: return this.parseWhileStatement(node)
		case types$1._with: return this.parseWithStatement(node)
		case types$1.braceL: return this.parseBlock(true, node)
		case types$1.semi: return this.parseEmptyStatement(node)
		case types$1._export:
		case types$1._import:
			if (this.options.ecmaVersion > 10 && starttype === types$1._import) {
				skipWhiteSpace.lastIndex = this.pos;
				var skip = skipWhiteSpace.exec(this.input);
				var next = this.pos + skip[0].length, nextCh = this.input.charCodeAt(next);
				if (nextCh === 40 || nextCh === 46) // '(' or '.'
					{ return this.parseExpressionStatement(node, this.parseExpression()) }
			}

			if (!this.options.allowImportExportEverywhere) {
				if (!topLevel)
					{ this.raise(this.start, "'import' and 'export' may only appear at the top level"); }
				if (!this.inModule)
					{ this.raise(this.start, "'import' and 'export' may appear only with 'sourceType: module'"); }
			}
			return starttype === types$1._import ? this.parseImport(node) : this.parseExport(node, exports)

			// If the statement does not start with a statement keyword or a
			// brace, it's an ExpressionStatement or LabeledStatement. We
			// simply start parsing an expression, and afterwards, if the
			// next token is a colon and the expression was a simple
			// Identifier node, we switch to interpreting it as a label.
		default:
			if (this.isAsyncFunction()) {
				if (context) { this.unexpected(); }
				this.next();
				return this.parseFunctionStatement(node, true, !context)
			}

			var maybeName = this.value, expr = this.parseExpression();
			if (starttype === types$1.name && expr.type === "Identifier" && this.eat(types$1.colon))
				{ return this.parseLabeledStatement(node, maybeName, expr, context) }
			else { return this.parseExpressionStatement(node, expr) }
		}
	};

	pp$8.parseBreakContinueStatement = function(node, keyword) {
		var isBreak = keyword === "break";
		this.next();
		if (this.eat(types$1.semi) || this.insertSemicolon()) { node.label = null; }
		else if (this.type !== types$1.name) { this.unexpected(); }
		else {
			node.label = this.parseIdent();
			this.semicolon();
		}

		// Verify that there is an actual destination to break or
		// continue to.
		var i = 0;
		for (; i < this.labels.length; ++i) {
			var lab = this.labels[i];
			if (node.label == null || lab.name === node.label.name) {
				if (lab.kind != null && (isBreak || lab.kind === "loop")) { break }
				if (node.label && isBreak) { break }
			}
		}
		if (i === this.labels.length) { this.raise(node.start, "Unsyntactic " + keyword); }
		return this.finishNode(node, isBreak ? "BreakStatement" : "ContinueStatement")
	};

	pp$8.parseDebuggerStatement = function(node) {
		this.next();
		this.semicolon();
		return this.finishNode(node, "DebuggerStatement")
	};

	pp$8.parseDoStatement = function(node) {
		this.next();
		this.labels.push(loopLabel);
		node.body = this.parseStatement("do");
		this.labels.pop();
		this.expect(types$1._while);
		node.test = this.parseParenExpression();
		if (this.options.ecmaVersion >= 6)
			{ this.eat(types$1.semi); }
		else
			{ this.semicolon(); }
		return this.finishNode(node, "DoWhileStatement")
	};

	// Disambiguating between a `for` and a `for`/`in` or `for`/`of`
	// loop is non-trivial. Basically, we have to parse the init `var`
	// statement or expression, disallowing the `in` operator (see
	// the second parameter to `parseExpression`), and then check
	// whether the next token is `in` or `of`. When there is no init
	// part (semicolon immediately after the opening parenthesis), it
	// is a regular `for` loop.

	pp$8.parseForStatement = function(node) {
		this.next();
		var awaitAt = (this.options.ecmaVersion >= 9 && this.canAwait && this.eatContextual("await")) ? this.lastTokStart : -1;
		this.labels.push(loopLabel);
		this.enterScope(0);
		this.expect(types$1.parenL);
		if (this.type === types$1.semi) {
			if (awaitAt > -1) { this.unexpected(awaitAt); }
			return this.parseFor(node, null)
		}
		var isLet = this.isLet();
		if (this.type === types$1._var || this.type === types$1._const || isLet) {
			var init$1 = this.startNode(), kind = isLet ? "let" : this.value;
			this.next();
			this.parseVar(init$1, true, kind);
			this.finishNode(init$1, "VariableDeclaration");
			if ((this.type === types$1._in || (this.options.ecmaVersion >= 6 && this.isContextual("of"))) && init$1.declarations.length === 1) {
				if (this.options.ecmaVersion >= 9) {
					if (this.type === types$1._in) {
						if (awaitAt > -1) { this.unexpected(awaitAt); }
					} else { node.await = awaitAt > -1; }
				}
				return this.parseForIn(node, init$1)
			}
			if (awaitAt > -1) { this.unexpected(awaitAt); }
			return this.parseFor(node, init$1)
		}
		var startsWithLet = this.isContextual("let"), isForOf = false;
		var refDestructuringErrors = new DestructuringErrors;
		var init = this.parseExpression(awaitAt > -1 ? "await" : true, refDestructuringErrors);
		if (this.type === types$1._in || (isForOf = this.options.ecmaVersion >= 6 && this.isContextual("of"))) {
			if (this.options.ecmaVersion >= 9) {
				if (this.type === types$1._in) {
					if (awaitAt > -1) { this.unexpected(awaitAt); }
				} else { node.await = awaitAt > -1; }
			}
			if (startsWithLet && isForOf) { this.raise(init.start, "The left-hand side of a for-of loop may not start with 'let'."); }
			this.toAssignable(init, false, refDestructuringErrors);
			this.checkLValPattern(init);
			return this.parseForIn(node, init)
		} else {
			this.checkExpressionErrors(refDestructuringErrors, true);
		}
		if (awaitAt > -1) { this.unexpected(awaitAt); }
		return this.parseFor(node, init)
	};

	pp$8.parseFunctionStatement = function(node, isAsync, declarationPosition) {
		this.next();
		return this.parseFunction(node, FUNC_STATEMENT | (declarationPosition ? 0 : FUNC_HANGING_STATEMENT), false, isAsync)
	};

	pp$8.parseIfStatement = function(node) {
		this.next();
		node.test = this.parseParenExpression();
		// allow function declarations in branches, but only in non-strict mode
		node.consequent = this.parseStatement("if");
		node.alternate = this.eat(types$1._else) ? this.parseStatement("if") : null;
		return this.finishNode(node, "IfStatement")
	};

	pp$8.parseReturnStatement = function(node) {
		if (!this.inFunction && !this.options.allowReturnOutsideFunction)
			{ this.raise(this.start, "'return' outside of function"); }
		this.next();

		// In `return` (and `break`/`continue`), the keywords with
		// optional arguments, we eagerly look for a semicolon or the
		// possibility to insert one.

		if (this.eat(types$1.semi) || this.insertSemicolon()) { node.argument = null; }
		else { node.argument = this.parseExpression(); this.semicolon(); }
		return this.finishNode(node, "ReturnStatement")
	};

	pp$8.parseSwitchStatement = function(node) {
		this.next();
		node.discriminant = this.parseParenExpression();
		node.cases = [];
		this.expect(types$1.braceL);
		this.labels.push(switchLabel);
		this.enterScope(0);

		// Statements under must be grouped (by label) in SwitchCase
		// nodes. `cur` is used to keep the node that we are currently
		// adding statements to.

		var cur;
		for (var sawDefault = false; this.type !== types$1.braceR;) {
			if (this.type === types$1._case || this.type === types$1._default) {
				var isCase = this.type === types$1._case;
				if (cur) { this.finishNode(cur, "SwitchCase"); }
				node.cases.push(cur = this.startNode());
				cur.consequent = [];
				this.next();
				if (isCase) {
					cur.test = this.parseExpression();
				} else {
					if (sawDefault) { this.raiseRecoverable(this.lastTokStart, "Multiple default clauses"); }
					sawDefault = true;
					cur.test = null;
				}
				this.expect(types$1.colon);
			} else {
				if (!cur) { this.unexpected(); }
				cur.consequent.push(this.parseStatement(null));
			}
		}
		this.exitScope();
		if (cur) { this.finishNode(cur, "SwitchCase"); }
		this.next(); // Closing brace
		this.labels.pop();
		return this.finishNode(node, "SwitchStatement")
	};

	pp$8.parseThrowStatement = function(node) {
		this.next();
		if (lineBreak.test(this.input.slice(this.lastTokEnd, this.start)))
			{ this.raise(this.lastTokEnd, "Illegal newline after throw"); }
		node.argument = this.parseExpression();
		this.semicolon();
		return this.finishNode(node, "ThrowStatement")
	};

	// Reused empty array added for node fields that are always empty.

	var empty$1 = [];

	pp$8.parseTryStatement = function(node) {
		this.next();
		node.block = this.parseBlock();
		node.handler = null;
		if (this.type === types$1._catch) {
			var clause = this.startNode();
			this.next();
			if (this.eat(types$1.parenL)) {
				clause.param = this.parseBindingAtom();
				var simple = clause.param.type === "Identifier";
				this.enterScope(simple ? SCOPE_SIMPLE_CATCH : 0);
				this.checkLValPattern(clause.param, simple ? BIND_SIMPLE_CATCH : BIND_LEXICAL);
				this.expect(types$1.parenR);
			} else {
				if (this.options.ecmaVersion < 10) { this.unexpected(); }
				clause.param = null;
				this.enterScope(0);
			}
			clause.body = this.parseBlock(false);
			this.exitScope();
			node.handler = this.finishNode(clause, "CatchClause");
		}
		node.finalizer = this.eat(types$1._finally) ? this.parseBlock() : null;
		if (!node.handler && !node.finalizer)
			{ this.raise(node.start, "Missing catch or finally clause"); }
		return this.finishNode(node, "TryStatement")
	};

	pp$8.parseVarStatement = function(node, kind) {
		this.next();
		this.parseVar(node, false, kind);
		this.semicolon();
		return this.finishNode(node, "VariableDeclaration")
	};

	pp$8.parseWhileStatement = function(node) {
		this.next();
		node.test = this.parseParenExpression();
		this.labels.push(loopLabel);
		node.body = this.parseStatement("while");
		this.labels.pop();
		return this.finishNode(node, "WhileStatement")
	};

	pp$8.parseWithStatement = function(node) {
		if (this.strict) { this.raise(this.start, "'with' in strict mode"); }
		this.next();
		node.object = this.parseParenExpression();
		node.body = this.parseStatement("with");
		return this.finishNode(node, "WithStatement")
	};

	pp$8.parseEmptyStatement = function(node) {
		this.next();
		return this.finishNode(node, "EmptyStatement")
	};

	pp$8.parseLabeledStatement = function(node, maybeName, expr, context) {
		for (var i$1 = 0, list = this.labels; i$1 < list.length; i$1 += 1)
			{
			var label = list[i$1];

			if (label.name === maybeName)
				{ this.raise(expr.start, "Label '" + maybeName + "' is already declared");
		} }
		var kind = this.type.isLoop ? "loop" : this.type === types$1._switch ? "switch" : null;
		for (var i = this.labels.length - 1; i >= 0; i--) {
			var label$1 = this.labels[i];
			if (label$1.statementStart === node.start) {
				// Update information about previous labels on this node
				label$1.statementStart = this.start;
				label$1.kind = kind;
			} else { break }
		}
		this.labels.push({name: maybeName, kind: kind, statementStart: this.start});
		node.body = this.parseStatement(context ? context.indexOf("label") === -1 ? context + "label" : context : "label");
		this.labels.pop();
		node.label = expr;
		return this.finishNode(node, "LabeledStatement")
	};

	pp$8.parseExpressionStatement = function(node, expr) {
		node.expression = expr;
		this.semicolon();
		return this.finishNode(node, "ExpressionStatement")
	};

	// Parse a semicolon-enclosed block of statements, handling `"use
	// strict"` declarations when `allowStrict` is true (used for
	// function bodies).

	pp$8.parseBlock = function(createNewLexicalScope, node, exitStrict) {
		if ( createNewLexicalScope === void 0 ) createNewLexicalScope = true;
		if ( node === void 0 ) node = this.startNode();

		node.body = [];
		this.expect(types$1.braceL);
		if (createNewLexicalScope) { this.enterScope(0); }
		while (this.type !== types$1.braceR) {
			var stmt = this.parseStatement(null);
			node.body.push(stmt);
		}
		if (exitStrict) { this.strict = false; }
		this.next();
		if (createNewLexicalScope) { this.exitScope(); }
		return this.finishNode(node, "BlockStatement")
	};

	// Parse a regular `for` loop. The disambiguation code in
	// `parseStatement` will already have parsed the init statement or
	// expression.

	pp$8.parseFor = function(node, init) {
		node.init = init;
		this.expect(types$1.semi);
		node.test = this.type === types$1.semi ? null : this.parseExpression();
		this.expect(types$1.semi);
		node.update = this.type === types$1.parenR ? null : this.parseExpression();
		this.expect(types$1.parenR);
		node.body = this.parseStatement("for");
		this.exitScope();
		this.labels.pop();
		return this.finishNode(node, "ForStatement")
	};

	// Parse a `for`/`in` and `for`/`of` loop, which are almost
	// same from parser's perspective.

	pp$8.parseForIn = function(node, init) {
		var isForIn = this.type === types$1._in;
		this.next();

		if (
			init.type === "VariableDeclaration" &&
			init.declarations[0].init != null &&
			(
				!isForIn ||
				this.options.ecmaVersion < 8 ||
				this.strict ||
				init.kind !== "var" ||
				init.declarations[0].id.type !== "Identifier"
			)
		) {
			this.raise(
				init.start,
				((isForIn ? "for-in" : "for-of") + " loop variable declaration may not have an initializer")
			);
		}
		node.left = init;
		node.right = isForIn ? this.parseExpression() : this.parseMaybeAssign();
		this.expect(types$1.parenR);
		node.body = this.parseStatement("for");
		this.exitScope();
		this.labels.pop();
		return this.finishNode(node, isForIn ? "ForInStatement" : "ForOfStatement")
	};

	// Parse a list of variable declarations.

	pp$8.parseVar = function(node, isFor, kind) {
		node.declarations = [];
		node.kind = kind;
		for (;;) {
			var decl = this.startNode();
			this.parseVarId(decl, kind);
			if (this.eat(types$1.eq)) {
				decl.init = this.parseMaybeAssign(isFor);
			} else if (kind === "const" && !(this.type === types$1._in || (this.options.ecmaVersion >= 6 && this.isContextual("of")))) {
				this.unexpected();
			} else if (decl.id.type !== "Identifier" && !(isFor && (this.type === types$1._in || this.isContextual("of")))) {
				this.raise(this.lastTokEnd, "Complex binding patterns require an initialization value");
			} else {
				decl.init = null;
			}
			node.declarations.push(this.finishNode(decl, "VariableDeclarator"));
			if (!this.eat(types$1.comma)) { break }
		}
		return node
	};

	pp$8.parseVarId = function(decl, kind) {
		decl.id = this.parseBindingAtom();
		this.checkLValPattern(decl.id, kind === "var" ? BIND_VAR : BIND_LEXICAL, false);
	};

	var FUNC_STATEMENT = 1, FUNC_HANGING_STATEMENT = 2, FUNC_NULLABLE_ID = 4;

	// Parse a function declaration or literal (depending on the
	// `statement & FUNC_STATEMENT`).

	// Remove `allowExpressionBody` for 7.0.0, as it is only called with false
	pp$8.parseFunction = function(node, statement, allowExpressionBody, isAsync, forInit) {
		this.initFunction(node);
		if (this.options.ecmaVersion >= 9 || this.options.ecmaVersion >= 6 && !isAsync) {
			if (this.type === types$1.star && (statement & FUNC_HANGING_STATEMENT))
				{ this.unexpected(); }
			node.generator = this.eat(types$1.star);
		}
		if (this.options.ecmaVersion >= 8)
			{ node.async = !!isAsync; }

		if (statement & FUNC_STATEMENT) {
			node.id = (statement & FUNC_NULLABLE_ID) && this.type !== types$1.name ? null : this.parseIdent();
			if (node.id && !(statement & FUNC_HANGING_STATEMENT))
				// If it is a regular function declaration in sloppy mode, then it is
				// subject to Annex B semantics (BIND_FUNCTION). Otherwise, the binding
				// mode depends on properties of the current scope (see
				// treatFunctionsAsVar).
				{ this.checkLValSimple(node.id, (this.strict || node.generator || node.async) ? this.treatFunctionsAsVar ? BIND_VAR : BIND_LEXICAL : BIND_FUNCTION); }
		}

		var oldYieldPos = this.yieldPos, oldAwaitPos = this.awaitPos, oldAwaitIdentPos = this.awaitIdentPos;
		this.yieldPos = 0;
		this.awaitPos = 0;
		this.awaitIdentPos = 0;
		this.enterScope(functionFlags(node.async, node.generator));

		if (!(statement & FUNC_STATEMENT))
			{ node.id = this.type === types$1.name ? this.parseIdent() : null; }

		this.parseFunctionParams(node);
		this.parseFunctionBody(node, allowExpressionBody, false, forInit);

		this.yieldPos = oldYieldPos;
		this.awaitPos = oldAwaitPos;
		this.awaitIdentPos = oldAwaitIdentPos;
		return this.finishNode(node, (statement & FUNC_STATEMENT) ? "FunctionDeclaration" : "FunctionExpression")
	};

	pp$8.parseFunctionParams = function(node) {
		this.expect(types$1.parenL);
		node.params = this.parseBindingList(types$1.parenR, false, this.options.ecmaVersion >= 8);
		this.checkYieldAwaitInDefaultParams();
	};

	// Parse a class declaration or literal (depending on the
	// `isStatement` parameter).

	pp$8.parseClass = function(node, isStatement) {
		this.next();

		// ecma-262 14.6 Class Definitions
		// A class definition is always strict mode code.
		var oldStrict = this.strict;
		this.strict = true;

		this.parseClassId(node, isStatement);
		this.parseClassSuper(node);
		var privateNameMap = this.enterClassBody();
		var classBody = this.startNode();
		var hadConstructor = false;
		classBody.body = [];
		this.expect(types$1.braceL);
		while (this.type !== types$1.braceR) {
			var element = this.parseClassElement(node.superClass !== null);
			if (element) {
				classBody.body.push(element);
				if (element.type === "MethodDefinition" && element.kind === "constructor") {
					if (hadConstructor) { this.raise(element.start, "Duplicate constructor in the same class"); }
					hadConstructor = true;
				} else if (element.key && element.key.type === "PrivateIdentifier" && isPrivateNameConflicted(privateNameMap, element)) {
					this.raiseRecoverable(element.key.start, ("Identifier '#" + (element.key.name) + "' has already been declared"));
				}
			}
		}
		this.strict = oldStrict;
		this.next();
		node.body = this.finishNode(classBody, "ClassBody");
		this.exitClassBody();
		return this.finishNode(node, isStatement ? "ClassDeclaration" : "ClassExpression")
	};

	pp$8.parseClassElement = function(constructorAllowsSuper) {
		if (this.eat(types$1.semi)) { return null }

		var ecmaVersion = this.options.ecmaVersion;
		var node = this.startNode();
		var keyName = "";
		var isGenerator = false;
		var isAsync = false;
		var kind = "method";
		var isStatic = false;

		if (this.eatContextual("static")) {
			// Parse static init block
			if (ecmaVersion >= 13 && this.eat(types$1.braceL)) {
				this.parseClassStaticBlock(node);
				return node
			}
			if (this.isClassElementNameStart() || this.type === types$1.star) {
				isStatic = true;
			} else {
				keyName = "static";
			}
		}
		node.static = isStatic;
		if (!keyName && ecmaVersion >= 8 && this.eatContextual("async")) {
			if ((this.isClassElementNameStart() || this.type === types$1.star) && !this.canInsertSemicolon()) {
				isAsync = true;
			} else {
				keyName = "async";
			}
		}
		if (!keyName && (ecmaVersion >= 9 || !isAsync) && this.eat(types$1.star)) {
			isGenerator = true;
		}
		if (!keyName && !isAsync && !isGenerator) {
			var lastValue = this.value;
			if (this.eatContextual("get") || this.eatContextual("set")) {
				if (this.isClassElementNameStart()) {
					kind = lastValue;
				} else {
					keyName = lastValue;
				}
			}
		}

		// Parse element name
		if (keyName) {
			// 'async', 'get', 'set', or 'static' were not a keyword contextually.
			// The last token is any of those. Make it the element name.
			node.computed = false;
			node.key = this.startNodeAt(this.lastTokStart, this.lastTokStartLoc);
			node.key.name = keyName;
			this.finishNode(node.key, "Identifier");
		} else {
			this.parseClassElementName(node);
		}

		// Parse element value
		if (ecmaVersion < 13 || this.type === types$1.parenL || kind !== "method" || isGenerator || isAsync) {
			var isConstructor = !node.static && checkKeyName(node, "constructor");
			var allowsDirectSuper = isConstructor && constructorAllowsSuper;
			// Couldn't move this check into the 'parseClassMethod' method for backward compatibility.
			if (isConstructor && kind !== "method") { this.raise(node.key.start, "Constructor can't have get/set modifier"); }
			node.kind = isConstructor ? "constructor" : kind;
			this.parseClassMethod(node, isGenerator, isAsync, allowsDirectSuper);
		} else {
			this.parseClassField(node);
		}

		return node
	};

	pp$8.isClassElementNameStart = function() {
		return (
			this.type === types$1.name ||
			this.type === types$1.privateId ||
			this.type === types$1.num ||
			this.type === types$1.string ||
			this.type === types$1.bracketL ||
			this.type.keyword
		)
	};

	pp$8.parseClassElementName = function(element) {
		if (this.type === types$1.privateId) {
			if (this.value === "constructor") {
				this.raise(this.start, "Classes can't have an element named '#constructor'");
			}
			element.computed = false;
			element.key = this.parsePrivateIdent();
		} else {
			this.parsePropertyName(element);
		}
	};

	pp$8.parseClassMethod = function(method, isGenerator, isAsync, allowsDirectSuper) {
		// Check key and flags
		var key = method.key;
		if (method.kind === "constructor") {
			if (isGenerator) { this.raise(key.start, "Constructor can't be a generator"); }
			if (isAsync) { this.raise(key.start, "Constructor can't be an async method"); }
		} else if (method.static && checkKeyName(method, "prototype")) {
			this.raise(key.start, "Classes may not have a static property named prototype");
		}

		// Parse value
		var value = method.value = this.parseMethod(isGenerator, isAsync, allowsDirectSuper);

		// Check value
		if (method.kind === "get" && value.params.length !== 0)
			{ this.raiseRecoverable(value.start, "getter should have no params"); }
		if (method.kind === "set" && value.params.length !== 1)
			{ this.raiseRecoverable(value.start, "setter should have exactly one param"); }
		if (method.kind === "set" && value.params[0].type === "RestElement")
			{ this.raiseRecoverable(value.params[0].start, "Setter cannot use rest params"); }

		return this.finishNode(method, "MethodDefinition")
	};

	pp$8.parseClassField = function(field) {
		if (checkKeyName(field, "constructor")) {
			this.raise(field.key.start, "Classes can't have a field named 'constructor'");
		} else if (field.static && checkKeyName(field, "prototype")) {
			this.raise(field.key.start, "Classes can't have a static field named 'prototype'");
		}

		if (this.eat(types$1.eq)) {
			// To raise SyntaxError if 'arguments' exists in the initializer.
			var scope = this.currentThisScope();
			var inClassFieldInit = scope.inClassFieldInit;
			scope.inClassFieldInit = true;
			field.value = this.parseMaybeAssign();
			scope.inClassFieldInit = inClassFieldInit;
		} else {
			field.value = null;
		}
		this.semicolon();

		return this.finishNode(field, "PropertyDefinition")
	};

	pp$8.parseClassStaticBlock = function(node) {
		node.body = [];

		var oldLabels = this.labels;
		this.labels = [];
		this.enterScope(SCOPE_CLASS_STATIC_BLOCK | SCOPE_SUPER);
		while (this.type !== types$1.braceR) {
			var stmt = this.parseStatement(null);
			node.body.push(stmt);
		}
		this.next();
		this.exitScope();
		this.labels = oldLabels;

		return this.finishNode(node, "StaticBlock")
	};

	pp$8.parseClassId = function(node, isStatement) {
		if (this.type === types$1.name) {
			node.id = this.parseIdent();
			if (isStatement)
				{ this.checkLValSimple(node.id, BIND_LEXICAL, false); }
		} else {
			if (isStatement === true)
				{ this.unexpected(); }
			node.id = null;
		}
	};

	pp$8.parseClassSuper = function(node) {
		node.superClass = this.eat(types$1._extends) ? this.parseExprSubscripts(false) : null;
	};

	pp$8.enterClassBody = function() {
		var element = {declared: Object.create(null), used: []};
		this.privateNameStack.push(element);
		return element.declared
	};

	pp$8.exitClassBody = function() {
		var ref = this.privateNameStack.pop();
		var declared = ref.declared;
		var used = ref.used;
		var len = this.privateNameStack.length;
		var parent = len === 0 ? null : this.privateNameStack[len - 1];
		for (var i = 0; i < used.length; ++i) {
			var id = used[i];
			if (!hasOwn(declared, id.name)) {
				if (parent) {
					parent.used.push(id);
				} else {
					this.raiseRecoverable(id.start, ("Private field '#" + (id.name) + "' must be declared in an enclosing class"));
				}
			}
		}
	};

	function isPrivateNameConflicted(privateNameMap, element) {
		var name = element.key.name;
		var curr = privateNameMap[name];

		var next = "true";
		if (element.type === "MethodDefinition" && (element.kind === "get" || element.kind === "set")) {
			next = (element.static ? "s" : "i") + element.kind;
		}

		// `class { get #a(){}; static set #a(_){} }` is also conflict.
		if (
			curr === "iget" && next === "iset" ||
			curr === "iset" && next === "iget" ||
			curr === "sget" && next === "sset" ||
			curr === "sset" && next === "sget"
		) {
			privateNameMap[name] = "true";
			return false
		} else if (!curr) {
			privateNameMap[name] = next;
			return false
		} else {
			return true
		}
	}

	function checkKeyName(node, name) {
		var computed = node.computed;
		var key = node.key;
		return !computed && (
			key.type === "Identifier" && key.name === name ||
			key.type === "Literal" && key.value === name
		)
	}

	// Parses module export declaration.

	pp$8.parseExport = function(node, exports) {
		this.next();
		// export * from '...'
		if (this.eat(types$1.star)) {
			if (this.options.ecmaVersion >= 11) {
				if (this.eatContextual("as")) {
					node.exported = this.parseModuleExportName();
					this.checkExport(exports, node.exported.name, this.lastTokStart);
				} else {
					node.exported = null;
				}
			}
			this.expectContextual("from");
			if (this.type !== types$1.string) { this.unexpected(); }
			node.source = this.parseExprAtom();
			this.semicolon();
			return this.finishNode(node, "ExportAllDeclaration")
		}
		if (this.eat(types$1._default)) { // export default ...
			this.checkExport(exports, "default", this.lastTokStart);
			var isAsync;
			if (this.type === types$1._function || (isAsync = this.isAsyncFunction())) {
				var fNode = this.startNode();
				this.next();
				if (isAsync) { this.next(); }
				node.declaration = this.parseFunction(fNode, FUNC_STATEMENT | FUNC_NULLABLE_ID, false, isAsync);
			} else if (this.type === types$1._class) {
				var cNode = this.startNode();
				node.declaration = this.parseClass(cNode, "nullableID");
			} else {
				node.declaration = this.parseMaybeAssign();
				this.semicolon();
			}
			return this.finishNode(node, "ExportDefaultDeclaration")
		}
		// export var|const|let|function|class ...
		if (this.shouldParseExportStatement()) {
			node.declaration = this.parseStatement(null);
			if (node.declaration.type === "VariableDeclaration")
				{ this.checkVariableExport(exports, node.declaration.declarations); }
			else
				{ this.checkExport(exports, node.declaration.id.name, node.declaration.id.start); }
			node.specifiers = [];
			node.source = null;
		} else { // export { x, y as z } [from '...']
			node.declaration = null;
			node.specifiers = this.parseExportSpecifiers(exports);
			if (this.eatContextual("from")) {
				if (this.type !== types$1.string) { this.unexpected(); }
				node.source = this.parseExprAtom();
			} else {
				for (var i = 0, list = node.specifiers; i < list.length; i += 1) {
					// check for keywords used as local names
					var spec = list[i];

					this.checkUnreserved(spec.local);
					// check if export is defined
					this.checkLocalExport(spec.local);

					if (spec.local.type === "Literal") {
						this.raise(spec.local.start, "A string literal cannot be used as an exported binding without `from`.");
					}
				}

				node.source = null;
			}
			this.semicolon();
		}
		return this.finishNode(node, "ExportNamedDeclaration")
	};

	pp$8.checkExport = function(exports, name, pos) {
		if (!exports) { return }
		if (hasOwn(exports, name))
			{ this.raiseRecoverable(pos, "Duplicate export '" + name + "'"); }
		exports[name] = true;
	};

	pp$8.checkPatternExport = function(exports, pat) {
		var type = pat.type;
		if (type === "Identifier")
			{ this.checkExport(exports, pat.name, pat.start); }
		else if (type === "ObjectPattern")
			{ for (var i = 0, list = pat.properties; i < list.length; i += 1)
				{
					var prop = list[i];

					this.checkPatternExport(exports, prop);
				} }
		else if (type === "ArrayPattern")
			{ for (var i$1 = 0, list$1 = pat.elements; i$1 < list$1.length; i$1 += 1) {
				var elt = list$1[i$1];

					if (elt) { this.checkPatternExport(exports, elt); }
			} }
		else if (type === "Property")
			{ this.checkPatternExport(exports, pat.value); }
		else if (type === "AssignmentPattern")
			{ this.checkPatternExport(exports, pat.left); }
		else if (type === "RestElement")
			{ this.checkPatternExport(exports, pat.argument); }
		else if (type === "ParenthesizedExpression")
			{ this.checkPatternExport(exports, pat.expression); }
	};

	pp$8.checkVariableExport = function(exports, decls) {
		if (!exports) { return }
		for (var i = 0, list = decls; i < list.length; i += 1)
			{
			var decl = list[i];

			this.checkPatternExport(exports, decl.id);
		}
	};

	pp$8.shouldParseExportStatement = function() {
		return this.type.keyword === "var" ||
			this.type.keyword === "const" ||
			this.type.keyword === "class" ||
			this.type.keyword === "function" ||
			this.isLet() ||
			this.isAsyncFunction()
	};

	// Parses a comma-separated list of module exports.

	pp$8.parseExportSpecifiers = function(exports) {
		var nodes = [], first = true;
		// export { x, y as z } [from '...']
		this.expect(types$1.braceL);
		while (!this.eat(types$1.braceR)) {
			if (!first) {
				this.expect(types$1.comma);
				if (this.afterTrailingComma(types$1.braceR)) { break }
			} else { first = false; }

			var node = this.startNode();
			node.local = this.parseModuleExportName();
			node.exported = this.eatContextual("as") ? this.parseModuleExportName() : node.local;
			this.checkExport(
				exports,
				node.exported[node.exported.type === "Identifier" ? "name" : "value"],
				node.exported.start
			);
			nodes.push(this.finishNode(node, "ExportSpecifier"));
		}
		return nodes
	};

	// Parses import declaration.

	pp$8.parseImport = function(node) {
		this.next();
		// import '...'
		if (this.type === types$1.string) {
			node.specifiers = empty$1;
			node.source = this.parseExprAtom();
		} else {
			node.specifiers = this.parseImportSpecifiers();
			this.expectContextual("from");
			node.source = this.type === types$1.string ? this.parseExprAtom() : this.unexpected();
		}
		this.semicolon();
		return this.finishNode(node, "ImportDeclaration")
	};

	// Parses a comma-separated list of module imports.

	pp$8.parseImportSpecifiers = function() {
		var nodes = [], first = true;
		if (this.type === types$1.name) {
			// import defaultObj, { x, y as z } from '...'
			var node = this.startNode();
			node.local = this.parseIdent();
			this.checkLValSimple(node.local, BIND_LEXICAL);
			nodes.push(this.finishNode(node, "ImportDefaultSpecifier"));
			if (!this.eat(types$1.comma)) { return nodes }
		}
		if (this.type === types$1.star) {
			var node$1 = this.startNode();
			this.next();
			this.expectContextual("as");
			node$1.local = this.parseIdent();
			this.checkLValSimple(node$1.local, BIND_LEXICAL);
			nodes.push(this.finishNode(node$1, "ImportNamespaceSpecifier"));
			return nodes
		}
		this.expect(types$1.braceL);
		while (!this.eat(types$1.braceR)) {
			if (!first) {
				this.expect(types$1.comma);
				if (this.afterTrailingComma(types$1.braceR)) { break }
			} else { first = false; }

			var node$2 = this.startNode();
			node$2.imported = this.parseModuleExportName();
			if (this.eatContextual("as")) {
				node$2.local = this.parseIdent();
			} else {
				this.checkUnreserved(node$2.imported);
				node$2.local = node$2.imported;
			}
			this.checkLValSimple(node$2.local, BIND_LEXICAL);
			nodes.push(this.finishNode(node$2, "ImportSpecifier"));
		}
		return nodes
	};

	pp$8.parseModuleExportName = function() {
		if (this.options.ecmaVersion >= 13 && this.type === types$1.string) {
			var stringLiteral = this.parseLiteral(this.value);
			if (loneSurrogate.test(stringLiteral.value)) {
				this.raise(stringLiteral.start, "An export name cannot include a lone surrogate.");
			}
			return stringLiteral
		}
		return this.parseIdent(true)
	};

	// Set `ExpressionStatement#directive` property for directive prologues.
	pp$8.adaptDirectivePrologue = function(statements) {
		for (var i = 0; i < statements.length && this.isDirectiveCandidate(statements[i]); ++i) {
			statements[i].directive = statements[i].expression.raw.slice(1, -1);
		}
	};
	pp$8.isDirectiveCandidate = function(statement) {
		return (
			statement.type === "ExpressionStatement" &&
			statement.expression.type === "Literal" &&
			typeof statement.expression.value === "string" &&
			// Reject parenthesized strings.
			(this.input[statement.start] === "\"" || this.input[statement.start] === "'")
		)
	};

	var pp$7 = Parser.prototype;

	// Convert existing expression atom to assignable pattern
	// if possible.

	pp$7.toAssignable = function(node, isBinding, refDestructuringErrors) {
		if (this.options.ecmaVersion >= 6 && node) {
			switch (node.type) {
			case "Identifier":
				if (this.inAsync && node.name === "await")
					{ this.raise(node.start, "Cannot use 'await' as identifier inside an async function"); }
				break

			case "ObjectPattern":
			case "ArrayPattern":
			case "AssignmentPattern":
			case "RestElement":
				break

			case "ObjectExpression":
				node.type = "ObjectPattern";
				if (refDestructuringErrors) { this.checkPatternErrors(refDestructuringErrors, true); }
				for (var i = 0, list = node.properties; i < list.length; i += 1) {
					var prop = list[i];

				this.toAssignable(prop, isBinding);
					// Early error:
					//   AssignmentRestProperty[Yield, Await] :
					//     `...` DestructuringAssignmentTarget[Yield, Await]
					//
					//   It is a Syntax Error if |DestructuringAssignmentTarget| is an |ArrayLiteral| or an |ObjectLiteral|.
					if (
						prop.type === "RestElement" &&
						(prop.argument.type === "ArrayPattern" || prop.argument.type === "ObjectPattern")
					) {
						this.raise(prop.argument.start, "Unexpected token");
					}
				}
				break

			case "Property":
				// AssignmentProperty has type === "Property"
				if (node.kind !== "init") { this.raise(node.key.start, "Object pattern can't contain getter or setter"); }
				this.toAssignable(node.value, isBinding);
				break

			case "ArrayExpression":
				node.type = "ArrayPattern";
				if (refDestructuringErrors) { this.checkPatternErrors(refDestructuringErrors, true); }
				this.toAssignableList(node.elements, isBinding);
				break

			case "SpreadElement":
				node.type = "RestElement";
				this.toAssignable(node.argument, isBinding);
				if (node.argument.type === "AssignmentPattern")
					{ this.raise(node.argument.start, "Rest elements cannot have a default value"); }
				break

			case "AssignmentExpression":
				if (node.operator !== "=") { this.raise(node.left.end, "Only '=' operator can be used for specifying default value."); }
				node.type = "AssignmentPattern";
				delete node.operator;
				this.toAssignable(node.left, isBinding);
				break

			case "ParenthesizedExpression":
				this.toAssignable(node.expression, isBinding, refDestructuringErrors);
				break

			case "ChainExpression":
				this.raiseRecoverable(node.start, "Optional chaining cannot appear in left-hand side");
				break

			case "MemberExpression":
				if (!isBinding) { break }

			default:
				this.raise(node.start, "Assigning to rvalue");
			}
		} else if (refDestructuringErrors) { this.checkPatternErrors(refDestructuringErrors, true); }
		return node
	};

	// Convert list of expression atoms to binding list.

	pp$7.toAssignableList = function(exprList, isBinding) {
		var end = exprList.length;
		for (var i = 0; i < end; i++) {
			var elt = exprList[i];
			if (elt) { this.toAssignable(elt, isBinding); }
		}
		if (end) {
			var last = exprList[end - 1];
			if (this.options.ecmaVersion === 6 && isBinding && last && last.type === "RestElement" && last.argument.type !== "Identifier")
				{ this.unexpected(last.argument.start); }
		}
		return exprList
	};

	// Parses spread element.

	pp$7.parseSpread = function(refDestructuringErrors) {
		var node = this.startNode();
		this.next();
		node.argument = this.parseMaybeAssign(false, refDestructuringErrors);
		return this.finishNode(node, "SpreadElement")
	};

	pp$7.parseRestBinding = function() {
		var node = this.startNode();
		this.next();

		// RestElement inside of a function parameter must be an identifier
		if (this.options.ecmaVersion === 6 && this.type !== types$1.name)
			{ this.unexpected(); }

		node.argument = this.parseBindingAtom();

		return this.finishNode(node, "RestElement")
	};

	// Parses lvalue (assignable) atom.

	pp$7.parseBindingAtom = function() {
		if (this.options.ecmaVersion >= 6) {
			switch (this.type) {
			case types$1.bracketL:
				var node = this.startNode();
				this.next();
				node.elements = this.parseBindingList(types$1.bracketR, true, true);
				return this.finishNode(node, "ArrayPattern")

			case types$1.braceL:
				return this.parseObj(true)
			}
		}
		return this.parseIdent()
	};

	pp$7.parseBindingList = function(close, allowEmpty, allowTrailingComma) {
		var elts = [], first = true;
		while (!this.eat(close)) {
			if (first) { first = false; }
			else { this.expect(types$1.comma); }
			if (allowEmpty && this.type === types$1.comma) {
				elts.push(null);
			} else if (allowTrailingComma && this.afterTrailingComma(close)) {
				break
			} else if (this.type === types$1.ellipsis) {
				var rest = this.parseRestBinding();
				this.parseBindingListItem(rest);
				elts.push(rest);
				if (this.type === types$1.comma) { this.raise(this.start, "Comma is not permitted after the rest element"); }
				this.expect(close);
				break
			} else {
				var elem = this.parseMaybeDefault(this.start, this.startLoc);
				this.parseBindingListItem(elem);
				elts.push(elem);
			}
		}
		return elts
	};

	pp$7.parseBindingListItem = function(param) {
		return param
	};

	// Parses assignment pattern around given atom if possible.

	pp$7.parseMaybeDefault = function(startPos, startLoc, left) {
		left = left || this.parseBindingAtom();
		if (this.options.ecmaVersion < 6 || !this.eat(types$1.eq)) { return left }
		var node = this.startNodeAt(startPos, startLoc);
		node.left = left;
		node.right = this.parseMaybeAssign();
		return this.finishNode(node, "AssignmentPattern")
	};

	// The following three functions all verify that a node is an lvalue —
	// something that can be bound, or assigned to. In order to do so, they perform
	// a variety of checks:
	//
	// - Check that none of the bound/assigned-to identifiers are reserved words.
	// - Record name declarations for bindings in the appropriate scope.
	// - Check duplicate argument names, if checkClashes is set.
	//
	// If a complex binding pattern is encountered (e.g., object and array
	// destructuring), the entire pattern is recursively checked.
	//
	// There are three versions of checkLVal*() appropriate for different
	// circumstances:
	//
	// - checkLValSimple() shall be used if the syntactic construct supports
	//   nothing other than identifiers and member expressions. Parenthesized
	//   expressions are also correctly handled. This is generally appropriate for
	//   constructs for which the spec says
	//
	//   > It is a Syntax Error if AssignmentTargetType of [the production] is not
	//   > simple.
	//
	//   It is also appropriate for checking if an identifier is valid and not
	//   defined elsewhere, like import declarations or function/class identifiers.
	//
	//   Examples where this is used include:
	//     a += …;
	//     import a from '…';
	//   where a is the node to be checked.
	//
	// - checkLValPattern() shall be used if the syntactic construct supports
	//   anything checkLValSimple() supports, as well as object and array
	//   destructuring patterns. This is generally appropriate for constructs for
	//   which the spec says
	//
	//   > It is a Syntax Error if [the production] is neither an ObjectLiteral nor
	//   > an ArrayLiteral and AssignmentTargetType of [the production] is not
	//   > simple.
	//
	//   Examples where this is used include:
	//     (a = …);
	//     const a = …;
	//     try { … } catch (a) { … }
	//   where a is the node to be checked.
	//
	// - checkLValInnerPattern() shall be used if the syntactic construct supports
	//   anything checkLValPattern() supports, as well as default assignment
	//   patterns, rest elements, and other constructs that may appear within an
	//   object or array destructuring pattern.
	//
	//   As a special case, function parameters also use checkLValInnerPattern(),
	//   as they also support defaults and rest constructs.
	//
	// These functions deliberately support both assignment and binding constructs,
	// as the logic for both is exceedingly similar. If the node is the target of
	// an assignment, then bindingType should be set to BIND_NONE. Otherwise, it
	// should be set to the appropriate BIND_* constant, like BIND_VAR or
	// BIND_LEXICAL.
	//
	// If the function is called with a non-BIND_NONE bindingType, then
	// additionally a checkClashes object may be specified to allow checking for
	// duplicate argument names. checkClashes is ignored if the provided construct
	// is an assignment (i.e., bindingType is BIND_NONE).

	pp$7.checkLValSimple = function(expr, bindingType, checkClashes) {
		if ( bindingType === void 0 ) bindingType = BIND_NONE;

		var isBind = bindingType !== BIND_NONE;

		switch (expr.type) {
		case "Identifier":
			if (this.strict && this.reservedWordsStrictBind.test(expr.name))
				{ this.raiseRecoverable(expr.start, (isBind ? "Binding " : "Assigning to ") + expr.name + " in strict mode"); }
			if (isBind) {
				if (bindingType === BIND_LEXICAL && expr.name === "let")
					{ this.raiseRecoverable(expr.start, "let is disallowed as a lexically bound name"); }
				if (checkClashes) {
					if (hasOwn(checkClashes, expr.name))
						{ this.raiseRecoverable(expr.start, "Argument name clash"); }
					checkClashes[expr.name] = true;
				}
				if (bindingType !== BIND_OUTSIDE) { this.declareName(expr.name, bindingType, expr.start); }
			}
			break

		case "ChainExpression":
			this.raiseRecoverable(expr.start, "Optional chaining cannot appear in left-hand side");
			break

		case "MemberExpression":
			if (isBind) { this.raiseRecoverable(expr.start, "Binding member expression"); }
			break

		case "ParenthesizedExpression":
			if (isBind) { this.raiseRecoverable(expr.start, "Binding parenthesized expression"); }
			return this.checkLValSimple(expr.expression, bindingType, checkClashes)

		default:
			this.raise(expr.start, (isBind ? "Binding" : "Assigning to") + " rvalue");
		}
	};

	pp$7.checkLValPattern = function(expr, bindingType, checkClashes) {
		if ( bindingType === void 0 ) bindingType = BIND_NONE;

		switch (expr.type) {
		case "ObjectPattern":
			for (var i = 0, list = expr.properties; i < list.length; i += 1) {
				var prop = list[i];

			this.checkLValInnerPattern(prop, bindingType, checkClashes);
			}
			break

		case "ArrayPattern":
			for (var i$1 = 0, list$1 = expr.elements; i$1 < list$1.length; i$1 += 1) {
				var elem = list$1[i$1];

			if (elem) { this.checkLValInnerPattern(elem, bindingType, checkClashes); }
			}
			break

		default:
			this.checkLValSimple(expr, bindingType, checkClashes);
		}
	};

	pp$7.checkLValInnerPattern = function(expr, bindingType, checkClashes) {
		if ( bindingType === void 0 ) bindingType = BIND_NONE;

		switch (expr.type) {
		case "Property":
			// AssignmentProperty has type === "Property"
			this.checkLValInnerPattern(expr.value, bindingType, checkClashes);
			break

		case "AssignmentPattern":
			this.checkLValPattern(expr.left, bindingType, checkClashes);
			break

		case "RestElement":
			this.checkLValPattern(expr.argument, bindingType, checkClashes);
			break

		default:
			this.checkLValPattern(expr, bindingType, checkClashes);
		}
	};

	// The algorithm used to determine whether a regexp can appear at a

	var TokContext = function TokContext(token, isExpr, preserveSpace, override, generator) {
		this.token = token;
		this.isExpr = !!isExpr;
		this.preserveSpace = !!preserveSpace;
		this.override = override;
		this.generator = !!generator;
	};

	var types = {
		b_stat: new TokContext("{", false),
		b_expr: new TokContext("{", true),
		b_tmpl: new TokContext("${", false),
		p_stat: new TokContext("(", false),
		p_expr: new TokContext("(", true),
		q_tmpl: new TokContext("`", true, true, function (p) { return p.tryReadTemplateToken(); }),
		f_stat: new TokContext("function", false),
		f_expr: new TokContext("function", true),
		f_expr_gen: new TokContext("function", true, false, null, true),
		f_gen: new TokContext("function", false, false, null, true)
	};

	var pp$6 = Parser.prototype;

	pp$6.initialContext = function() {
		return [types.b_stat]
	};

	pp$6.curContext = function() {
		return this.context[this.context.length - 1]
	};

	pp$6.braceIsBlock = function(prevType) {
		var parent = this.curContext();
		if (parent === types.f_expr || parent === types.f_stat)
			{ return true }
		if (prevType === types$1.colon && (parent === types.b_stat || parent === types.b_expr))
			{ return !parent.isExpr }

		// The check for `tt.name && exprAllowed` detects whether we are
		// after a `yield` or `of` construct. See the `updateContext` for
		// `tt.name`.
		if (prevType === types$1._return || prevType === types$1.name && this.exprAllowed)
			{ return lineBreak.test(this.input.slice(this.lastTokEnd, this.start)) }
		if (prevType === types$1._else || prevType === types$1.semi || prevType === types$1.eof || prevType === types$1.parenR || prevType === types$1.arrow)
			{ return true }
		if (prevType === types$1.braceL)
			{ return parent === types.b_stat }
		if (prevType === types$1._var || prevType === types$1._const || prevType === types$1.name)
			{ return false }
		return !this.exprAllowed
	};

	pp$6.inGeneratorContext = function() {
		for (var i = this.context.length - 1; i >= 1; i--) {
			var context = this.context[i];
			if (context.token === "function")
				{ return context.generator }
		}
		return false
	};

	pp$6.updateContext = function(prevType) {
		var update, type = this.type;
		if (type.keyword && prevType === types$1.dot)
			{ this.exprAllowed = false; }
		else if (update = type.updateContext)
			{ update.call(this, prevType); }
		else
			{ this.exprAllowed = type.beforeExpr; }
	};

	// Used to handle egde case when token context could not be inferred correctly in tokenize phase
	pp$6.overrideContext = function(tokenCtx) {
		if (this.curContext() !== tokenCtx) {
			this.context[this.context.length - 1] = tokenCtx;
		}
	};

	// Token-specific context update code

	types$1.parenR.updateContext = types$1.braceR.updateContext = function() {
		if (this.context.length === 1) {
			this.exprAllowed = true;
			return
		}
		var out = this.context.pop();
		if (out === types.b_stat && this.curContext().token === "function") {
			out = this.context.pop();
		}
		this.exprAllowed = !out.isExpr;
	};

	types$1.braceL.updateContext = function(prevType) {
		this.context.push(this.braceIsBlock(prevType) ? types.b_stat : types.b_expr);
		this.exprAllowed = true;
	};

	types$1.dollarBraceL.updateContext = function() {
		this.context.push(types.b_tmpl);
		this.exprAllowed = true;
	};

	types$1.parenL.updateContext = function(prevType) {
		var statementParens = prevType === types$1._if || prevType === types$1._for || prevType === types$1._with || prevType === types$1._while;
		this.context.push(statementParens ? types.p_stat : types.p_expr);
		this.exprAllowed = true;
	};

	types$1.incDec.updateContext = function() {
		// tokExprAllowed stays unchanged
	};

	types$1._function.updateContext = types$1._class.updateContext = function(prevType) {
		if (prevType.beforeExpr && prevType !== types$1._else &&
				!(prevType === types$1.semi && this.curContext() !== types.p_stat) &&
				!(prevType === types$1._return && lineBreak.test(this.input.slice(this.lastTokEnd, this.start))) &&
				!((prevType === types$1.colon || prevType === types$1.braceL) && this.curContext() === types.b_stat))
			{ this.context.push(types.f_expr); }
		else
			{ this.context.push(types.f_stat); }
		this.exprAllowed = false;
	};

	types$1.backQuote.updateContext = function() {
		if (this.curContext() === types.q_tmpl)
			{ this.context.pop(); }
		else
			{ this.context.push(types.q_tmpl); }
		this.exprAllowed = false;
	};

	types$1.star.updateContext = function(prevType) {
		if (prevType === types$1._function) {
			var index = this.context.length - 1;
			if (this.context[index] === types.f_expr)
				{ this.context[index] = types.f_expr_gen; }
			else
				{ this.context[index] = types.f_gen; }
		}
		this.exprAllowed = true;
	};

	types$1.name.updateContext = function(prevType) {
		var allowed = false;
		if (this.options.ecmaVersion >= 6 && prevType !== types$1.dot) {
			if (this.value === "of" && !this.exprAllowed ||
					this.value === "yield" && this.inGeneratorContext())
				{ allowed = true; }
		}
		this.exprAllowed = allowed;
	};

	// A recursive descent parser operates by defining functions for all

	var pp$5 = Parser.prototype;

	// Check if property name clashes with already added.
	// Object/class getters and setters are not allowed to clash —
	// either with each other or with an init property — and in
	// strict mode, init properties are also not allowed to be repeated.

	pp$5.checkPropClash = function(prop, propHash, refDestructuringErrors) {
		if (this.options.ecmaVersion >= 9 && prop.type === "SpreadElement")
			{ return }
		if (this.options.ecmaVersion >= 6 && (prop.computed || prop.method || prop.shorthand))
			{ return }
		var key = prop.key;
		var name;
		switch (key.type) {
		case "Identifier": name = key.name; break
		case "Literal": name = String(key.value); break
		default: return
		}
		var kind = prop.kind;
		if (this.options.ecmaVersion >= 6) {
			if (name === "__proto__" && kind === "init") {
				if (propHash.proto) {
					if (refDestructuringErrors) {
						if (refDestructuringErrors.doubleProto < 0) {
							refDestructuringErrors.doubleProto = key.start;
						}
					} else {
						this.raiseRecoverable(key.start, "Redefinition of __proto__ property");
					}
				}
				propHash.proto = true;
			}
			return
		}
		name = "$" + name;
		var other = propHash[name];
		if (other) {
			var redefinition;
			if (kind === "init") {
				redefinition = this.strict && other.init || other.get || other.set;
			} else {
				redefinition = other.init || other[kind];
			}
			if (redefinition)
				{ this.raiseRecoverable(key.start, "Redefinition of property"); }
		} else {
			other = propHash[name] = {
				init: false,
				get: false,
				set: false
			};
		}
		other[kind] = true;
	};

	// ### Expression parsing

	// These nest, from the most general expression type at the top to
	// 'atomic', nondivisible expression types at the bottom. Most of
	// the functions will simply let the function(s) below them parse,
	// and, *if* the syntactic construct they handle is present, wrap
	// the AST node that the inner parser gave them in another node.

	// Parse a full expression. The optional arguments are used to
	// forbid the `in` operator (in for loops initalization expressions)
	// and provide reference for storing '=' operator inside shorthand
	// property assignment in contexts where both object expression
	// and object pattern might appear (so it's possible to raise
	// delayed syntax error at correct position).

	pp$5.parseExpression = function(forInit, refDestructuringErrors) {
		var startPos = this.start, startLoc = this.startLoc;
		var expr = this.parseMaybeAssign(forInit, refDestructuringErrors);
		if (this.type === types$1.comma) {
			var node = this.startNodeAt(startPos, startLoc);
			node.expressions = [expr];
			while (this.eat(types$1.comma)) { node.expressions.push(this.parseMaybeAssign(forInit, refDestructuringErrors)); }
			return this.finishNode(node, "SequenceExpression")
		}
		return expr
	};

	// Parse an assignment expression. This includes applications of
	// operators like `+=`.

	pp$5.parseMaybeAssign = function(forInit, refDestructuringErrors, afterLeftParse) {
		if (this.isContextual("yield")) {
			if (this.inGenerator) { return this.parseYield(forInit) }
			// The tokenizer will assume an expression is allowed after
			// `yield`, but this isn't that kind of yield
			else { this.exprAllowed = false; }
		}

		var ownDestructuringErrors = false, oldParenAssign = -1, oldTrailingComma = -1, oldDoubleProto = -1;
		if (refDestructuringErrors) {
			oldParenAssign = refDestructuringErrors.parenthesizedAssign;
			oldTrailingComma = refDestructuringErrors.trailingComma;
			oldDoubleProto = refDestructuringErrors.doubleProto;
			refDestructuringErrors.parenthesizedAssign = refDestructuringErrors.trailingComma = -1;
		} else {
			refDestructuringErrors = new DestructuringErrors;
			ownDestructuringErrors = true;
		}

		var startPos = this.start, startLoc = this.startLoc;
		if (this.type === types$1.parenL || this.type === types$1.name) {
			this.potentialArrowAt = this.start;
			this.potentialArrowInForAwait = forInit === "await";
		}
		var left = this.parseMaybeConditional(forInit, refDestructuringErrors);
		if (afterLeftParse) { left = afterLeftParse.call(this, left, startPos, startLoc); }
		if (this.type.isAssign) {
			var node = this.startNodeAt(startPos, startLoc);
			node.operator = this.value;
			if (this.type === types$1.eq)
				{ left = this.toAssignable(left, false, refDestructuringErrors); }
			if (!ownDestructuringErrors) {
				refDestructuringErrors.parenthesizedAssign = refDestructuringErrors.trailingComma = refDestructuringErrors.doubleProto = -1;
			}
			if (refDestructuringErrors.shorthandAssign >= left.start)
				{ refDestructuringErrors.shorthandAssign = -1; } // reset because shorthand default was used correctly
			if (this.type === types$1.eq)
				{ this.checkLValPattern(left); }
			else
				{ this.checkLValSimple(left); }
			node.left = left;
			this.next();
			node.right = this.parseMaybeAssign(forInit);
			if (oldDoubleProto > -1) { refDestructuringErrors.doubleProto = oldDoubleProto; }
			return this.finishNode(node, "AssignmentExpression")
		} else {
			if (ownDestructuringErrors) { this.checkExpressionErrors(refDestructuringErrors, true); }
		}
		if (oldParenAssign > -1) { refDestructuringErrors.parenthesizedAssign = oldParenAssign; }
		if (oldTrailingComma > -1) { refDestructuringErrors.trailingComma = oldTrailingComma; }
		return left
	};

	// Parse a ternary conditional (`?:`) operator.

	pp$5.parseMaybeConditional = function(forInit, refDestructuringErrors) {
		var startPos = this.start, startLoc = this.startLoc;
		var expr = this.parseExprOps(forInit, refDestructuringErrors);
		if (this.checkExpressionErrors(refDestructuringErrors)) { return expr }
		if (this.eat(types$1.question)) {
			var node = this.startNodeAt(startPos, startLoc);
			node.test = expr;
			node.consequent = this.parseMaybeAssign();
			this.expect(types$1.colon);
			node.alternate = this.parseMaybeAssign(forInit);
			return this.finishNode(node, "ConditionalExpression")
		}
		return expr
	};

	// Start the precedence parser.

	pp$5.parseExprOps = function(forInit, refDestructuringErrors) {
		var startPos = this.start, startLoc = this.startLoc;
		var expr = this.parseMaybeUnary(refDestructuringErrors, false, false, forInit);
		if (this.checkExpressionErrors(refDestructuringErrors)) { return expr }
		return expr.start === startPos && expr.type === "ArrowFunctionExpression" ? expr : this.parseExprOp(expr, startPos, startLoc, -1, forInit)
	};

	// Parse binary operators with the operator precedence parsing
	// algorithm. `left` is the left-hand side of the operator.
	// `minPrec` provides context that allows the function to stop and
	// defer further parser to one of its callers when it encounters an
	// operator that has a lower precedence than the set it is parsing.

	pp$5.parseExprOp = function(left, leftStartPos, leftStartLoc, minPrec, forInit) {
		var prec = this.type.binop;
		if (prec != null && (!forInit || this.type !== types$1._in)) {
			if (prec > minPrec) {
				var logical = this.type === types$1.logicalOR || this.type === types$1.logicalAND;
				var coalesce = this.type === types$1.coalesce;
				if (coalesce) {
					// Handle the precedence of `tt.coalesce` as equal to the range of logical expressions.
					// In other words, `node.right` shouldn't contain logical expressions in order to check the mixed error.
					prec = types$1.logicalAND.binop;
				}
				var op = this.value;
				this.next();
				var startPos = this.start, startLoc = this.startLoc;
				var right = this.parseExprOp(this.parseMaybeUnary(null, false, false, forInit), startPos, startLoc, prec, forInit);
				var node = this.buildBinary(leftStartPos, leftStartLoc, left, right, op, logical || coalesce);
				if ((logical && this.type === types$1.coalesce) || (coalesce && (this.type === types$1.logicalOR || this.type === types$1.logicalAND))) {
					this.raiseRecoverable(this.start, "Logical expressions and coalesce expressions cannot be mixed. Wrap either by parentheses");
				}
				return this.parseExprOp(node, leftStartPos, leftStartLoc, minPrec, forInit)
			}
		}
		return left
	};

	pp$5.buildBinary = function(startPos, startLoc, left, right, op, logical) {
		if (right.type === "PrivateIdentifier") { this.raise(right.start, "Private identifier can only be left side of binary expression"); }
		var node = this.startNodeAt(startPos, startLoc);
		node.left = left;
		node.operator = op;
		node.right = right;
		return this.finishNode(node, logical ? "LogicalExpression" : "BinaryExpression")
	};

	// Parse unary operators, both prefix and postfix.

	pp$5.parseMaybeUnary = function(refDestructuringErrors, sawUnary, incDec, forInit) {
		var startPos = this.start, startLoc = this.startLoc, expr;
		if (this.isContextual("await") && this.canAwait) {
			expr = this.parseAwait(forInit);
			sawUnary = true;
		} else if (this.type.prefix) {
			var node = this.startNode(), update = this.type === types$1.incDec;
			node.operator = this.value;
			node.prefix = true;
			this.next();
			node.argument = this.parseMaybeUnary(null, true, update, forInit);
			this.checkExpressionErrors(refDestructuringErrors, true);
			if (update) { this.checkLValSimple(node.argument); }
			else if (this.strict && node.operator === "delete" &&
							node.argument.type === "Identifier")
				{ this.raiseRecoverable(node.start, "Deleting local variable in strict mode"); }
			else if (node.operator === "delete" && isPrivateFieldAccess(node.argument))
				{ this.raiseRecoverable(node.start, "Private fields can not be deleted"); }
			else { sawUnary = true; }
			expr = this.finishNode(node, update ? "UpdateExpression" : "UnaryExpression");
		} else if (!sawUnary && this.type === types$1.privateId) {
			if (forInit || this.privateNameStack.length === 0) { this.unexpected(); }
			expr = this.parsePrivateIdent();
			// only could be private fields in 'in', such as #x in obj
			if (this.type !== types$1._in) { this.unexpected(); }
		} else {
			expr = this.parseExprSubscripts(refDestructuringErrors, forInit);
			if (this.checkExpressionErrors(refDestructuringErrors)) { return expr }
			while (this.type.postfix && !this.canInsertSemicolon()) {
				var node$1 = this.startNodeAt(startPos, startLoc);
				node$1.operator = this.value;
				node$1.prefix = false;
				node$1.argument = expr;
				this.checkLValSimple(expr);
				this.next();
				expr = this.finishNode(node$1, "UpdateExpression");
			}
		}

		if (!incDec && this.eat(types$1.starstar)) {
			if (sawUnary)
				{ this.unexpected(this.lastTokStart); }
			else
				{ return this.buildBinary(startPos, startLoc, expr, this.parseMaybeUnary(null, false, false, forInit), "**", false) }
		} else {
			return expr
		}
	};

	function isPrivateFieldAccess(node) {
		return (
			node.type === "MemberExpression" && node.property.type === "PrivateIdentifier" ||
			node.type === "ChainExpression" && isPrivateFieldAccess(node.expression)
		)
	}

	// Parse call, dot, and `[]`-subscript expressions.

	pp$5.parseExprSubscripts = function(refDestructuringErrors, forInit) {
		var startPos = this.start, startLoc = this.startLoc;
		var expr = this.parseExprAtom(refDestructuringErrors, forInit);
		if (expr.type === "ArrowFunctionExpression" && this.input.slice(this.lastTokStart, this.lastTokEnd) !== ")")
			{ return expr }
		var result = this.parseSubscripts(expr, startPos, startLoc, false, forInit);
		if (refDestructuringErrors && result.type === "MemberExpression") {
			if (refDestructuringErrors.parenthesizedAssign >= result.start) { refDestructuringErrors.parenthesizedAssign = -1; }
			if (refDestructuringErrors.parenthesizedBind >= result.start) { refDestructuringErrors.parenthesizedBind = -1; }
			if (refDestructuringErrors.trailingComma >= result.start) { refDestructuringErrors.trailingComma = -1; }
		}
		return result
	};

	pp$5.parseSubscripts = function(base, startPos, startLoc, noCalls, forInit) {
		var maybeAsyncArrow = this.options.ecmaVersion >= 8 && base.type === "Identifier" && base.name === "async" &&
				this.lastTokEnd === base.end && !this.canInsertSemicolon() && base.end - base.start === 5 &&
				this.potentialArrowAt === base.start;
		var optionalChained = false;

		while (true) {
			var element = this.parseSubscript(base, startPos, startLoc, noCalls, maybeAsyncArrow, optionalChained, forInit);

			if (element.optional) { optionalChained = true; }
			if (element === base || element.type === "ArrowFunctionExpression") {
				if (optionalChained) {
					var chainNode = this.startNodeAt(startPos, startLoc);
					chainNode.expression = element;
					element = this.finishNode(chainNode, "ChainExpression");
				}
				return element
			}

			base = element;
		}
	};

	pp$5.parseSubscript = function(base, startPos, startLoc, noCalls, maybeAsyncArrow, optionalChained, forInit) {
		var optionalSupported = this.options.ecmaVersion >= 11;
		var optional = optionalSupported && this.eat(types$1.questionDot);
		if (noCalls && optional) { this.raise(this.lastTokStart, "Optional chaining cannot appear in the callee of new expressions"); }

		var computed = this.eat(types$1.bracketL);
		if (computed || (optional && this.type !== types$1.parenL && this.type !== types$1.backQuote) || this.eat(types$1.dot)) {
			var node = this.startNodeAt(startPos, startLoc);
			node.object = base;
			if (computed) {
				node.property = this.parseExpression();
				this.expect(types$1.bracketR);
			} else if (this.type === types$1.privateId && base.type !== "Super") {
				node.property = this.parsePrivateIdent();
			} else {
				node.property = this.parseIdent(this.options.allowReserved !== "never");
			}
			node.computed = !!computed;
			if (optionalSupported) {
				node.optional = optional;
			}
			base = this.finishNode(node, "MemberExpression");
		} else if (!noCalls && this.eat(types$1.parenL)) {
			var refDestructuringErrors = new DestructuringErrors, oldYieldPos = this.yieldPos, oldAwaitPos = this.awaitPos, oldAwaitIdentPos = this.awaitIdentPos;
			this.yieldPos = 0;
			this.awaitPos = 0;
			this.awaitIdentPos = 0;
			var exprList = this.parseExprList(types$1.parenR, this.options.ecmaVersion >= 8, false, refDestructuringErrors);
			if (maybeAsyncArrow && !optional && !this.canInsertSemicolon() && this.eat(types$1.arrow)) {
				this.checkPatternErrors(refDestructuringErrors, false);
				this.checkYieldAwaitInDefaultParams();
				if (this.awaitIdentPos > 0)
					{ this.raise(this.awaitIdentPos, "Cannot use 'await' as identifier inside an async function"); }
				this.yieldPos = oldYieldPos;
				this.awaitPos = oldAwaitPos;
				this.awaitIdentPos = oldAwaitIdentPos;
				return this.parseArrowExpression(this.startNodeAt(startPos, startLoc), exprList, true, forInit)
			}
			this.checkExpressionErrors(refDestructuringErrors, true);
			this.yieldPos = oldYieldPos || this.yieldPos;
			this.awaitPos = oldAwaitPos || this.awaitPos;
			this.awaitIdentPos = oldAwaitIdentPos || this.awaitIdentPos;
			var node$1 = this.startNodeAt(startPos, startLoc);
			node$1.callee = base;
			node$1.arguments = exprList;
			if (optionalSupported) {
				node$1.optional = optional;
			}
			base = this.finishNode(node$1, "CallExpression");
		} else if (this.type === types$1.backQuote) {
			if (optional || optionalChained) {
				this.raise(this.start, "Optional chaining cannot appear in the tag of tagged template expressions");
			}
			var node$2 = this.startNodeAt(startPos, startLoc);
			node$2.tag = base;
			node$2.quasi = this.parseTemplate({isTagged: true});
			base = this.finishNode(node$2, "TaggedTemplateExpression");
		}
		return base
	};

	// Parse an atomic expression — either a single token that is an
	// expression, an expression started by a keyword like `function` or
	// `new`, or an expression wrapped in punctuation like `()`, `[]`,
	// or `{}`.

	pp$5.parseExprAtom = function(refDestructuringErrors, forInit) {
		// If a division operator appears in an expression position, the
		// tokenizer got confused, and we force it to read a regexp instead.
		if (this.type === types$1.slash) { this.readRegexp(); }

		var node, canBeArrow = this.potentialArrowAt === this.start;
		switch (this.type) {
		case types$1._super:
			if (!this.allowSuper)
				{ this.raise(this.start, "'super' keyword outside a method"); }
			node = this.startNode();
			this.next();
			if (this.type === types$1.parenL && !this.allowDirectSuper)
				{ this.raise(node.start, "super() call outside constructor of a subclass"); }
			// The `super` keyword can appear at below:
			// SuperProperty:
			//     super [ Expression ]
			//     super . IdentifierName
			// SuperCall:
			//     super ( Arguments )
			if (this.type !== types$1.dot && this.type !== types$1.bracketL && this.type !== types$1.parenL)
				{ this.unexpected(); }
			return this.finishNode(node, "Super")

		case types$1._this:
			node = this.startNode();
			this.next();
			return this.finishNode(node, "ThisExpression")

		case types$1.name:
			var startPos = this.start, startLoc = this.startLoc, containsEsc = this.containsEsc;
			var id = this.parseIdent(false);
			if (this.options.ecmaVersion >= 8 && !containsEsc && id.name === "async" && !this.canInsertSemicolon() && this.eat(types$1._function)) {
				this.overrideContext(types.f_expr);
				return this.parseFunction(this.startNodeAt(startPos, startLoc), 0, false, true, forInit)
			}
			if (canBeArrow && !this.canInsertSemicolon()) {
				if (this.eat(types$1.arrow))
					{ return this.parseArrowExpression(this.startNodeAt(startPos, startLoc), [id], false, forInit) }
				if (this.options.ecmaVersion >= 8 && id.name === "async" && this.type === types$1.name && !containsEsc &&
						(!this.potentialArrowInForAwait || this.value !== "of" || this.containsEsc)) {
					id = this.parseIdent(false);
					if (this.canInsertSemicolon() || !this.eat(types$1.arrow))
						{ this.unexpected(); }
					return this.parseArrowExpression(this.startNodeAt(startPos, startLoc), [id], true, forInit)
				}
			}
			return id

		case types$1.regexp:
			var value = this.value;
			node = this.parseLiteral(value.value);
			node.regex = {pattern: value.pattern, flags: value.flags};
			return node

		case types$1.num: case types$1.string:
			return this.parseLiteral(this.value)

		case types$1._null: case types$1._true: case types$1._false:
			node = this.startNode();
			node.value = this.type === types$1._null ? null : this.type === types$1._true;
			node.raw = this.type.keyword;
			this.next();
			return this.finishNode(node, "Literal")

		case types$1.parenL:
			var start = this.start, expr = this.parseParenAndDistinguishExpression(canBeArrow, forInit);
			if (refDestructuringErrors) {
				if (refDestructuringErrors.parenthesizedAssign < 0 && !this.isSimpleAssignTarget(expr))
					{ refDestructuringErrors.parenthesizedAssign = start; }
				if (refDestructuringErrors.parenthesizedBind < 0)
					{ refDestructuringErrors.parenthesizedBind = start; }
			}
			return expr

		case types$1.bracketL:
			node = this.startNode();
			this.next();
			node.elements = this.parseExprList(types$1.bracketR, true, true, refDestructuringErrors);
			return this.finishNode(node, "ArrayExpression")

		case types$1.braceL:
			this.overrideContext(types.b_expr);
			return this.parseObj(false, refDestructuringErrors)

		case types$1._function:
			node = this.startNode();
			this.next();
			return this.parseFunction(node, 0)

		case types$1._class:
			return this.parseClass(this.startNode(), false)

		case types$1._new:
			return this.parseNew()

		case types$1.backQuote:
			return this.parseTemplate()

		case types$1._import:
			if (this.options.ecmaVersion >= 11) {
				return this.parseExprImport()
			} else {
				return this.unexpected()
			}

		default:
			this.unexpected();
		}
	};

	pp$5.parseExprImport = function() {
		var node = this.startNode();

		// Consume `import` as an identifier for `import.meta`.
		// Because `this.parseIdent(true)` doesn't check escape sequences, it needs the check of `this.containsEsc`.
		if (this.containsEsc) { this.raiseRecoverable(this.start, "Escape sequence in keyword import"); }
		var meta = this.parseIdent(true);

		switch (this.type) {
		case types$1.parenL:
			return this.parseDynamicImport(node)
		case types$1.dot:
			node.meta = meta;
			return this.parseImportMeta(node)
		default:
			this.unexpected();
		}
	};

	pp$5.parseDynamicImport = function(node) {
		this.next(); // skip `(`

		// Parse node.source.
		node.source = this.parseMaybeAssign();

		// Verify ending.
		if (!this.eat(types$1.parenR)) {
			var errorPos = this.start;
			if (this.eat(types$1.comma) && this.eat(types$1.parenR)) {
				this.raiseRecoverable(errorPos, "Trailing comma is not allowed in import()");
			} else {
				this.unexpected(errorPos);
			}
		}

		return this.finishNode(node, "ImportExpression")
	};

	pp$5.parseImportMeta = function(node) {
		this.next(); // skip `.`

		var containsEsc = this.containsEsc;
		node.property = this.parseIdent(true);

		if (node.property.name !== "meta")
			{ this.raiseRecoverable(node.property.start, "The only valid meta property for import is 'import.meta'"); }
		if (containsEsc)
			{ this.raiseRecoverable(node.start, "'import.meta' must not contain escaped characters"); }
		if (this.options.sourceType !== "module" && !this.options.allowImportExportEverywhere)
			{ this.raiseRecoverable(node.start, "Cannot use 'import.meta' outside a module"); }

		return this.finishNode(node, "MetaProperty")
	};

	pp$5.parseLiteral = function(value) {
		var node = this.startNode();
		node.value = value;
		node.raw = this.input.slice(this.start, this.end);
		if (node.raw.charCodeAt(node.raw.length - 1) === 110) { node.bigint = node.raw.slice(0, -1).replace(/_/g, ""); }
		this.next();
		return this.finishNode(node, "Literal")
	};

	pp$5.parseParenExpression = function() {
		this.expect(types$1.parenL);
		var val = this.parseExpression();
		this.expect(types$1.parenR);
		return val
	};

	pp$5.parseParenAndDistinguishExpression = function(canBeArrow, forInit) {
		var startPos = this.start, startLoc = this.startLoc, val, allowTrailingComma = this.options.ecmaVersion >= 8;
		if (this.options.ecmaVersion >= 6) {
			this.next();

			var innerStartPos = this.start, innerStartLoc = this.startLoc;
			var exprList = [], first = true, lastIsComma = false;
			var refDestructuringErrors = new DestructuringErrors, oldYieldPos = this.yieldPos, oldAwaitPos = this.awaitPos, spreadStart;
			this.yieldPos = 0;
			this.awaitPos = 0;
			// Do not save awaitIdentPos to allow checking awaits nested in parameters
			while (this.type !== types$1.parenR) {
				first ? first = false : this.expect(types$1.comma);
				if (allowTrailingComma && this.afterTrailingComma(types$1.parenR, true)) {
					lastIsComma = true;
					break
				} else if (this.type === types$1.ellipsis) {
					spreadStart = this.start;
					exprList.push(this.parseParenItem(this.parseRestBinding()));
					if (this.type === types$1.comma) { this.raise(this.start, "Comma is not permitted after the rest element"); }
					break
				} else {
					exprList.push(this.parseMaybeAssign(false, refDestructuringErrors, this.parseParenItem));
				}
			}
			var innerEndPos = this.lastTokEnd, innerEndLoc = this.lastTokEndLoc;
			this.expect(types$1.parenR);

			if (canBeArrow && !this.canInsertSemicolon() && this.eat(types$1.arrow)) {
				this.checkPatternErrors(refDestructuringErrors, false);
				this.checkYieldAwaitInDefaultParams();
				this.yieldPos = oldYieldPos;
				this.awaitPos = oldAwaitPos;
				return this.parseParenArrowList(startPos, startLoc, exprList, forInit)
			}

			if (!exprList.length || lastIsComma) { this.unexpected(this.lastTokStart); }
			if (spreadStart) { this.unexpected(spreadStart); }
			this.checkExpressionErrors(refDestructuringErrors, true);
			this.yieldPos = oldYieldPos || this.yieldPos;
			this.awaitPos = oldAwaitPos || this.awaitPos;

			if (exprList.length > 1) {
				val = this.startNodeAt(innerStartPos, innerStartLoc);
				val.expressions = exprList;
				this.finishNodeAt(val, "SequenceExpression", innerEndPos, innerEndLoc);
			} else {
				val = exprList[0];
			}
		} else {
			val = this.parseParenExpression();
		}

		if (this.options.preserveParens) {
			var par = this.startNodeAt(startPos, startLoc);
			par.expression = val;
			return this.finishNode(par, "ParenthesizedExpression")
		} else {
			return val
		}
	};

	pp$5.parseParenItem = function(item) {
		return item
	};

	pp$5.parseParenArrowList = function(startPos, startLoc, exprList, forInit) {
		return this.parseArrowExpression(this.startNodeAt(startPos, startLoc), exprList, false, forInit)
	};

	// New's precedence is slightly tricky. It must allow its argument to
	// be a `[]` or dot subscript expression, but not a call — at least,
	// not without wrapping it in parentheses. Thus, it uses the noCalls
	// argument to parseSubscripts to prevent it from consuming the
	// argument list.

	var empty = [];

	pp$5.parseNew = function() {
		if (this.containsEsc) { this.raiseRecoverable(this.start, "Escape sequence in keyword new"); }
		var node = this.startNode();
		var meta = this.parseIdent(true);
		if (this.options.ecmaVersion >= 6 && this.eat(types$1.dot)) {
			node.meta = meta;
			var containsEsc = this.containsEsc;
			node.property = this.parseIdent(true);
			if (node.property.name !== "target")
				{ this.raiseRecoverable(node.property.start, "The only valid meta property for new is 'new.target'"); }
			if (containsEsc)
				{ this.raiseRecoverable(node.start, "'new.target' must not contain escaped characters"); }
			if (!this.allowNewDotTarget)
				{ this.raiseRecoverable(node.start, "'new.target' can only be used in functions and class static block"); }
			return this.finishNode(node, "MetaProperty")
		}
		var startPos = this.start, startLoc = this.startLoc, isImport = this.type === types$1._import;
		node.callee = this.parseSubscripts(this.parseExprAtom(), startPos, startLoc, true, false);
		if (isImport && node.callee.type === "ImportExpression") {
			this.raise(startPos, "Cannot use new with import()");
		}
		if (this.eat(types$1.parenL)) { node.arguments = this.parseExprList(types$1.parenR, this.options.ecmaVersion >= 8, false); }
		else { node.arguments = empty; }
		return this.finishNode(node, "NewExpression")
	};

	// Parse template expression.

	pp$5.parseTemplateElement = function(ref) {
		var isTagged = ref.isTagged;

		var elem = this.startNode();
		if (this.type === types$1.invalidTemplate) {
			if (!isTagged) {
				this.raiseRecoverable(this.start, "Bad escape sequence in untagged template literal");
			}
			elem.value = {
				raw: this.value,
				cooked: null
			};
		} else {
			elem.value = {
				raw: this.input.slice(this.start, this.end).replace(/\r\n?/g, "\n"),
				cooked: this.value
			};
		}
		this.next();
		elem.tail = this.type === types$1.backQuote;
		return this.finishNode(elem, "TemplateElement")
	};

	pp$5.parseTemplate = function(ref) {
		if ( ref === void 0 ) ref = {};
		var isTagged = ref.isTagged; if ( isTagged === void 0 ) isTagged = false;

		var node = this.startNode();
		this.next();
		node.expressions = [];
		var curElt = this.parseTemplateElement({isTagged: isTagged});
		node.quasis = [curElt];
		while (!curElt.tail) {
			if (this.type === types$1.eof) { this.raise(this.pos, "Unterminated template literal"); }
			this.expect(types$1.dollarBraceL);
			node.expressions.push(this.parseExpression());
			this.expect(types$1.braceR);
			node.quasis.push(curElt = this.parseTemplateElement({isTagged: isTagged}));
		}
		this.next();
		return this.finishNode(node, "TemplateLiteral")
	};

	pp$5.isAsyncProp = function(prop) {
		return !prop.computed && prop.key.type === "Identifier" && prop.key.name === "async" &&
			(this.type === types$1.name || this.type === types$1.num || this.type === types$1.string || this.type === types$1.bracketL || this.type.keyword || (this.options.ecmaVersion >= 9 && this.type === types$1.star)) &&
			!lineBreak.test(this.input.slice(this.lastTokEnd, this.start))
	};

	// Parse an object literal or binding pattern.

	pp$5.parseObj = function(isPattern, refDestructuringErrors) {
		var node = this.startNode(), first = true, propHash = {};
		node.properties = [];
		this.next();
		while (!this.eat(types$1.braceR)) {
			if (!first) {
				this.expect(types$1.comma);
				if (this.options.ecmaVersion >= 5 && this.afterTrailingComma(types$1.braceR)) { break }
			} else { first = false; }

			var prop = this.parseProperty(isPattern, refDestructuringErrors);
			if (!isPattern) { this.checkPropClash(prop, propHash, refDestructuringErrors); }
			node.properties.push(prop);
		}
		return this.finishNode(node, isPattern ? "ObjectPattern" : "ObjectExpression")
	};

	pp$5.parseProperty = function(isPattern, refDestructuringErrors) {
		var prop = this.startNode(), isGenerator, isAsync, startPos, startLoc;
		if (this.options.ecmaVersion >= 9 && this.eat(types$1.ellipsis)) {
			if (isPattern) {
				prop.argument = this.parseIdent(false);
				if (this.type === types$1.comma) {
					this.raise(this.start, "Comma is not permitted after the rest element");
				}
				return this.finishNode(prop, "RestElement")
			}
			// To disallow parenthesized identifier via `this.toAssignable()`.
			if (this.type === types$1.parenL && refDestructuringErrors) {
				if (refDestructuringErrors.parenthesizedAssign < 0) {
					refDestructuringErrors.parenthesizedAssign = this.start;
				}
				if (refDestructuringErrors.parenthesizedBind < 0) {
					refDestructuringErrors.parenthesizedBind = this.start;
				}
			}
			// Parse argument.
			prop.argument = this.parseMaybeAssign(false, refDestructuringErrors);
			// To disallow trailing comma via `this.toAssignable()`.
			if (this.type === types$1.comma && refDestructuringErrors && refDestructuringErrors.trailingComma < 0) {
				refDestructuringErrors.trailingComma = this.start;
			}
			// Finish
			return this.finishNode(prop, "SpreadElement")
		}
		if (this.options.ecmaVersion >= 6) {
			prop.method = false;
			prop.shorthand = false;
			if (isPattern || refDestructuringErrors) {
				startPos = this.start;
				startLoc = this.startLoc;
			}
			if (!isPattern)
				{ isGenerator = this.eat(types$1.star); }
		}
		var containsEsc = this.containsEsc;
		this.parsePropertyName(prop);
		if (!isPattern && !containsEsc && this.options.ecmaVersion >= 8 && !isGenerator && this.isAsyncProp(prop)) {
			isAsync = true;
			isGenerator = this.options.ecmaVersion >= 9 && this.eat(types$1.star);
			this.parsePropertyName(prop, refDestructuringErrors);
		} else {
			isAsync = false;
		}
		this.parsePropertyValue(prop, isPattern, isGenerator, isAsync, startPos, startLoc, refDestructuringErrors, containsEsc);
		return this.finishNode(prop, "Property")
	};

	pp$5.parsePropertyValue = function(prop, isPattern, isGenerator, isAsync, startPos, startLoc, refDestructuringErrors, containsEsc) {
		if ((isGenerator || isAsync) && this.type === types$1.colon)
			{ this.unexpected(); }

		if (this.eat(types$1.colon)) {
			prop.value = isPattern ? this.parseMaybeDefault(this.start, this.startLoc) : this.parseMaybeAssign(false, refDestructuringErrors);
			prop.kind = "init";
		} else if (this.options.ecmaVersion >= 6 && this.type === types$1.parenL) {
			if (isPattern) { this.unexpected(); }
			prop.kind = "init";
			prop.method = true;
			prop.value = this.parseMethod(isGenerator, isAsync);
		} else if (!isPattern && !containsEsc &&
							this.options.ecmaVersion >= 5 && !prop.computed && prop.key.type === "Identifier" &&
							(prop.key.name === "get" || prop.key.name === "set") &&
							(this.type !== types$1.comma && this.type !== types$1.braceR && this.type !== types$1.eq)) {
			if (isGenerator || isAsync) { this.unexpected(); }
			prop.kind = prop.key.name;
			this.parsePropertyName(prop);
			prop.value = this.parseMethod(false);
			var paramCount = prop.kind === "get" ? 0 : 1;
			if (prop.value.params.length !== paramCount) {
				var start = prop.value.start;
				if (prop.kind === "get")
					{ this.raiseRecoverable(start, "getter should have no params"); }
				else
					{ this.raiseRecoverable(start, "setter should have exactly one param"); }
			} else {
				if (prop.kind === "set" && prop.value.params[0].type === "RestElement")
					{ this.raiseRecoverable(prop.value.params[0].start, "Setter cannot use rest params"); }
			}
		} else if (this.options.ecmaVersion >= 6 && !prop.computed && prop.key.type === "Identifier") {
			if (isGenerator || isAsync) { this.unexpected(); }
			this.checkUnreserved(prop.key);
			if (prop.key.name === "await" && !this.awaitIdentPos)
				{ this.awaitIdentPos = startPos; }
			prop.kind = "init";
			if (isPattern) {
				prop.value = this.parseMaybeDefault(startPos, startLoc, this.copyNode(prop.key));
			} else if (this.type === types$1.eq && refDestructuringErrors) {
				if (refDestructuringErrors.shorthandAssign < 0)
					{ refDestructuringErrors.shorthandAssign = this.start; }
				prop.value = this.parseMaybeDefault(startPos, startLoc, this.copyNode(prop.key));
			} else {
				prop.value = this.copyNode(prop.key);
			}
			prop.shorthand = true;
		} else { this.unexpected(); }
	};

	pp$5.parsePropertyName = function(prop) {
		if (this.options.ecmaVersion >= 6) {
			if (this.eat(types$1.bracketL)) {
				prop.computed = true;
				prop.key = this.parseMaybeAssign();
				this.expect(types$1.bracketR);
				return prop.key
			} else {
				prop.computed = false;
			}
		}
		return prop.key = this.type === types$1.num || this.type === types$1.string ? this.parseExprAtom() : this.parseIdent(this.options.allowReserved !== "never")
	};

	// Initialize empty function node.

	pp$5.initFunction = function(node) {
		node.id = null;
		if (this.options.ecmaVersion >= 6) { node.generator = node.expression = false; }
		if (this.options.ecmaVersion >= 8) { node.async = false; }
	};

	// Parse object or class method.

	pp$5.parseMethod = function(isGenerator, isAsync, allowDirectSuper) {
		var node = this.startNode(), oldYieldPos = this.yieldPos, oldAwaitPos = this.awaitPos, oldAwaitIdentPos = this.awaitIdentPos;

		this.initFunction(node);
		if (this.options.ecmaVersion >= 6)
			{ node.generator = isGenerator; }
		if (this.options.ecmaVersion >= 8)
			{ node.async = !!isAsync; }

		this.yieldPos = 0;
		this.awaitPos = 0;
		this.awaitIdentPos = 0;
		this.enterScope(functionFlags(isAsync, node.generator) | SCOPE_SUPER | (allowDirectSuper ? SCOPE_DIRECT_SUPER : 0));

		this.expect(types$1.parenL);
		node.params = this.parseBindingList(types$1.parenR, false, this.options.ecmaVersion >= 8);
		this.checkYieldAwaitInDefaultParams();
		this.parseFunctionBody(node, false, true, false);

		this.yieldPos = oldYieldPos;
		this.awaitPos = oldAwaitPos;
		this.awaitIdentPos = oldAwaitIdentPos;
		return this.finishNode(node, "FunctionExpression")
	};

	// Parse arrow function expression with given parameters.

	pp$5.parseArrowExpression = function(node, params, isAsync, forInit) {
		var oldYieldPos = this.yieldPos, oldAwaitPos = this.awaitPos, oldAwaitIdentPos = this.awaitIdentPos;

		this.enterScope(functionFlags(isAsync, false) | SCOPE_ARROW);
		this.initFunction(node);
		if (this.options.ecmaVersion >= 8) { node.async = !!isAsync; }

		this.yieldPos = 0;
		this.awaitPos = 0;
		this.awaitIdentPos = 0;

		node.params = this.toAssignableList(params, true);
		this.parseFunctionBody(node, true, false, forInit);

		this.yieldPos = oldYieldPos;
		this.awaitPos = oldAwaitPos;
		this.awaitIdentPos = oldAwaitIdentPos;
		return this.finishNode(node, "ArrowFunctionExpression")
	};

	// Parse function body and check parameters.

	pp$5.parseFunctionBody = function(node, isArrowFunction, isMethod, forInit) {
		var isExpression = isArrowFunction && this.type !== types$1.braceL;
		var oldStrict = this.strict, useStrict = false;

		if (isExpression) {
			node.body = this.parseMaybeAssign(forInit);
			node.expression = true;
			this.checkParams(node, false);
		} else {
			var nonSimple = this.options.ecmaVersion >= 7 && !this.isSimpleParamList(node.params);
			if (!oldStrict || nonSimple) {
				useStrict = this.strictDirective(this.end);
				// If this is a strict mode function, verify that argument names
				// are not repeated, and it does not try to bind the words `eval`
				// or `arguments`.
				if (useStrict && nonSimple)
					{ this.raiseRecoverable(node.start, "Illegal 'use strict' directive in function with non-simple parameter list"); }
			}
			// Start a new scope with regard to labels and the `inFunction`
			// flag (restore them to their old value afterwards).
			var oldLabels = this.labels;
			this.labels = [];
			if (useStrict) { this.strict = true; }

			// Add the params to varDeclaredNames to ensure that an error is thrown
			// if a let/const declaration in the function clashes with one of the params.
			this.checkParams(node, !oldStrict && !useStrict && !isArrowFunction && !isMethod && this.isSimpleParamList(node.params));
			// Ensure the function name isn't a forbidden identifier in strict mode, e.g. 'eval'
			if (this.strict && node.id) { this.checkLValSimple(node.id, BIND_OUTSIDE); }
			node.body = this.parseBlock(false, undefined, useStrict && !oldStrict);
			node.expression = false;
			this.adaptDirectivePrologue(node.body.body);
			this.labels = oldLabels;
		}
		this.exitScope();
	};

	pp$5.isSimpleParamList = function(params) {
		for (var i = 0, list = params; i < list.length; i += 1)
			{
			var param = list[i];

			if (param.type !== "Identifier") { return false
		} }
		return true
	};

	// Checks function params for various disallowed patterns such as using "eval"
	// or "arguments" and duplicate parameters.

	pp$5.checkParams = function(node, allowDuplicates) {
		var nameHash = Object.create(null);
		for (var i = 0, list = node.params; i < list.length; i += 1)
			{
			var param = list[i];

			this.checkLValInnerPattern(param, BIND_VAR, allowDuplicates ? null : nameHash);
		}
	};

	// Parses a comma-separated list of expressions, and returns them as
	// an array. `close` is the token type that ends the list, and
	// `allowEmpty` can be turned on to allow subsequent commas with
	// nothing in between them to be parsed as `null` (which is needed
	// for array literals).

	pp$5.parseExprList = function(close, allowTrailingComma, allowEmpty, refDestructuringErrors) {
		var elts = [], first = true;
		while (!this.eat(close)) {
			if (!first) {
				this.expect(types$1.comma);
				if (allowTrailingComma && this.afterTrailingComma(close)) { break }
			} else { first = false; }

			var elt = (void 0);
			if (allowEmpty && this.type === types$1.comma)
				{ elt = null; }
			else if (this.type === types$1.ellipsis) {
				elt = this.parseSpread(refDestructuringErrors);
				if (refDestructuringErrors && this.type === types$1.comma && refDestructuringErrors.trailingComma < 0)
					{ refDestructuringErrors.trailingComma = this.start; }
			} else {
				elt = this.parseMaybeAssign(false, refDestructuringErrors);
			}
			elts.push(elt);
		}
		return elts
	};

	pp$5.checkUnreserved = function(ref) {
		var start = ref.start;
		var end = ref.end;
		var name = ref.name;

		if (this.inGenerator && name === "yield")
			{ this.raiseRecoverable(start, "Cannot use 'yield' as identifier inside a generator"); }
		if (this.inAsync && name === "await")
			{ this.raiseRecoverable(start, "Cannot use 'await' as identifier inside an async function"); }
		if (this.currentThisScope().inClassFieldInit && name === "arguments")
			{ this.raiseRecoverable(start, "Cannot use 'arguments' in class field initializer"); }
		if (this.inClassStaticBlock && (name === "arguments" || name === "await"))
			{ this.raise(start, ("Cannot use " + name + " in class static initialization block")); }
		if (this.keywords.test(name))
			{ this.raise(start, ("Unexpected keyword '" + name + "'")); }
		if (this.options.ecmaVersion < 6 &&
			this.input.slice(start, end).indexOf("\\") !== -1) { return }
		var re = this.strict ? this.reservedWordsStrict : this.reservedWords;
		if (re.test(name)) {
			if (!this.inAsync && name === "await")
				{ this.raiseRecoverable(start, "Cannot use keyword 'await' outside an async function"); }
			this.raiseRecoverable(start, ("The keyword '" + name + "' is reserved"));
		}
	};

	// Parse the next token as an identifier. If `liberal` is true (used
	// when parsing properties), it will also convert keywords into
	// identifiers.

	pp$5.parseIdent = function(liberal, isBinding) {
		var node = this.startNode();
		if (this.type === types$1.name) {
			node.name = this.value;
		} else if (this.type.keyword) {
			node.name = this.type.keyword;

			// To fix https://github.com/acornjs/acorn/issues/575
			// `class` and `function` keywords push new context into this.context.
			// But there is no chance to pop the context if the keyword is consumed as an identifier such as a property name.
			// If the previous token is a dot, this does not apply because the context-managing code already ignored the keyword
			if ((node.name === "class" || node.name === "function") &&
					(this.lastTokEnd !== this.lastTokStart + 1 || this.input.charCodeAt(this.lastTokStart) !== 46)) {
				this.context.pop();
			}
		} else {
			this.unexpected();
		}
		this.next(!!liberal);
		this.finishNode(node, "Identifier");
		if (!liberal) {
			this.checkUnreserved(node);
			if (node.name === "await" && !this.awaitIdentPos)
				{ this.awaitIdentPos = node.start; }
		}
		return node
	};

	pp$5.parsePrivateIdent = function() {
		var node = this.startNode();
		if (this.type === types$1.privateId) {
			node.name = this.value;
		} else {
			this.unexpected();
		}
		this.next();
		this.finishNode(node, "PrivateIdentifier");

		// For validating existence
		if (this.privateNameStack.length === 0) {
			this.raise(node.start, ("Private field '#" + (node.name) + "' must be declared in an enclosing class"));
		} else {
			this.privateNameStack[this.privateNameStack.length - 1].used.push(node);
		}

		return node
	};

	// Parses yield expression inside generator.

	pp$5.parseYield = function(forInit) {
		if (!this.yieldPos) { this.yieldPos = this.start; }

		var node = this.startNode();
		this.next();
		if (this.type === types$1.semi || this.canInsertSemicolon() || (this.type !== types$1.star && !this.type.startsExpr)) {
			node.delegate = false;
			node.argument = null;
		} else {
			node.delegate = this.eat(types$1.star);
			node.argument = this.parseMaybeAssign(forInit);
		}
		return this.finishNode(node, "YieldExpression")
	};

	pp$5.parseAwait = function(forInit) {
		if (!this.awaitPos) { this.awaitPos = this.start; }

		var node = this.startNode();
		this.next();
		node.argument = this.parseMaybeUnary(null, true, false, forInit);
		return this.finishNode(node, "AwaitExpression")
	};

	var pp$4 = Parser.prototype;

	// This function is used to raise exceptions on parse errors. It
	// takes an offset integer (into the current `input`) to indicate
	// the location of the error, attaches the position to the end
	// of the error message, and then raises a `SyntaxError` with that
	// message.

	pp$4.raise = function(pos, message) {
		var loc = getLineInfo(this.input, pos);
		message += " (" + loc.line + ":" + loc.column + ")";
		var err = new SyntaxError(message);
		err.pos = pos; err.loc = loc; err.raisedAt = this.pos;
		throw err
	};

	pp$4.raiseRecoverable = pp$4.raise;

	pp$4.curPosition = function() {
		if (this.options.locations) {
			return new Position(this.curLine, this.pos - this.lineStart)
		}
	};

	var pp$3 = Parser.prototype;

	var Scope = function Scope(flags) {
		this.flags = flags;
		// A list of var-declared names in the current lexical scope
		this.var = [];
		// A list of lexically-declared names in the current lexical scope
		this.lexical = [];
		// A list of lexically-declared FunctionDeclaration names in the current lexical scope
		this.functions = [];
		// A switch to disallow the identifier reference 'arguments'
		this.inClassFieldInit = false;
	};

	// The functions in this module keep track of declared variables in the current scope in order to detect duplicate variable names.

	pp$3.enterScope = function(flags) {
		this.scopeStack.push(new Scope(flags));
	};

	pp$3.exitScope = function() {
		this.scopeStack.pop();
	};

	// The spec says:
	// > At the top level of a function, or script, function declarations are
	// > treated like var declarations rather than like lexical declarations.
	pp$3.treatFunctionsAsVarInScope = function(scope) {
		return (scope.flags & SCOPE_FUNCTION) || !this.inModule && (scope.flags & SCOPE_TOP)
	};

	pp$3.declareName = function(name, bindingType, pos) {
		var redeclared = false;
		if (bindingType === BIND_LEXICAL) {
			var scope = this.currentScope();
			redeclared = scope.lexical.indexOf(name) > -1 || scope.functions.indexOf(name) > -1 || scope.var.indexOf(name) > -1;
			scope.lexical.push(name);
			if (this.inModule && (scope.flags & SCOPE_TOP))
				{ delete this.undefinedExports[name]; }
		} else if (bindingType === BIND_SIMPLE_CATCH) {
			var scope$1 = this.currentScope();
			scope$1.lexical.push(name);
		} else if (bindingType === BIND_FUNCTION) {
			var scope$2 = this.currentScope();
			if (this.treatFunctionsAsVar)
				{ redeclared = scope$2.lexical.indexOf(name) > -1; }
			else
				{ redeclared = scope$2.lexical.indexOf(name) > -1 || scope$2.var.indexOf(name) > -1; }
			scope$2.functions.push(name);
		} else {
			for (var i = this.scopeStack.length - 1; i >= 0; --i) {
				var scope$3 = this.scopeStack[i];
				if (scope$3.lexical.indexOf(name) > -1 && !((scope$3.flags & SCOPE_SIMPLE_CATCH) && scope$3.lexical[0] === name) ||
						!this.treatFunctionsAsVarInScope(scope$3) && scope$3.functions.indexOf(name) > -1) {
					redeclared = true;
					break
				}
				scope$3.var.push(name);
				if (this.inModule && (scope$3.flags & SCOPE_TOP))
					{ delete this.undefinedExports[name]; }
				if (scope$3.flags & SCOPE_VAR) { break }
			}
		}
		if (redeclared) { this.raiseRecoverable(pos, ("Identifier '" + name + "' has already been declared")); }
	};

	pp$3.checkLocalExport = function(id) {
		// scope.functions must be empty as Module code is always strict.
		if (this.scopeStack[0].lexical.indexOf(id.name) === -1 &&
				this.scopeStack[0].var.indexOf(id.name) === -1) {
			this.undefinedExports[id.name] = id;
		}
	};

	pp$3.currentScope = function() {
		return this.scopeStack[this.scopeStack.length - 1]
	};

	pp$3.currentVarScope = function() {
		for (var i = this.scopeStack.length - 1;; i--) {
			var scope = this.scopeStack[i];
			if (scope.flags & SCOPE_VAR) { return scope }
		}
	};

	// Could be useful for `this`, `new.target`, `super()`, `super.property`, and `super[property]`.
	pp$3.currentThisScope = function() {
		for (var i = this.scopeStack.length - 1;; i--) {
			var scope = this.scopeStack[i];
			if (scope.flags & SCOPE_VAR && !(scope.flags & SCOPE_ARROW)) { return scope }
		}
	};

	var Node = function Node(parser, pos, loc) {
		this.type = "";
		this.start = pos;
		this.end = 0;
		if (parser.options.locations)
			{ this.loc = new SourceLocation(parser, loc); }
		if (parser.options.directSourceFile)
			{ this.sourceFile = parser.options.directSourceFile; }
		if (parser.options.ranges)
			{ this.range = [pos, 0]; }
	};

	// Start an AST node, attaching a start offset.

	var pp$2 = Parser.prototype;

	pp$2.startNode = function() {
		return new Node(this, this.start, this.startLoc)
	};

	pp$2.startNodeAt = function(pos, loc) {
		return new Node(this, pos, loc)
	};

	// Finish an AST node, adding `type` and `end` properties.

	function finishNodeAt(node, type, pos, loc) {
		node.type = type;
		node.end = pos;
		if (this.options.locations)
			{ node.loc.end = loc; }
		if (this.options.ranges)
			{ node.range[1] = pos; }
		return node
	}

	pp$2.finishNode = function(node, type) {
		return finishNodeAt.call(this, node, type, this.lastTokEnd, this.lastTokEndLoc)
	};

	// Finish node at given position

	pp$2.finishNodeAt = function(node, type, pos, loc) {
		return finishNodeAt.call(this, node, type, pos, loc)
	};

	pp$2.copyNode = function(node) {
		var newNode = new Node(this, node.start, this.startLoc);
		for (var prop in node) { newNode[prop] = node[prop]; }
		return newNode
	};

	// This file contains Unicode properties extracted from the ECMAScript
	// specification. The lists are extracted like so:
	// $$('#table-binary-unicode-properties > figure > table > tbody > tr > td:nth-child(1) code').map(el => el.innerText)

	// #table-binary-unicode-properties
	var ecma9BinaryProperties = "ASCII ASCII_Hex_Digit AHex Alphabetic Alpha Any Assigned Bidi_Control Bidi_C Bidi_Mirrored Bidi_M Case_Ignorable CI Cased Changes_When_Casefolded CWCF Changes_When_Casemapped CWCM Changes_When_Lowercased CWL Changes_When_NFKC_Casefolded CWKCF Changes_When_Titlecased CWT Changes_When_Uppercased CWU Dash Default_Ignorable_Code_Point DI Deprecated Dep Diacritic Dia Emoji Emoji_Component Emoji_Modifier Emoji_Modifier_Base Emoji_Presentation Extender Ext Grapheme_Base Gr_Base Grapheme_Extend Gr_Ext Hex_Digit Hex IDS_Binary_Operator IDSB IDS_Trinary_Operator IDST ID_Continue IDC ID_Start IDS Ideographic Ideo Join_Control Join_C Logical_Order_Exception LOE Lowercase Lower Math Noncharacter_Code_Point NChar Pattern_Syntax Pat_Syn Pattern_White_Space Pat_WS Quotation_Mark QMark Radical Regional_Indicator RI Sentence_Terminal STerm Soft_Dotted SD Terminal_Punctuation Term Unified_Ideograph UIdeo Uppercase Upper Variation_Selector VS White_Space space XID_Continue XIDC XID_Start XIDS";
	var ecma10BinaryProperties = ecma9BinaryProperties + " Extended_Pictographic";
	var ecma11BinaryProperties = ecma10BinaryProperties;
	var ecma12BinaryProperties = ecma11BinaryProperties + " EBase EComp EMod EPres ExtPict";
	var ecma13BinaryProperties = ecma12BinaryProperties;
	var unicodeBinaryProperties = {
		9: ecma9BinaryProperties,
		10: ecma10BinaryProperties,
		11: ecma11BinaryProperties,
		12: ecma12BinaryProperties,
		13: ecma13BinaryProperties
	};

	// #table-unicode-general-category-values
	var unicodeGeneralCategoryValues = "Cased_Letter LC Close_Punctuation Pe Connector_Punctuation Pc Control Cc cntrl Currency_Symbol Sc Dash_Punctuation Pd Decimal_Number Nd digit Enclosing_Mark Me Final_Punctuation Pf Format Cf Initial_Punctuation Pi Letter L Letter_Number Nl Line_Separator Zl Lowercase_Letter Ll Mark M Combining_Mark Math_Symbol Sm Modifier_Letter Lm Modifier_Symbol Sk Nonspacing_Mark Mn Number N Open_Punctuation Ps Other C Other_Letter Lo Other_Number No Other_Punctuation Po Other_Symbol So Paragraph_Separator Zp Private_Use Co Punctuation P punct Separator Z Space_Separator Zs Spacing_Mark Mc Surrogate Cs Symbol S Titlecase_Letter Lt Unassigned Cn Uppercase_Letter Lu";

	// #table-unicode-script-values
	var ecma9ScriptValues = "Adlam Adlm Ahom Anatolian_Hieroglyphs Hluw Arabic Arab Armenian Armn Avestan Avst Balinese Bali Bamum Bamu Bassa_Vah Bass Batak Batk Bengali Beng Bhaiksuki Bhks Bopomofo Bopo Brahmi Brah Braille Brai Buginese Bugi Buhid Buhd Canadian_Aboriginal Cans Carian Cari Caucasian_Albanian Aghb Chakma Cakm Cham Cham Cherokee Cher Common Zyyy Coptic Copt Qaac Cuneiform Xsux Cypriot Cprt Cyrillic Cyrl Deseret Dsrt Devanagari Deva Duployan Dupl Egyptian_Hieroglyphs Egyp Elbasan Elba Ethiopic Ethi Georgian Geor Glagolitic Glag Gothic Goth Grantha Gran Greek Grek Gujarati Gujr Gurmukhi Guru Han Hani Hangul Hang Hanunoo Hano Hatran Hatr Hebrew Hebr Hiragana Hira Imperial_Aramaic Armi Inherited Zinh Qaai Inscriptional_Pahlavi Phli Inscriptional_Parthian Prti Javanese Java Kaithi Kthi Kannada Knda Katakana Kana Kayah_Li Kali Kharoshthi Khar Khmer Khmr Khojki Khoj Khudawadi Sind Lao Laoo Latin Latn Lepcha Lepc Limbu Limb Linear_A Lina Linear_B Linb Lisu Lisu Lycian Lyci Lydian Lydi Mahajani Mahj Malayalam Mlym Mandaic Mand Manichaean Mani Marchen Marc Masaram_Gondi Gonm Meetei_Mayek Mtei Mende_Kikakui Mend Meroitic_Cursive Merc Meroitic_Hieroglyphs Mero Miao Plrd Modi Mongolian Mong Mro Mroo Multani Mult Myanmar Mymr Nabataean Nbat New_Tai_Lue Talu Newa Newa Nko Nkoo Nushu Nshu Ogham Ogam Ol_Chiki Olck Old_Hungarian Hung Old_Italic Ital Old_North_Arabian Narb Old_Permic Perm Old_Persian Xpeo Old_South_Arabian Sarb Old_Turkic Orkh Oriya Orya Osage Osge Osmanya Osma Pahawh_Hmong Hmng Palmyrene Palm Pau_Cin_Hau Pauc Phags_Pa Phag Phoenician Phnx Psalter_Pahlavi Phlp Rejang Rjng Runic Runr Samaritan Samr Saurashtra Saur Sharada Shrd Shavian Shaw Siddham Sidd SignWriting Sgnw Sinhala Sinh Sora_Sompeng Sora Soyombo Soyo Sundanese Sund Syloti_Nagri Sylo Syriac Syrc Tagalog Tglg Tagbanwa Tagb Tai_Le Tale Tai_Tham Lana Tai_Viet Tavt Takri Takr Tamil Taml Tangut Tang Telugu Telu Thaana Thaa Thai Thai Tibetan Tibt Tifinagh Tfng Tirhuta Tirh Ugaritic Ugar Vai Vaii Warang_Citi Wara Yi Yiii Zanabazar_Square Zanb";
	var ecma10ScriptValues = ecma9ScriptValues + " Dogra Dogr Gunjala_Gondi Gong Hanifi_Rohingya Rohg Makasar Maka Medefaidrin Medf Old_Sogdian Sogo Sogdian Sogd";
	var ecma11ScriptValues = ecma10ScriptValues + " Elymaic Elym Nandinagari Nand Nyiakeng_Puachue_Hmong Hmnp Wancho Wcho";
	var ecma12ScriptValues = ecma11ScriptValues + " Chorasmian Chrs Diak Dives_Akuru Khitan_Small_Script Kits Yezi Yezidi";
	var ecma13ScriptValues = ecma12ScriptValues + " Cypro_Minoan Cpmn Old_Uyghur Ougr Tangsa Tnsa Toto Vithkuqi Vith";
	var unicodeScriptValues = {
		9: ecma9ScriptValues,
		10: ecma10ScriptValues,
		11: ecma11ScriptValues,
		12: ecma12ScriptValues,
		13: ecma13ScriptValues
	};

	var data = {};
	function buildUnicodeData(ecmaVersion) {
		var d = data[ecmaVersion] = {
			binary: wordsRegexp(unicodeBinaryProperties[ecmaVersion] + " " + unicodeGeneralCategoryValues),
			nonBinary: {
				General_Category: wordsRegexp(unicodeGeneralCategoryValues),
				Script: wordsRegexp(unicodeScriptValues[ecmaVersion])
			}
		};
		d.nonBinary.Script_Extensions = d.nonBinary.Script;

		d.nonBinary.gc = d.nonBinary.General_Category;
		d.nonBinary.sc = d.nonBinary.Script;
		d.nonBinary.scx = d.nonBinary.Script_Extensions;
	}

	for (var i = 0, list = [9, 10, 11, 12, 13]; i < list.length; i += 1) {
		var ecmaVersion = list[i];

		buildUnicodeData(ecmaVersion);
	}

	var pp$1 = Parser.prototype;

	var RegExpValidationState = function RegExpValidationState(parser) {
		this.parser = parser;
		this.validFlags = "gim" + (parser.options.ecmaVersion >= 6 ? "uy" : "") + (parser.options.ecmaVersion >= 9 ? "s" : "") + (parser.options.ecmaVersion >= 13 ? "d" : "");
		this.unicodeProperties = data[parser.options.ecmaVersion >= 13 ? 13 : parser.options.ecmaVersion];
		this.source = "";
		this.flags = "";
		this.start = 0;
		this.switchU = false;
		this.switchN = false;
		this.pos = 0;
		this.lastIntValue = 0;
		this.lastStringValue = "";
		this.lastAssertionIsQuantifiable = false;
		this.numCapturingParens = 0;
		this.maxBackReference = 0;
		this.groupNames = [];
		this.backReferenceNames = [];
	};

	RegExpValidationState.prototype.reset = function reset (start, pattern, flags) {
		var unicode = flags.indexOf("u") !== -1;
		this.start = start | 0;
		this.source = pattern + "";
		this.flags = flags;
		this.switchU = unicode && this.parser.options.ecmaVersion >= 6;
		this.switchN = unicode && this.parser.options.ecmaVersion >= 9;
	};

	RegExpValidationState.prototype.raise = function raise (message) {
		this.parser.raiseRecoverable(this.start, ("Invalid regular expression: /" + (this.source) + "/: " + message));
	};

	// If u flag is given, this returns the code point at the index (it combines a surrogate pair).
	// Otherwise, this returns the code unit of the index (can be a part of a surrogate pair).
	RegExpValidationState.prototype.at = function at (i, forceU) {
			if ( forceU === void 0 ) forceU = false;

		var s = this.source;
		var l = s.length;
		if (i >= l) {
			return -1
		}
		var c = s.charCodeAt(i);
		if (!(forceU || this.switchU) || c <= 0xD7FF || c >= 0xE000 || i + 1 >= l) {
			return c
		}
		var next = s.charCodeAt(i + 1);
		return next >= 0xDC00 && next <= 0xDFFF ? (c << 10) + next - 0x35FDC00 : c
	};

	RegExpValidationState.prototype.nextIndex = function nextIndex (i, forceU) {
			if ( forceU === void 0 ) forceU = false;

		var s = this.source;
		var l = s.length;
		if (i >= l) {
			return l
		}
		var c = s.charCodeAt(i), next;
		if (!(forceU || this.switchU) || c <= 0xD7FF || c >= 0xE000 || i + 1 >= l ||
				(next = s.charCodeAt(i + 1)) < 0xDC00 || next > 0xDFFF) {
			return i + 1
		}
		return i + 2
	};

	RegExpValidationState.prototype.current = function current (forceU) {
			if ( forceU === void 0 ) forceU = false;

		return this.at(this.pos, forceU)
	};

	RegExpValidationState.prototype.lookahead = function lookahead (forceU) {
			if ( forceU === void 0 ) forceU = false;

		return this.at(this.nextIndex(this.pos, forceU), forceU)
	};

	RegExpValidationState.prototype.advance = function advance (forceU) {
			if ( forceU === void 0 ) forceU = false;

		this.pos = this.nextIndex(this.pos, forceU);
	};

	RegExpValidationState.prototype.eat = function eat (ch, forceU) {
			if ( forceU === void 0 ) forceU = false;

		if (this.current(forceU) === ch) {
			this.advance(forceU);
			return true
		}
		return false
	};

	function codePointToString$1(ch) {
		if (ch <= 0xFFFF) { return String.fromCharCode(ch) }
		ch -= 0x10000;
		return String.fromCharCode((ch >> 10) + 0xD800, (ch & 0x03FF) + 0xDC00)
	}

	/**
		* Validate the flags part of a given RegExpLiteral.
		*
		* @param {RegExpValidationState} state The state to validate RegExp.
		* @returns {void}
		*/
	pp$1.validateRegExpFlags = function(state) {
		var validFlags = state.validFlags;
		var flags = state.flags;

		for (var i = 0; i < flags.length; i++) {
			var flag = flags.charAt(i);
			if (validFlags.indexOf(flag) === -1) {
				this.raise(state.start, "Invalid regular expression flag");
			}
			if (flags.indexOf(flag, i + 1) > -1) {
				this.raise(state.start, "Duplicate regular expression flag");
			}
		}
	};

	/**
		* Validate the pattern part of a given RegExpLiteral.
		*
		* @param {RegExpValidationState} state The state to validate RegExp.
		* @returns {void}
		*/
	pp$1.validateRegExpPattern = function(state) {
		this.regexp_pattern(state);

		// The goal symbol for the parse is |Pattern[~U, ~N]|. If the result of
		// parsing contains a |GroupName|, reparse with the goal symbol
		// |Pattern[~U, +N]| and use this result instead. Throw a *SyntaxError*
		// exception if _P_ did not conform to the grammar, if any elements of _P_
		// were not matched by the parse, or if any Early Error conditions exist.
		if (!state.switchN && this.options.ecmaVersion >= 9 && state.groupNames.length > 0) {
			state.switchN = true;
			this.regexp_pattern(state);
		}
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-Pattern
	pp$1.regexp_pattern = function(state) {
		state.pos = 0;
		state.lastIntValue = 0;
		state.lastStringValue = "";
		state.lastAssertionIsQuantifiable = false;
		state.numCapturingParens = 0;
		state.maxBackReference = 0;
		state.groupNames.length = 0;
		state.backReferenceNames.length = 0;

		this.regexp_disjunction(state);

		if (state.pos !== state.source.length) {
			// Make the same messages as V8.
			if (state.eat(0x29 /* ) */)) {
				state.raise("Unmatched ')'");
			}
			if (state.eat(0x5D /* ] */) || state.eat(0x7D /* } */)) {
				state.raise("Lone quantifier brackets");
			}
		}
		if (state.maxBackReference > state.numCapturingParens) {
			state.raise("Invalid escape");
		}
		for (var i = 0, list = state.backReferenceNames; i < list.length; i += 1) {
			var name = list[i];

			if (state.groupNames.indexOf(name) === -1) {
				state.raise("Invalid named capture referenced");
			}
		}
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-Disjunction
	pp$1.regexp_disjunction = function(state) {
		this.regexp_alternative(state);
		while (state.eat(0x7C /* | */)) {
			this.regexp_alternative(state);
		}

		// Make the same message as V8.
		if (this.regexp_eatQuantifier(state, true)) {
			state.raise("Nothing to repeat");
		}
		if (state.eat(0x7B /* { */)) {
			state.raise("Lone quantifier brackets");
		}
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-Alternative
	pp$1.regexp_alternative = function(state) {
		while (state.pos < state.source.length && this.regexp_eatTerm(state))
			{ }
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-annexB-Term
	pp$1.regexp_eatTerm = function(state) {
		if (this.regexp_eatAssertion(state)) {
			// Handle `QuantifiableAssertion Quantifier` alternative.
			// `state.lastAssertionIsQuantifiable` is true if the last eaten Assertion
			// is a QuantifiableAssertion.
			if (state.lastAssertionIsQuantifiable && this.regexp_eatQuantifier(state)) {
				// Make the same message as V8.
				if (state.switchU) {
					state.raise("Invalid quantifier");
				}
			}
			return true
		}

		if (state.switchU ? this.regexp_eatAtom(state) : this.regexp_eatExtendedAtom(state)) {
			this.regexp_eatQuantifier(state);
			return true
		}

		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-annexB-Assertion
	pp$1.regexp_eatAssertion = function(state) {
		var start = state.pos;
		state.lastAssertionIsQuantifiable = false;

		// ^, $
		if (state.eat(0x5E /* ^ */) || state.eat(0x24 /* $ */)) {
			return true
		}

		// \b \B
		if (state.eat(0x5C /* \ */)) {
			if (state.eat(0x42 /* B */) || state.eat(0x62 /* b */)) {
				return true
			}
			state.pos = start;
		}

		// Lookahead / Lookbehind
		if (state.eat(0x28 /* ( */) && state.eat(0x3F /* ? */)) {
			var lookbehind = false;
			if (this.options.ecmaVersion >= 9) {
				lookbehind = state.eat(0x3C /* < */);
			}
			if (state.eat(0x3D /* = */) || state.eat(0x21 /* ! */)) {
				this.regexp_disjunction(state);
				if (!state.eat(0x29 /* ) */)) {
					state.raise("Unterminated group");
				}
				state.lastAssertionIsQuantifiable = !lookbehind;
				return true
			}
		}

		state.pos = start;
		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-Quantifier
	pp$1.regexp_eatQuantifier = function(state, noError) {
		if ( noError === void 0 ) noError = false;

		if (this.regexp_eatQuantifierPrefix(state, noError)) {
			state.eat(0x3F /* ? */);
			return true
		}
		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-QuantifierPrefix
	pp$1.regexp_eatQuantifierPrefix = function(state, noError) {
		return (
			state.eat(0x2A /* * */) ||
			state.eat(0x2B /* + */) ||
			state.eat(0x3F /* ? */) ||
			this.regexp_eatBracedQuantifier(state, noError)
		)
	};
	pp$1.regexp_eatBracedQuantifier = function(state, noError) {
		var start = state.pos;
		if (state.eat(0x7B /* { */)) {
			var min = 0, max = -1;
			if (this.regexp_eatDecimalDigits(state)) {
				min = state.lastIntValue;
				if (state.eat(0x2C /* , */) && this.regexp_eatDecimalDigits(state)) {
					max = state.lastIntValue;
				}
				if (state.eat(0x7D /* } */)) {
					// SyntaxError in https://www.ecma-international.org/ecma-262/8.0/#sec-term
					if (max !== -1 && max < min && !noError) {
						state.raise("numbers out of order in {} quantifier");
					}
					return true
				}
			}
			if (state.switchU && !noError) {
				state.raise("Incomplete quantifier");
			}
			state.pos = start;
		}
		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-Atom
	pp$1.regexp_eatAtom = function(state) {
		return (
			this.regexp_eatPatternCharacters(state) ||
			state.eat(0x2E /* . */) ||
			this.regexp_eatReverseSolidusAtomEscape(state) ||
			this.regexp_eatCharacterClass(state) ||
			this.regexp_eatUncapturingGroup(state) ||
			this.regexp_eatCapturingGroup(state)
		)
	};
	pp$1.regexp_eatReverseSolidusAtomEscape = function(state) {
		var start = state.pos;
		if (state.eat(0x5C /* \ */)) {
			if (this.regexp_eatAtomEscape(state)) {
				return true
			}
			state.pos = start;
		}
		return false
	};
	pp$1.regexp_eatUncapturingGroup = function(state) {
		var start = state.pos;
		if (state.eat(0x28 /* ( */)) {
			if (state.eat(0x3F /* ? */) && state.eat(0x3A /* : */)) {
				this.regexp_disjunction(state);
				if (state.eat(0x29 /* ) */)) {
					return true
				}
				state.raise("Unterminated group");
			}
			state.pos = start;
		}
		return false
	};
	pp$1.regexp_eatCapturingGroup = function(state) {
		if (state.eat(0x28 /* ( */)) {
			if (this.options.ecmaVersion >= 9) {
				this.regexp_groupSpecifier(state);
			} else if (state.current() === 0x3F /* ? */) {
				state.raise("Invalid group");
			}
			this.regexp_disjunction(state);
			if (state.eat(0x29 /* ) */)) {
				state.numCapturingParens += 1;
				return true
			}
			state.raise("Unterminated group");
		}
		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-annexB-ExtendedAtom
	pp$1.regexp_eatExtendedAtom = function(state) {
		return (
			state.eat(0x2E /* . */) ||
			this.regexp_eatReverseSolidusAtomEscape(state) ||
			this.regexp_eatCharacterClass(state) ||
			this.regexp_eatUncapturingGroup(state) ||
			this.regexp_eatCapturingGroup(state) ||
			this.regexp_eatInvalidBracedQuantifier(state) ||
			this.regexp_eatExtendedPatternCharacter(state)
		)
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-annexB-InvalidBracedQuantifier
	pp$1.regexp_eatInvalidBracedQuantifier = function(state) {
		if (this.regexp_eatBracedQuantifier(state, true)) {
			state.raise("Nothing to repeat");
		}
		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-SyntaxCharacter
	pp$1.regexp_eatSyntaxCharacter = function(state) {
		var ch = state.current();
		if (isSyntaxCharacter(ch)) {
			state.lastIntValue = ch;
			state.advance();
			return true
		}
		return false
	};
	function isSyntaxCharacter(ch) {
		return (
			ch === 0x24 /* $ */ ||
			ch >= 0x28 /* ( */ && ch <= 0x2B /* + */ ||
			ch === 0x2E /* . */ ||
			ch === 0x3F /* ? */ ||
			ch >= 0x5B /* [ */ && ch <= 0x5E /* ^ */ ||
			ch >= 0x7B /* { */ && ch <= 0x7D /* } */
		)
	}

	// https://www.ecma-international.org/ecma-262/8.0/#prod-PatternCharacter
	// But eat eager.
	pp$1.regexp_eatPatternCharacters = function(state) {
		var start = state.pos;
		var ch = 0;
		while ((ch = state.current()) !== -1 && !isSyntaxCharacter(ch)) {
			state.advance();
		}
		return state.pos !== start
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-annexB-ExtendedPatternCharacter
	pp$1.regexp_eatExtendedPatternCharacter = function(state) {
		var ch = state.current();
		if (
			ch !== -1 &&
			ch !== 0x24 /* $ */ &&
			!(ch >= 0x28 /* ( */ && ch <= 0x2B /* + */) &&
			ch !== 0x2E /* . */ &&
			ch !== 0x3F /* ? */ &&
			ch !== 0x5B /* [ */ &&
			ch !== 0x5E /* ^ */ &&
			ch !== 0x7C /* | */
		) {
			state.advance();
			return true
		}
		return false
	};

	// GroupSpecifier ::
	//   [empty]
	//   `?` GroupName
	pp$1.regexp_groupSpecifier = function(state) {
		if (state.eat(0x3F /* ? */)) {
			if (this.regexp_eatGroupName(state)) {
				if (state.groupNames.indexOf(state.lastStringValue) !== -1) {
					state.raise("Duplicate capture group name");
				}
				state.groupNames.push(state.lastStringValue);
				return
			}
			state.raise("Invalid group");
		}
	};

	// GroupName ::
	//   `<` RegExpIdentifierName `>`
	// Note: this updates `state.lastStringValue` property with the eaten name.
	pp$1.regexp_eatGroupName = function(state) {
		state.lastStringValue = "";
		if (state.eat(0x3C /* < */)) {
			if (this.regexp_eatRegExpIdentifierName(state) && state.eat(0x3E /* > */)) {
				return true
			}
			state.raise("Invalid capture group name");
		}
		return false
	};

	// RegExpIdentifierName ::
	//   RegExpIdentifierStart
	//   RegExpIdentifierName RegExpIdentifierPart
	// Note: this updates `state.lastStringValue` property with the eaten name.
	pp$1.regexp_eatRegExpIdentifierName = function(state) {
		state.lastStringValue = "";
		if (this.regexp_eatRegExpIdentifierStart(state)) {
			state.lastStringValue += codePointToString$1(state.lastIntValue);
			while (this.regexp_eatRegExpIdentifierPart(state)) {
				state.lastStringValue += codePointToString$1(state.lastIntValue);
			}
			return true
		}
		return false
	};

	// RegExpIdentifierStart ::
	//   UnicodeIDStart
	//   `$`
	//   `_`
	//   `\` RegExpUnicodeEscapeSequence[+U]
	pp$1.regexp_eatRegExpIdentifierStart = function(state) {
		var start = state.pos;
		var forceU = this.options.ecmaVersion >= 11;
		var ch = state.current(forceU);
		state.advance(forceU);

		if (ch === 0x5C /* \ */ && this.regexp_eatRegExpUnicodeEscapeSequence(state, forceU)) {
			ch = state.lastIntValue;
		}
		if (isRegExpIdentifierStart(ch)) {
			state.lastIntValue = ch;
			return true
		}

		state.pos = start;
		return false
	};
	function isRegExpIdentifierStart(ch) {
		return isIdentifierStart(ch, true) || ch === 0x24 /* $ */ || ch === 0x5F /* _ */
	}

	// RegExpIdentifierPart ::
	//   UnicodeIDContinue
	//   `$`
	//   `_`
	//   `\` RegExpUnicodeEscapeSequence[+U]
	//   <ZWNJ>
	//   <ZWJ>
	pp$1.regexp_eatRegExpIdentifierPart = function(state) {
		var start = state.pos;
		var forceU = this.options.ecmaVersion >= 11;
		var ch = state.current(forceU);
		state.advance(forceU);

		if (ch === 0x5C /* \ */ && this.regexp_eatRegExpUnicodeEscapeSequence(state, forceU)) {
			ch = state.lastIntValue;
		}
		if (isRegExpIdentifierPart(ch)) {
			state.lastIntValue = ch;
			return true
		}

		state.pos = start;
		return false
	};
	function isRegExpIdentifierPart(ch) {
		return isIdentifierChar(ch, true) || ch === 0x24 /* $ */ || ch === 0x5F /* _ */ || ch === 0x200C /* <ZWNJ> */ || ch === 0x200D /* <ZWJ> */
	}

	// https://www.ecma-international.org/ecma-262/8.0/#prod-annexB-AtomEscape
	pp$1.regexp_eatAtomEscape = function(state) {
		if (
			this.regexp_eatBackReference(state) ||
			this.regexp_eatCharacterClassEscape(state) ||
			this.regexp_eatCharacterEscape(state) ||
			(state.switchN && this.regexp_eatKGroupName(state))
		) {
			return true
		}
		if (state.switchU) {
			// Make the same message as V8.
			if (state.current() === 0x63 /* c */) {
				state.raise("Invalid unicode escape");
			}
			state.raise("Invalid escape");
		}
		return false
	};
	pp$1.regexp_eatBackReference = function(state) {
		var start = state.pos;
		if (this.regexp_eatDecimalEscape(state)) {
			var n = state.lastIntValue;
			if (state.switchU) {
				// For SyntaxError in https://www.ecma-international.org/ecma-262/8.0/#sec-atomescape
				if (n > state.maxBackReference) {
					state.maxBackReference = n;
				}
				return true
			}
			if (n <= state.numCapturingParens) {
				return true
			}
			state.pos = start;
		}
		return false
	};
	pp$1.regexp_eatKGroupName = function(state) {
		if (state.eat(0x6B /* k */)) {
			if (this.regexp_eatGroupName(state)) {
				state.backReferenceNames.push(state.lastStringValue);
				return true
			}
			state.raise("Invalid named reference");
		}
		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-annexB-CharacterEscape
	pp$1.regexp_eatCharacterEscape = function(state) {
		return (
			this.regexp_eatControlEscape(state) ||
			this.regexp_eatCControlLetter(state) ||
			this.regexp_eatZero(state) ||
			this.regexp_eatHexEscapeSequence(state) ||
			this.regexp_eatRegExpUnicodeEscapeSequence(state, false) ||
			(!state.switchU && this.regexp_eatLegacyOctalEscapeSequence(state)) ||
			this.regexp_eatIdentityEscape(state)
		)
	};
	pp$1.regexp_eatCControlLetter = function(state) {
		var start = state.pos;
		if (state.eat(0x63 /* c */)) {
			if (this.regexp_eatControlLetter(state)) {
				return true
			}
			state.pos = start;
		}
		return false
	};
	pp$1.regexp_eatZero = function(state) {
		if (state.current() === 0x30 /* 0 */ && !isDecimalDigit(state.lookahead())) {
			state.lastIntValue = 0;
			state.advance();
			return true
		}
		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-ControlEscape
	pp$1.regexp_eatControlEscape = function(state) {
		var ch = state.current();
		if (ch === 0x74 /* t */) {
			state.lastIntValue = 0x09; /* \t */
			state.advance();
			return true
		}
		if (ch === 0x6E /* n */) {
			state.lastIntValue = 0x0A; /* \n */
			state.advance();
			return true
		}
		if (ch === 0x76 /* v */) {
			state.lastIntValue = 0x0B; /* \v */
			state.advance();
			return true
		}
		if (ch === 0x66 /* f */) {
			state.lastIntValue = 0x0C; /* \f */
			state.advance();
			return true
		}
		if (ch === 0x72 /* r */) {
			state.lastIntValue = 0x0D; /* \r */
			state.advance();
			return true
		}
		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-ControlLetter
	pp$1.regexp_eatControlLetter = function(state) {
		var ch = state.current();
		if (isControlLetter(ch)) {
			state.lastIntValue = ch % 0x20;
			state.advance();
			return true
		}
		return false
	};
	function isControlLetter(ch) {
		return (
			(ch >= 0x41 /* A */ && ch <= 0x5A /* Z */) ||
			(ch >= 0x61 /* a */ && ch <= 0x7A /* z */)
		)
	}

	// https://www.ecma-international.org/ecma-262/8.0/#prod-RegExpUnicodeEscapeSequence
	pp$1.regexp_eatRegExpUnicodeEscapeSequence = function(state, forceU) {
		if ( forceU === void 0 ) forceU = false;

		var start = state.pos;
		var switchU = forceU || state.switchU;

		if (state.eat(0x75 /* u */)) {
			if (this.regexp_eatFixedHexDigits(state, 4)) {
				var lead = state.lastIntValue;
				if (switchU && lead >= 0xD800 && lead <= 0xDBFF) {
					var leadSurrogateEnd = state.pos;
					if (state.eat(0x5C /* \ */) && state.eat(0x75 /* u */) && this.regexp_eatFixedHexDigits(state, 4)) {
						var trail = state.lastIntValue;
						if (trail >= 0xDC00 && trail <= 0xDFFF) {
							state.lastIntValue = (lead - 0xD800) * 0x400 + (trail - 0xDC00) + 0x10000;
							return true
						}
					}
					state.pos = leadSurrogateEnd;
					state.lastIntValue = lead;
				}
				return true
			}
			if (
				switchU &&
				state.eat(0x7B /* { */) &&
				this.regexp_eatHexDigits(state) &&
				state.eat(0x7D /* } */) &&
				isValidUnicode(state.lastIntValue)
			) {
				return true
			}
			if (switchU) {
				state.raise("Invalid unicode escape");
			}
			state.pos = start;
		}

		return false
	};
	function isValidUnicode(ch) {
		return ch >= 0 && ch <= 0x10FFFF
	}

	// https://www.ecma-international.org/ecma-262/8.0/#prod-annexB-IdentityEscape
	pp$1.regexp_eatIdentityEscape = function(state) {
		if (state.switchU) {
			if (this.regexp_eatSyntaxCharacter(state)) {
				return true
			}
			if (state.eat(0x2F /* / */)) {
				state.lastIntValue = 0x2F; /* / */
				return true
			}
			return false
		}

		var ch = state.current();
		if (ch !== 0x63 /* c */ && (!state.switchN || ch !== 0x6B /* k */)) {
			state.lastIntValue = ch;
			state.advance();
			return true
		}

		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-DecimalEscape
	pp$1.regexp_eatDecimalEscape = function(state) {
		state.lastIntValue = 0;
		var ch = state.current();
		if (ch >= 0x31 /* 1 */ && ch <= 0x39 /* 9 */) {
			do {
				state.lastIntValue = 10 * state.lastIntValue + (ch - 0x30 /* 0 */);
				state.advance();
			} while ((ch = state.current()) >= 0x30 /* 0 */ && ch <= 0x39 /* 9 */)
			return true
		}
		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-CharacterClassEscape
	pp$1.regexp_eatCharacterClassEscape = function(state) {
		var ch = state.current();

		if (isCharacterClassEscape(ch)) {
			state.lastIntValue = -1;
			state.advance();
			return true
		}

		if (
			state.switchU &&
			this.options.ecmaVersion >= 9 &&
			(ch === 0x50 /* P */ || ch === 0x70 /* p */)
		) {
			state.lastIntValue = -1;
			state.advance();
			if (
				state.eat(0x7B /* { */) &&
				this.regexp_eatUnicodePropertyValueExpression(state) &&
				state.eat(0x7D /* } */)
			) {
				return true
			}
			state.raise("Invalid property name");
		}

		return false
	};
	function isCharacterClassEscape(ch) {
		return (
			ch === 0x64 /* d */ ||
			ch === 0x44 /* D */ ||
			ch === 0x73 /* s */ ||
			ch === 0x53 /* S */ ||
			ch === 0x77 /* w */ ||
			ch === 0x57 /* W */
		)
	}

	// UnicodePropertyValueExpression ::
	//   UnicodePropertyName `=` UnicodePropertyValue
	//   LoneUnicodePropertyNameOrValue
	pp$1.regexp_eatUnicodePropertyValueExpression = function(state) {
		var start = state.pos;

		// UnicodePropertyName `=` UnicodePropertyValue
		if (this.regexp_eatUnicodePropertyName(state) && state.eat(0x3D /* = */)) {
			var name = state.lastStringValue;
			if (this.regexp_eatUnicodePropertyValue(state)) {
				var value = state.lastStringValue;
				this.regexp_validateUnicodePropertyNameAndValue(state, name, value);
				return true
			}
		}
		state.pos = start;

		// LoneUnicodePropertyNameOrValue
		if (this.regexp_eatLoneUnicodePropertyNameOrValue(state)) {
			var nameOrValue = state.lastStringValue;
			this.regexp_validateUnicodePropertyNameOrValue(state, nameOrValue);
			return true
		}
		return false
	};
	pp$1.regexp_validateUnicodePropertyNameAndValue = function(state, name, value) {
		if (!hasOwn(state.unicodeProperties.nonBinary, name))
			{ state.raise("Invalid property name"); }
		if (!state.unicodeProperties.nonBinary[name].test(value))
			{ state.raise("Invalid property value"); }
	};
	pp$1.regexp_validateUnicodePropertyNameOrValue = function(state, nameOrValue) {
		if (!state.unicodeProperties.binary.test(nameOrValue))
			{ state.raise("Invalid property name"); }
	};

	// UnicodePropertyName ::
	//   UnicodePropertyNameCharacters
	pp$1.regexp_eatUnicodePropertyName = function(state) {
		var ch = 0;
		state.lastStringValue = "";
		while (isUnicodePropertyNameCharacter(ch = state.current())) {
			state.lastStringValue += codePointToString$1(ch);
			state.advance();
		}
		return state.lastStringValue !== ""
	};
	function isUnicodePropertyNameCharacter(ch) {
		return isControlLetter(ch) || ch === 0x5F /* _ */
	}

	// UnicodePropertyValue ::
	//   UnicodePropertyValueCharacters
	pp$1.regexp_eatUnicodePropertyValue = function(state) {
		var ch = 0;
		state.lastStringValue = "";
		while (isUnicodePropertyValueCharacter(ch = state.current())) {
			state.lastStringValue += codePointToString$1(ch);
			state.advance();
		}
		return state.lastStringValue !== ""
	};
	function isUnicodePropertyValueCharacter(ch) {
		return isUnicodePropertyNameCharacter(ch) || isDecimalDigit(ch)
	}

	// LoneUnicodePropertyNameOrValue ::
	//   UnicodePropertyValueCharacters
	pp$1.regexp_eatLoneUnicodePropertyNameOrValue = function(state) {
		return this.regexp_eatUnicodePropertyValue(state)
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-CharacterClass
	pp$1.regexp_eatCharacterClass = function(state) {
		if (state.eat(0x5B /* [ */)) {
			state.eat(0x5E /* ^ */);
			this.regexp_classRanges(state);
			if (state.eat(0x5D /* ] */)) {
				return true
			}
			// Unreachable since it threw "unterminated regular expression" error before.
			state.raise("Unterminated character class");
		}
		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-ClassRanges
	// https://www.ecma-international.org/ecma-262/8.0/#prod-NonemptyClassRanges
	// https://www.ecma-international.org/ecma-262/8.0/#prod-NonemptyClassRangesNoDash
	pp$1.regexp_classRanges = function(state) {
		while (this.regexp_eatClassAtom(state)) {
			var left = state.lastIntValue;
			if (state.eat(0x2D /* - */) && this.regexp_eatClassAtom(state)) {
				var right = state.lastIntValue;
				if (state.switchU && (left === -1 || right === -1)) {
					state.raise("Invalid character class");
				}
				if (left !== -1 && right !== -1 && left > right) {
					state.raise("Range out of order in character class");
				}
			}
		}
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-ClassAtom
	// https://www.ecma-international.org/ecma-262/8.0/#prod-ClassAtomNoDash
	pp$1.regexp_eatClassAtom = function(state) {
		var start = state.pos;

		if (state.eat(0x5C /* \ */)) {
			if (this.regexp_eatClassEscape(state)) {
				return true
			}
			if (state.switchU) {
				// Make the same message as V8.
				var ch$1 = state.current();
				if (ch$1 === 0x63 /* c */ || isOctalDigit(ch$1)) {
					state.raise("Invalid class escape");
				}
				state.raise("Invalid escape");
			}
			state.pos = start;
		}

		var ch = state.current();
		if (ch !== 0x5D /* ] */) {
			state.lastIntValue = ch;
			state.advance();
			return true
		}

		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-annexB-ClassEscape
	pp$1.regexp_eatClassEscape = function(state) {
		var start = state.pos;

		if (state.eat(0x62 /* b */)) {
			state.lastIntValue = 0x08; /* <BS> */
			return true
		}

		if (state.switchU && state.eat(0x2D /* - */)) {
			state.lastIntValue = 0x2D; /* - */
			return true
		}

		if (!state.switchU && state.eat(0x63 /* c */)) {
			if (this.regexp_eatClassControlLetter(state)) {
				return true
			}
			state.pos = start;
		}

		return (
			this.regexp_eatCharacterClassEscape(state) ||
			this.regexp_eatCharacterEscape(state)
		)
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-annexB-ClassControlLetter
	pp$1.regexp_eatClassControlLetter = function(state) {
		var ch = state.current();
		if (isDecimalDigit(ch) || ch === 0x5F /* _ */) {
			state.lastIntValue = ch % 0x20;
			state.advance();
			return true
		}
		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-HexEscapeSequence
	pp$1.regexp_eatHexEscapeSequence = function(state) {
		var start = state.pos;
		if (state.eat(0x78 /* x */)) {
			if (this.regexp_eatFixedHexDigits(state, 2)) {
				return true
			}
			if (state.switchU) {
				state.raise("Invalid escape");
			}
			state.pos = start;
		}
		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-DecimalDigits
	pp$1.regexp_eatDecimalDigits = function(state) {
		var start = state.pos;
		var ch = 0;
		state.lastIntValue = 0;
		while (isDecimalDigit(ch = state.current())) {
			state.lastIntValue = 10 * state.lastIntValue + (ch - 0x30 /* 0 */);
			state.advance();
		}
		return state.pos !== start
	};
	function isDecimalDigit(ch) {
		return ch >= 0x30 /* 0 */ && ch <= 0x39 /* 9 */
	}

	// https://www.ecma-international.org/ecma-262/8.0/#prod-HexDigits
	pp$1.regexp_eatHexDigits = function(state) {
		var start = state.pos;
		var ch = 0;
		state.lastIntValue = 0;
		while (isHexDigit(ch = state.current())) {
			state.lastIntValue = 16 * state.lastIntValue + hexToInt(ch);
			state.advance();
		}
		return state.pos !== start
	};
	function isHexDigit(ch) {
		return (
			(ch >= 0x30 /* 0 */ && ch <= 0x39 /* 9 */) ||
			(ch >= 0x41 /* A */ && ch <= 0x46 /* F */) ||
			(ch >= 0x61 /* a */ && ch <= 0x66 /* f */)
		)
	}
	function hexToInt(ch) {
		if (ch >= 0x41 /* A */ && ch <= 0x46 /* F */) {
			return 10 + (ch - 0x41 /* A */)
		}
		if (ch >= 0x61 /* a */ && ch <= 0x66 /* f */) {
			return 10 + (ch - 0x61 /* a */)
		}
		return ch - 0x30 /* 0 */
	}

	// https://www.ecma-international.org/ecma-262/8.0/#prod-annexB-LegacyOctalEscapeSequence
	// Allows only 0-377(octal) i.e. 0-255(decimal).
	pp$1.regexp_eatLegacyOctalEscapeSequence = function(state) {
		if (this.regexp_eatOctalDigit(state)) {
			var n1 = state.lastIntValue;
			if (this.regexp_eatOctalDigit(state)) {
				var n2 = state.lastIntValue;
				if (n1 <= 3 && this.regexp_eatOctalDigit(state)) {
					state.lastIntValue = n1 * 64 + n2 * 8 + state.lastIntValue;
				} else {
					state.lastIntValue = n1 * 8 + n2;
				}
			} else {
				state.lastIntValue = n1;
			}
			return true
		}
		return false
	};

	// https://www.ecma-international.org/ecma-262/8.0/#prod-OctalDigit
	pp$1.regexp_eatOctalDigit = function(state) {
		var ch = state.current();
		if (isOctalDigit(ch)) {
			state.lastIntValue = ch - 0x30; /* 0 */
			state.advance();
			return true
		}
		state.lastIntValue = 0;
		return false
	};
	function isOctalDigit(ch) {
		return ch >= 0x30 /* 0 */ && ch <= 0x37 /* 7 */
	}

	// https://www.ecma-international.org/ecma-262/8.0/#prod-Hex4Digits
	// https://www.ecma-international.org/ecma-262/8.0/#prod-HexDigit
	// And HexDigit HexDigit in https://www.ecma-international.org/ecma-262/8.0/#prod-HexEscapeSequence
	pp$1.regexp_eatFixedHexDigits = function(state, length) {
		var start = state.pos;
		state.lastIntValue = 0;
		for (var i = 0; i < length; ++i) {
			var ch = state.current();
			if (!isHexDigit(ch)) {
				state.pos = start;
				return false
			}
			state.lastIntValue = 16 * state.lastIntValue + hexToInt(ch);
			state.advance();
		}
		return true
	};

	// Object type used to represent tokens. Note that normally, tokens
	// simply exist as properties on the parser object. This is only
	// used for the onToken callback and the external tokenizer.

	var Token = function Token(p) {
		this.type = p.type;
		this.value = p.value;
		this.start = p.start;
		this.end = p.end;
		if (p.options.locations)
			{ this.loc = new SourceLocation(p, p.startLoc, p.endLoc); }
		if (p.options.ranges)
			{ this.range = [p.start, p.end]; }
	};

	// ## Tokenizer

	var pp = Parser.prototype;

	// Move to the next token

	pp.next = function(ignoreEscapeSequenceInKeyword) {
		if (!ignoreEscapeSequenceInKeyword && this.type.keyword && this.containsEsc)
			{ this.raiseRecoverable(this.start, "Escape sequence in keyword " + this.type.keyword); }
		if (this.options.onToken)
			{ this.options.onToken(new Token(this)); }

		this.lastTokEnd = this.end;
		this.lastTokStart = this.start;
		this.lastTokEndLoc = this.endLoc;
		this.lastTokStartLoc = this.startLoc;
		this.nextToken();
	};

	pp.getToken = function() {
		this.next();
		return new Token(this)
	};

	// If we're in an ES6 environment, make parsers iterable
	if (typeof Symbol !== "undefined")
		{ pp[Symbol.iterator] = function() {
			var this$1$1 = this;

			return {
				next: function () {
					var token = this$1$1.getToken();
					return {
						done: token.type === types$1.eof,
						value: token
					}
				}
			}
		}; }

	// Toggle strict mode. Re-reads the next number or string to please
	// pedantic tests (`"use strict"; 010;` should fail).

	// Read a single token, updating the parser object's token-related
	// properties.

	pp.nextToken = function() {
		var curContext = this.curContext();
		if (!curContext || !curContext.preserveSpace) { this.skipSpace(); }

		this.start = this.pos;
		if (this.options.locations) { this.startLoc = this.curPosition(); }
		if (this.pos >= this.input.length) { return this.finishToken(types$1.eof) }

		if (curContext.override) { return curContext.override(this) }
		else { this.readToken(this.fullCharCodeAtPos()); }
	};

	pp.readToken = function(code) {
		// Identifier or keyword. '\uXXXX' sequences are allowed in
		// identifiers, so '\' also dispatches to that.
		if (isIdentifierStart(code, this.options.ecmaVersion >= 6) || code === 92 /* '\' */)
			{ return this.readWord() }

		return this.getTokenFromCode(code)
	};

	pp.fullCharCodeAtPos = function() {
		var code = this.input.charCodeAt(this.pos);
		if (code <= 0xd7ff || code >= 0xdc00) { return code }
		var next = this.input.charCodeAt(this.pos + 1);
		return next <= 0xdbff || next >= 0xe000 ? code : (code << 10) + next - 0x35fdc00
	};

	pp.skipBlockComment = function() {
		var startLoc = this.options.onComment && this.curPosition();
		var start = this.pos, end = this.input.indexOf("*/", this.pos += 2);
		if (end === -1) { this.raise(this.pos - 2, "Unterminated comment"); }
		this.pos = end + 2;
		if (this.options.locations) {
			for (var nextBreak = (void 0), pos = start; (nextBreak = nextLineBreak(this.input, pos, this.pos)) > -1;) {
				++this.curLine;
				pos = this.lineStart = nextBreak;
			}
		}
		if (this.options.onComment)
			{ this.options.onComment(true, this.input.slice(start + 2, end), start, this.pos,
														startLoc, this.curPosition()); }
	};

	pp.skipLineComment = function(startSkip) {
		var start = this.pos;
		var startLoc = this.options.onComment && this.curPosition();
		var ch = this.input.charCodeAt(this.pos += startSkip);
		while (this.pos < this.input.length && !isNewLine(ch)) {
			ch = this.input.charCodeAt(++this.pos);
		}
		if (this.options.onComment)
			{ this.options.onComment(false, this.input.slice(start + startSkip, this.pos), start, this.pos,
														startLoc, this.curPosition()); }
	};

	// Called at the start of the parse and after every token. Skips
	// whitespace and comments, and.

	pp.skipSpace = function() {
		loop: while (this.pos < this.input.length) {
			var ch = this.input.charCodeAt(this.pos);
			switch (ch) {
			case 32: case 160: // ' '
				++this.pos;
				break
			case 13:
				if (this.input.charCodeAt(this.pos + 1) === 10) {
					++this.pos;
				}
			case 10: case 8232: case 8233:
				++this.pos;
				if (this.options.locations) {
					++this.curLine;
					this.lineStart = this.pos;
				}
				break
			case 47: // '/'
				switch (this.input.charCodeAt(this.pos + 1)) {
				case 42: // '*'
					this.skipBlockComment();
					break
				case 47:
					this.skipLineComment(2);
					break
				default:
					break loop
				}
				break
			default:
				if (ch > 8 && ch < 14 || ch >= 5760 && nonASCIIwhitespace.test(String.fromCharCode(ch))) {
					++this.pos;
				} else {
					break loop
				}
			}
		}
	};

	// Called at the end of every token. Sets `end`, `val`, and
	// maintains `context` and `exprAllowed`, and skips the space after
	// the token, so that the next one's `start` will point at the
	// right position.

	pp.finishToken = function(type, val) {
		this.end = this.pos;
		if (this.options.locations) { this.endLoc = this.curPosition(); }
		var prevType = this.type;
		this.type = type;
		this.value = val;

		this.updateContext(prevType);
	};

	// ### Token reading

	// This is the function that is called to fetch the next token. It
	// is somewhat obscure, because it works in character codes rather
	// than characters, and because operator parsing has been inlined
	// into it.
	//
	// All in the name of speed.
	//
	pp.readToken_dot = function() {
		var next = this.input.charCodeAt(this.pos + 1);
		if (next >= 48 && next <= 57) { return this.readNumber(true) }
		var next2 = this.input.charCodeAt(this.pos + 2);
		if (this.options.ecmaVersion >= 6 && next === 46 && next2 === 46) { // 46 = dot '.'
			this.pos += 3;
			return this.finishToken(types$1.ellipsis)
		} else {
			++this.pos;
			return this.finishToken(types$1.dot)
		}
	};

	pp.readToken_slash = function() { // '/'
		var next = this.input.charCodeAt(this.pos + 1);
		if (this.exprAllowed) { ++this.pos; return this.readRegexp() }
		if (next === 61) { return this.finishOp(types$1.assign, 2) }
		return this.finishOp(types$1.slash, 1)
	};

	pp.readToken_mult_modulo_exp = function(code) { // '%*'
		var next = this.input.charCodeAt(this.pos + 1);
		var size = 1;
		var tokentype = code === 42 ? types$1.star : types$1.modulo;

		// exponentiation operator ** and **=
		if (this.options.ecmaVersion >= 7 && code === 42 && next === 42) {
			++size;
			tokentype = types$1.starstar;
			next = this.input.charCodeAt(this.pos + 2);
		}

		if (next === 61) { return this.finishOp(types$1.assign, size + 1) }
		return this.finishOp(tokentype, size)
	};

	pp.readToken_pipe_amp = function(code) { // '|&'
		var next = this.input.charCodeAt(this.pos + 1);
		if (next === code) {
			if (this.options.ecmaVersion >= 12) {
				var next2 = this.input.charCodeAt(this.pos + 2);
				if (next2 === 61) { return this.finishOp(types$1.assign, 3) }
			}
			return this.finishOp(code === 124 ? types$1.logicalOR : types$1.logicalAND, 2)
		}
		if (next === 61) { return this.finishOp(types$1.assign, 2) }
		return this.finishOp(code === 124 ? types$1.bitwiseOR : types$1.bitwiseAND, 1)
	};

	pp.readToken_caret = function() { // '^'
		var next = this.input.charCodeAt(this.pos + 1);
		if (next === 61) { return this.finishOp(types$1.assign, 2) }
		return this.finishOp(types$1.bitwiseXOR, 1)
	};

	pp.readToken_plus_min = function(code) { // '+-'
		var next = this.input.charCodeAt(this.pos + 1);
		if (next === code) {
			if (next === 45 && !this.inModule && this.input.charCodeAt(this.pos + 2) === 62 &&
					(this.lastTokEnd === 0 || lineBreak.test(this.input.slice(this.lastTokEnd, this.pos)))) {
				// A `-->` line comment
				this.skipLineComment(3);
				this.skipSpace();
				return this.nextToken()
			}
			return this.finishOp(types$1.incDec, 2)
		}
		if (next === 61) { return this.finishOp(types$1.assign, 2) }
		return this.finishOp(types$1.plusMin, 1)
	};

	pp.readToken_lt_gt = function(code) { // '<>'
		var next = this.input.charCodeAt(this.pos + 1);
		var size = 1;
		if (next === code) {
			size = code === 62 && this.input.charCodeAt(this.pos + 2) === 62 ? 3 : 2;
			if (this.input.charCodeAt(this.pos + size) === 61) { return this.finishOp(types$1.assign, size + 1) }
			return this.finishOp(types$1.bitShift, size)
		}
		if (next === 33 && code === 60 && !this.inModule && this.input.charCodeAt(this.pos + 2) === 45 &&
				this.input.charCodeAt(this.pos + 3) === 45) {
			// `<!--`, an XML-style comment that should be interpreted as a line comment
			this.skipLineComment(4);
			this.skipSpace();
			return this.nextToken()
		}
		if (next === 61) { size = 2; }
		return this.finishOp(types$1.relational, size)
	};

	pp.readToken_eq_excl = function(code) { // '=!'
		var next = this.input.charCodeAt(this.pos + 1);
		if (next === 61) { return this.finishOp(types$1.equality, this.input.charCodeAt(this.pos + 2) === 61 ? 3 : 2) }
		if (code === 61 && next === 62 && this.options.ecmaVersion >= 6) { // '=>'
			this.pos += 2;
			return this.finishToken(types$1.arrow)
		}
		return this.finishOp(code === 61 ? types$1.eq : types$1.prefix, 1)
	};

	pp.readToken_question = function() { // '?'
		var ecmaVersion = this.options.ecmaVersion;
		if (ecmaVersion >= 11) {
			var next = this.input.charCodeAt(this.pos + 1);
			if (next === 46) {
				var next2 = this.input.charCodeAt(this.pos + 2);
				if (next2 < 48 || next2 > 57) { return this.finishOp(types$1.questionDot, 2) }
			}
			if (next === 63) {
				if (ecmaVersion >= 12) {
					var next2$1 = this.input.charCodeAt(this.pos + 2);
					if (next2$1 === 61) { return this.finishOp(types$1.assign, 3) }
				}
				return this.finishOp(types$1.coalesce, 2)
			}
		}
		return this.finishOp(types$1.question, 1)
	};

	pp.readToken_numberSign = function() { // '#'
		var ecmaVersion = this.options.ecmaVersion;
		var code = 35; // '#'
		if (ecmaVersion >= 13) {
			++this.pos;
			code = this.fullCharCodeAtPos();
			if (isIdentifierStart(code, true) || code === 92 /* '\' */) {
				return this.finishToken(types$1.privateId, this.readWord1())
			}
		}

		this.raise(this.pos, "Unexpected character '" + codePointToString(code) + "'");
	};

	pp.getTokenFromCode = function(code) {
		switch (code) {
		// The interpretation of a dot depends on whether it is followed
		// by a digit or another two dots.
		case 46: // '.'
			return this.readToken_dot()

		// Punctuation tokens.
		case 40: ++this.pos; return this.finishToken(types$1.parenL)
		case 41: ++this.pos; return this.finishToken(types$1.parenR)
		case 59: ++this.pos; return this.finishToken(types$1.semi)
		case 44: ++this.pos; return this.finishToken(types$1.comma)
		case 91: ++this.pos; return this.finishToken(types$1.bracketL)
		case 93: ++this.pos; return this.finishToken(types$1.bracketR)
		case 123: ++this.pos; return this.finishToken(types$1.braceL)
		case 125: ++this.pos; return this.finishToken(types$1.braceR)
		case 58: ++this.pos; return this.finishToken(types$1.colon)

		case 96: // '`'
			if (this.options.ecmaVersion < 6) { break }
			++this.pos;
			return this.finishToken(types$1.backQuote)

		case 48: // '0'
			var next = this.input.charCodeAt(this.pos + 1);
			if (next === 120 || next === 88) { return this.readRadixNumber(16) } // '0x', '0X' - hex number
			if (this.options.ecmaVersion >= 6) {
				if (next === 111 || next === 79) { return this.readRadixNumber(8) } // '0o', '0O' - octal number
				if (next === 98 || next === 66) { return this.readRadixNumber(2) } // '0b', '0B' - binary number
			}

		// Anything else beginning with a digit is an integer, octal
		// number, or float.
		case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: // 1-9
			return this.readNumber(false)

		// Quotes produce strings.
		case 34: case 39: // '"', "'"
			return this.readString(code)

		// Operators are parsed inline in tiny state machines. '=' (61) is
		// often referred to. `finishOp` simply skips the amount of
		// characters it is given as second argument, and returns a token
		// of the type given by its first argument.
		case 47: // '/'
			return this.readToken_slash()

		case 37: case 42: // '%*'
			return this.readToken_mult_modulo_exp(code)

		case 124: case 38: // '|&'
			return this.readToken_pipe_amp(code)

		case 94: // '^'
			return this.readToken_caret()

		case 43: case 45: // '+-'
			return this.readToken_plus_min(code)

		case 60: case 62: // '<>'
			return this.readToken_lt_gt(code)

		case 61: case 33: // '=!'
			return this.readToken_eq_excl(code)

		case 63: // '?'
			return this.readToken_question()

		case 126: // '~'
			return this.finishOp(types$1.prefix, 1)

		case 35: // '#'
			return this.readToken_numberSign()
		}

		this.raise(this.pos, "Unexpected character '" + codePointToString(code) + "'");
	};

	pp.finishOp = function(type, size) {
		var str = this.input.slice(this.pos, this.pos + size);
		this.pos += size;
		return this.finishToken(type, str)
	};

	pp.readRegexp = function() {
		var escaped, inClass, start = this.pos;
		for (;;) {
			if (this.pos >= this.input.length) { this.raise(start, "Unterminated regular expression"); }
			var ch = this.input.charAt(this.pos);
			if (lineBreak.test(ch)) { this.raise(start, "Unterminated regular expression"); }
			if (!escaped) {
				if (ch === "[") { inClass = true; }
				else if (ch === "]" && inClass) { inClass = false; }
				else if (ch === "/" && !inClass) { break }
				escaped = ch === "\\";
			} else { escaped = false; }
			++this.pos;
		}
		var pattern = this.input.slice(start, this.pos);
		++this.pos;
		var flagsStart = this.pos;
		var flags = this.readWord1();
		if (this.containsEsc) { this.unexpected(flagsStart); }

		// Validate pattern
		var state = this.regexpState || (this.regexpState = new RegExpValidationState(this));
		state.reset(start, pattern, flags);
		this.validateRegExpFlags(state);
		this.validateRegExpPattern(state);

		// Create Literal#value property value.
		var value = null;
		try {
			value = new RegExp(pattern, flags);
		} catch (e) {
			// ESTree requires null if it failed to instantiate RegExp object.
			// https://github.com/estree/estree/blob/a27003adf4fd7bfad44de9cef372a2eacd527b1c/es5.md#regexpliteral
		}

		return this.finishToken(types$1.regexp, {pattern: pattern, flags: flags, value: value})
	};

	// Read an integer in the given radix. Return null if zero digits
	// were read, the integer value otherwise. When `len` is given, this
	// will return `null` unless the integer has exactly `len` digits.

	pp.readInt = function(radix, len, maybeLegacyOctalNumericLiteral) {
		// `len` is used for character escape sequences. In that case, disallow separators.
		var allowSeparators = this.options.ecmaVersion >= 12 && len === undefined;

		// `maybeLegacyOctalNumericLiteral` is true if it doesn't have prefix (0x,0o,0b)
		// and isn't fraction part nor exponent part. In that case, if the first digit
		// is zero then disallow separators.
		var isLegacyOctalNumericLiteral = maybeLegacyOctalNumericLiteral && this.input.charCodeAt(this.pos) === 48;

		var start = this.pos, total = 0, lastCode = 0;
		for (var i = 0, e = len == null ? Infinity : len; i < e; ++i, ++this.pos) {
			var code = this.input.charCodeAt(this.pos), val = (void 0);

			if (allowSeparators && code === 95) {
				if (isLegacyOctalNumericLiteral) { this.raiseRecoverable(this.pos, "Numeric separator is not allowed in legacy octal numeric literals"); }
				if (lastCode === 95) { this.raiseRecoverable(this.pos, "Numeric separator must be exactly one underscore"); }
				if (i === 0) { this.raiseRecoverable(this.pos, "Numeric separator is not allowed at the first of digits"); }
				lastCode = code;
				continue
			}

			if (code >= 97) { val = code - 97 + 10; } // a
			else if (code >= 65) { val = code - 65 + 10; } // A
			else if (code >= 48 && code <= 57) { val = code - 48; } // 0-9
			else { val = Infinity; }
			if (val >= radix) { break }
			lastCode = code;
			total = total * radix + val;
		}

		if (allowSeparators && lastCode === 95) { this.raiseRecoverable(this.pos - 1, "Numeric separator is not allowed at the last of digits"); }
		if (this.pos === start || len != null && this.pos - start !== len) { return null }

		return total
	};

	function stringToNumber(str, isLegacyOctalNumericLiteral) {
		if (isLegacyOctalNumericLiteral) {
			return parseInt(str, 8)
		}

		// `parseFloat(value)` stops parsing at the first numeric separator then returns a wrong value.
		return parseFloat(str.replace(/_/g, ""))
	}

	function stringToBigInt(str) {
		if (typeof BigInt !== "function") {
			return null
		}

		// `BigInt(value)` throws syntax error if the string contains numeric separators.
		return BigInt(str.replace(/_/g, ""))
	}

	pp.readRadixNumber = function(radix) {
		var start = this.pos;
		this.pos += 2; // 0x
		var val = this.readInt(radix);
		if (val == null) { this.raise(this.start + 2, "Expected number in radix " + radix); }
		if (this.options.ecmaVersion >= 11 && this.input.charCodeAt(this.pos) === 110) {
			val = stringToBigInt(this.input.slice(start, this.pos));
			++this.pos;
		} else if (isIdentifierStart(this.fullCharCodeAtPos())) { this.raise(this.pos, "Identifier directly after number"); }
		return this.finishToken(types$1.num, val)
	};

	// Read an integer, octal integer, or floating-point number.

	pp.readNumber = function(startsWithDot) {
		var start = this.pos;
		if (!startsWithDot && this.readInt(10, undefined, true) === null) { this.raise(start, "Invalid number"); }
		var octal = this.pos - start >= 2 && this.input.charCodeAt(start) === 48;
		if (octal && this.strict) { this.raise(start, "Invalid number"); }
		var next = this.input.charCodeAt(this.pos);
		if (!octal && !startsWithDot && this.options.ecmaVersion >= 11 && next === 110) {
			var val$1 = stringToBigInt(this.input.slice(start, this.pos));
			++this.pos;
			if (isIdentifierStart(this.fullCharCodeAtPos())) { this.raise(this.pos, "Identifier directly after number"); }
			return this.finishToken(types$1.num, val$1)
		}
		if (octal && /[89]/.test(this.input.slice(start, this.pos))) { octal = false; }
		if (next === 46 && !octal) { // '.'
			++this.pos;
			this.readInt(10);
			next = this.input.charCodeAt(this.pos);
		}
		if ((next === 69 || next === 101) && !octal) { // 'eE'
			next = this.input.charCodeAt(++this.pos);
			if (next === 43 || next === 45) { ++this.pos; } // '+-'
			if (this.readInt(10) === null) { this.raise(start, "Invalid number"); }
		}
		if (isIdentifierStart(this.fullCharCodeAtPos())) { this.raise(this.pos, "Identifier directly after number"); }

		var val = stringToNumber(this.input.slice(start, this.pos), octal);
		return this.finishToken(types$1.num, val)
	};

	// Read a string value, interpreting backslash-escapes.

	pp.readCodePoint = function() {
		var ch = this.input.charCodeAt(this.pos), code;

		if (ch === 123) { // '{'
			if (this.options.ecmaVersion < 6) { this.unexpected(); }
			var codePos = ++this.pos;
			code = this.readHexChar(this.input.indexOf("}", this.pos) - this.pos);
			++this.pos;
			if (code > 0x10FFFF) { this.invalidStringToken(codePos, "Code point out of bounds"); }
		} else {
			code = this.readHexChar(4);
		}
		return code
	};

	function codePointToString(code) {
		// UTF-16 Decoding
		if (code <= 0xFFFF) { return String.fromCharCode(code) }
		code -= 0x10000;
		return String.fromCharCode((code >> 10) + 0xD800, (code & 1023) + 0xDC00)
	}

	pp.readString = function(quote) {
		var out = "", chunkStart = ++this.pos;
		for (;;) {
			if (this.pos >= this.input.length) { this.raise(this.start, "Unterminated string constant"); }
			var ch = this.input.charCodeAt(this.pos);
			if (ch === quote) { break }
			if (ch === 92) { // '\'
				out += this.input.slice(chunkStart, this.pos);
				out += this.readEscapedChar(false);
				chunkStart = this.pos;
			} else if (ch === 0x2028 || ch === 0x2029) {
				if (this.options.ecmaVersion < 10) { this.raise(this.start, "Unterminated string constant"); }
				++this.pos;
				if (this.options.locations) {
					this.curLine++;
					this.lineStart = this.pos;
				}
			} else {
				if (isNewLine(ch)) { this.raise(this.start, "Unterminated string constant"); }
				++this.pos;
			}
		}
		out += this.input.slice(chunkStart, this.pos++);
		return this.finishToken(types$1.string, out)
	};

	// Reads template string tokens.

	var INVALID_TEMPLATE_ESCAPE_ERROR = {};

	pp.tryReadTemplateToken = function() {
		this.inTemplateElement = true;
		try {
			this.readTmplToken();
		} catch (err) {
			if (err === INVALID_TEMPLATE_ESCAPE_ERROR) {
				this.readInvalidTemplateToken();
			} else {
				throw err
			}
		}

		this.inTemplateElement = false;
	};

	pp.invalidStringToken = function(position, message) {
		if (this.inTemplateElement && this.options.ecmaVersion >= 9) {
			throw INVALID_TEMPLATE_ESCAPE_ERROR
		} else {
			this.raise(position, message);
		}
	};

	pp.readTmplToken = function() {
		var out = "", chunkStart = this.pos;
		for (;;) {
			if (this.pos >= this.input.length) { this.raise(this.start, "Unterminated template"); }
			var ch = this.input.charCodeAt(this.pos);
			if (ch === 96 || ch === 36 && this.input.charCodeAt(this.pos + 1) === 123) { // '`', '${'
				if (this.pos === this.start && (this.type === types$1.template || this.type === types$1.invalidTemplate)) {
					if (ch === 36) {
						this.pos += 2;
						return this.finishToken(types$1.dollarBraceL)
					} else {
						++this.pos;
						return this.finishToken(types$1.backQuote)
					}
				}
				out += this.input.slice(chunkStart, this.pos);
				return this.finishToken(types$1.template, out)
			}
			if (ch === 92) { // '\'
				out += this.input.slice(chunkStart, this.pos);
				out += this.readEscapedChar(true);
				chunkStart = this.pos;
			} else if (isNewLine(ch)) {
				out += this.input.slice(chunkStart, this.pos);
				++this.pos;
				switch (ch) {
				case 13:
					if (this.input.charCodeAt(this.pos) === 10) { ++this.pos; }
				case 10:
					out += "\n";
					break
				default:
					out += String.fromCharCode(ch);
					break
				}
				if (this.options.locations) {
					++this.curLine;
					this.lineStart = this.pos;
				}
				chunkStart = this.pos;
			} else {
				++this.pos;
			}
		}
	};

	// Reads a template token to search for the end, without validating any escape sequences
	pp.readInvalidTemplateToken = function() {
		for (; this.pos < this.input.length; this.pos++) {
			switch (this.input[this.pos]) {
			case "\\":
				++this.pos;
				break

			case "$":
				if (this.input[this.pos + 1] !== "{") {
					break
				}

			// falls through
			case "`":
				return this.finishToken(types$1.invalidTemplate, this.input.slice(this.start, this.pos))

			// no default
			}
		}
		this.raise(this.start, "Unterminated template");
	};

	// Used to read escaped characters

	pp.readEscapedChar = function(inTemplate) {
		var ch = this.input.charCodeAt(++this.pos);
		++this.pos;
		switch (ch) {
		case 110: return "\n" // 'n' -> '\n'
		case 114: return "\r" // 'r' -> '\r'
		case 120: return String.fromCharCode(this.readHexChar(2)) // 'x'
		case 117: return codePointToString(this.readCodePoint()) // 'u'
		case 116: return "\t" // 't' -> '\t'
		case 98: return "\b" // 'b' -> '\b'
		case 118: return "\u000b" // 'v' -> '\u000b'
		case 102: return "\f" // 'f' -> '\f'
		case 13: if (this.input.charCodeAt(this.pos) === 10) { ++this.pos; } // '\r\n'
		case 10: // ' \n'
			if (this.options.locations) { this.lineStart = this.pos; ++this.curLine; }
			return ""
		case 56:
		case 57:
			if (this.strict) {
				this.invalidStringToken(
					this.pos - 1,
					"Invalid escape sequence"
				);
			}
			if (inTemplate) {
				var codePos = this.pos - 1;

				this.invalidStringToken(
					codePos,
					"Invalid escape sequence in template string"
				);

				return null
			}
		default:
			if (ch >= 48 && ch <= 55) {
				var octalStr = this.input.substr(this.pos - 1, 3).match(/^[0-7]+/)[0];
				var octal = parseInt(octalStr, 8);
				if (octal > 255) {
					octalStr = octalStr.slice(0, -1);
					octal = parseInt(octalStr, 8);
				}
				this.pos += octalStr.length - 1;
				ch = this.input.charCodeAt(this.pos);
				if ((octalStr !== "0" || ch === 56 || ch === 57) && (this.strict || inTemplate)) {
					this.invalidStringToken(
						this.pos - 1 - octalStr.length,
						inTemplate
							? "Octal literal in template string"
							: "Octal literal in strict mode"
					);
				}
				return String.fromCharCode(octal)
			}
			if (isNewLine(ch)) {
				// Unicode new line characters after \ get removed from output in both
				// template literals and strings
				return ""
			}
			return String.fromCharCode(ch)
		}
	};

	// Used to read character escape sequences ('\x', '\u', '\U').

	pp.readHexChar = function(len) {
		var codePos = this.pos;
		var n = this.readInt(16, len);
		if (n === null) { this.invalidStringToken(codePos, "Bad character escape sequence"); }
		return n
	};

	// Read an identifier, and return it as a string. Sets `this.containsEsc`
	// to whether the word contained a '\u' escape.
	//
	// Incrementally adds only escaped chars, adding other chunks as-is
	// as a micro-optimization.

	pp.readWord1 = function() {
		this.containsEsc = false;
		var word = "", first = true, chunkStart = this.pos;
		var astral = this.options.ecmaVersion >= 6;
		while (this.pos < this.input.length) {
			var ch = this.fullCharCodeAtPos();
			if (isIdentifierChar(ch, astral)) {
				this.pos += ch <= 0xffff ? 1 : 2;
			} else if (ch === 92) { // "\"
				this.containsEsc = true;
				word += this.input.slice(chunkStart, this.pos);
				var escStart = this.pos;
				if (this.input.charCodeAt(++this.pos) !== 117) // "u"
					{ this.invalidStringToken(this.pos, "Expecting Unicode escape sequence \\uXXXX"); }
				++this.pos;
				var esc = this.readCodePoint();
				if (!(first ? isIdentifierStart : isIdentifierChar)(esc, astral))
					{ this.invalidStringToken(escStart, "Invalid Unicode escape"); }
				word += codePointToString(esc);
				chunkStart = this.pos;
			} else {
				break
			}
			first = false;
		}
		return word + this.input.slice(chunkStart, this.pos)
	};

	// Read an identifier or keyword token. Will check for reserved
	// words when necessary.

	pp.readWord = function() {
		var word = this.readWord1();
		var type = types$1.name;
		if (this.keywords.test(word)) {
			type = keywords[word];
		}
		return this.finishToken(type, word)
	};

	// Acorn is a tiny, fast JavaScript parser written in JavaScript.

	var version = "8.7.0";

	Parser.acorn = {
		Parser: Parser,
		version: version,
		defaultOptions: defaultOptions,
		Position: Position,
		SourceLocation: SourceLocation,
		getLineInfo: getLineInfo,
		Node: Node,
		TokenType: TokenType,
		tokTypes: types$1,
		keywordTypes: keywords,
		TokContext: TokContext,
		tokContexts: types,
		isIdentifierChar: isIdentifierChar,
		isIdentifierStart: isIdentifierStart,
		Token: Token,
		isNewLine: isNewLine,
		lineBreak: lineBreak,
		lineBreakG: lineBreakG,
		nonASCIIwhitespace: nonASCIIwhitespace
	};

	// The main exported interface (under `self.acorn` when in the
	// browser) is a `parse` function that takes a code string and
	// returns an abstract syntax tree as specified by [Mozilla parser
	// API][api].
	//
	// [api]: https://developer.mozilla.org/en-US/docs/SpiderMonkey/Parser_API

	function parse(input, options) {
		return Parser.parse(input, options)
	}

	// This function tries to parse a single expression at a given
	// offset in a string. Useful for parsing mixed-language formats
	// that embed JavaScript expressions.

	function parseExpressionAt(input, pos, options) {
		return Parser.parseExpressionAt(input, pos, options)
	}

	// Acorn is organized as a tokenizer and a recursive-descent parser.
	// The `tokenizer` export provides an interface to the tokenizer.

	function tokenizer(input, options) {
		return Parser.tokenizer(input, options)
	}

	exports.Node = Node;
	exports.Parser = Parser;
	exports.Position = Position;
	exports.SourceLocation = SourceLocation;
	exports.TokContext = TokContext;
	exports.Token = Token;
	exports.TokenType = TokenType;
	exports.defaultOptions = defaultOptions;
	exports.getLineInfo = getLineInfo;
	exports.isIdentifierChar = isIdentifierChar;
	exports.isIdentifierStart = isIdentifierStart;
	exports.isNewLine = isNewLine;
	exports.keywordTypes = keywords;
	exports.lineBreak = lineBreak;
	exports.lineBreakG = lineBreakG;
	exports.nonASCIIwhitespace = nonASCIIwhitespace;
	exports.parse = parse;
	exports.parseExpressionAt = parseExpressionAt;
	exports.tokContexts = types;
	exports.tokTypes = types$1;
	exports.tokenizer = tokenizer;
	exports.version = version;

	Object.defineProperty(exports, '__esModule', { value: true });

}));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('acorn')) :
	typeof define === 'function' && define.amd ? define(['exports', 'acorn'], factory) :
	(global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global.acorn = global.acorn || {}, global.acorn.loose = {}), global.acorn));
})(this, (function (exports, acorn) { 'use strict';

	var dummyValue = "✖";

	function isDummy(node) { return node.name === dummyValue }

	function noop() {}

	var LooseParser = function LooseParser(input, options) {
		if ( options === void 0 ) options = {};

		this.toks = this.constructor.BaseParser.tokenizer(input, options);
		this.options = this.toks.options;
		this.input = this.toks.input;
		this.tok = this.last = {type: acorn.tokTypes.eof, start: 0, end: 0};
		this.tok.validateRegExpFlags = noop;
		this.tok.validateRegExpPattern = noop;
		if (this.options.locations) {
			var here = this.toks.curPosition();
			this.tok.loc = new acorn.SourceLocation(this.toks, here, here);
		}
		this.ahead = []; // Tokens ahead
		this.context = []; // Indentation contexted
		this.curIndent = 0;
		this.curLineStart = 0;
		this.nextLineStart = this.lineEnd(this.curLineStart) + 1;
		this.inAsync = false;
		this.inGenerator = false;
		this.inFunction = false;
	};

	LooseParser.prototype.startNode = function startNode () {
		return new acorn.Node(this.toks, this.tok.start, this.options.locations ? this.tok.loc.start : null)
	};

	LooseParser.prototype.storeCurrentPos = function storeCurrentPos () {
		return this.options.locations ? [this.tok.start, this.tok.loc.start] : this.tok.start
	};

	LooseParser.prototype.startNodeAt = function startNodeAt (pos) {
		if (this.options.locations) {
			return new acorn.Node(this.toks, pos[0], pos[1])
		} else {
			return new acorn.Node(this.toks, pos)
		}
	};

	LooseParser.prototype.finishNode = function finishNode (node, type) {
		node.type = type;
		node.end = this.last.end;
		if (this.options.locations)
			{ node.loc.end = this.last.loc.end; }
		if (this.options.ranges)
			{ node.range[1] = this.last.end; }
		return node
	};

	LooseParser.prototype.dummyNode = function dummyNode (type) {
		var dummy = this.startNode();
		dummy.type = type;
		dummy.end = dummy.start;
		if (this.options.locations)
			{ dummy.loc.end = dummy.loc.start; }
		if (this.options.ranges)
			{ dummy.range[1] = dummy.start; }
		this.last = {type: acorn.tokTypes.name, start: dummy.start, end: dummy.start, loc: dummy.loc};
		return dummy
	};

	LooseParser.prototype.dummyIdent = function dummyIdent () {
		var dummy = this.dummyNode("Identifier");
		dummy.name = dummyValue;
		return dummy
	};

	LooseParser.prototype.dummyString = function dummyString () {
		var dummy = this.dummyNode("Literal");
		dummy.value = dummy.raw = dummyValue;
		return dummy
	};

	LooseParser.prototype.eat = function eat (type) {
		if (this.tok.type === type) {
			this.next();
			return true
		} else {
			return false
		}
	};

	LooseParser.prototype.isContextual = function isContextual (name) {
		return this.tok.type === acorn.tokTypes.name && this.tok.value === name
	};

	LooseParser.prototype.eatContextual = function eatContextual (name) {
		return this.tok.value === name && this.eat(acorn.tokTypes.name)
	};

	LooseParser.prototype.canInsertSemicolon = function canInsertSemicolon () {
		return this.tok.type === acorn.tokTypes.eof || this.tok.type === acorn.tokTypes.braceR ||
			acorn.lineBreak.test(this.input.slice(this.last.end, this.tok.start))
	};

	LooseParser.prototype.semicolon = function semicolon () {
		return this.eat(acorn.tokTypes.semi)
	};

	LooseParser.prototype.expect = function expect (type) {
		if (this.eat(type)) { return true }
		for (var i = 1; i <= 2; i++) {
			if (this.lookAhead(i).type === type) {
				for (var j = 0; j < i; j++) { this.next(); }
				return true
			}
		}
	};

	LooseParser.prototype.pushCx = function pushCx () {
		this.context.push(this.curIndent);
	};

	LooseParser.prototype.popCx = function popCx () {
		this.curIndent = this.context.pop();
	};

	LooseParser.prototype.lineEnd = function lineEnd (pos) {
		while (pos < this.input.length && !acorn.isNewLine(this.input.charCodeAt(pos))) { ++pos; }
		return pos
	};

	LooseParser.prototype.indentationAfter = function indentationAfter (pos) {
		for (var count = 0;; ++pos) {
			var ch = this.input.charCodeAt(pos);
			if (ch === 32) { ++count; }
			else if (ch === 9) { count += this.options.tabSize; }
			else { return count }
		}
	};

	LooseParser.prototype.closes = function closes (closeTok, indent, line, blockHeuristic) {
		if (this.tok.type === closeTok || this.tok.type === acorn.tokTypes.eof) { return true }
		return line !== this.curLineStart && this.curIndent < indent && this.tokenStartsLine() &&
			(!blockHeuristic || this.nextLineStart >= this.input.length ||
			this.indentationAfter(this.nextLineStart) < indent)
	};

	LooseParser.prototype.tokenStartsLine = function tokenStartsLine () {
		for (var p = this.tok.start - 1; p >= this.curLineStart; --p) {
			var ch = this.input.charCodeAt(p);
			if (ch !== 9 && ch !== 32) { return false }
		}
		return true
	};

	LooseParser.prototype.extend = function extend (name, f) {
		this[name] = f(this[name]);
	};

	LooseParser.prototype.parse = function parse () {
		this.next();
		return this.parseTopLevel()
	};

	LooseParser.extend = function extend () {
			var plugins = [], len = arguments.length;
			while ( len-- ) plugins[ len ] = arguments[ len ];

		var cls = this;
		for (var i = 0; i < plugins.length; i++) { cls = plugins[i](cls); }
		return cls
	};

	LooseParser.parse = function parse (input, options) {
		return new this(input, options).parse()
	};

	// Allows plugins to extend the base parser / tokenizer used
	LooseParser.BaseParser = acorn.Parser;

	var lp$2 = LooseParser.prototype;

	function isSpace(ch) {
		return (ch < 14 && ch > 8) || ch === 32 || ch === 160 || acorn.isNewLine(ch)
	}

	lp$2.next = function() {
		this.last = this.tok;
		if (this.ahead.length)
			{ this.tok = this.ahead.shift(); }
		else
			{ this.tok = this.readToken(); }

		if (this.tok.start >= this.nextLineStart) {
			while (this.tok.start >= this.nextLineStart) {
				this.curLineStart = this.nextLineStart;
				this.nextLineStart = this.lineEnd(this.curLineStart) + 1;
			}
			this.curIndent = this.indentationAfter(this.curLineStart);
		}
	};

	lp$2.readToken = function() {
		for (;;) {
			try {
				this.toks.next();
				if (this.toks.type === acorn.tokTypes.dot &&
						this.input.substr(this.toks.end, 1) === "." &&
						this.options.ecmaVersion >= 6) {
					this.toks.end++;
					this.toks.type = acorn.tokTypes.ellipsis;
				}
				return new acorn.Token(this.toks)
			} catch (e) {
				if (!(e instanceof SyntaxError)) { throw e }

				// Try to skip some text, based on the error message, and then continue
				var msg = e.message, pos = e.raisedAt, replace = true;
				if (/unterminated/i.test(msg)) {
					pos = this.lineEnd(e.pos + 1);
					if (/string/.test(msg)) {
						replace = {start: e.pos, end: pos, type: acorn.tokTypes.string, value: this.input.slice(e.pos + 1, pos)};
					} else if (/regular expr/i.test(msg)) {
						var re = this.input.slice(e.pos, pos);
						try { re = new RegExp(re); } catch (e$1) { /* ignore compilation error due to new syntax */ }
						replace = {start: e.pos, end: pos, type: acorn.tokTypes.regexp, value: re};
					} else if (/template/.test(msg)) {
						replace = {
							start: e.pos,
							end: pos,
							type: acorn.tokTypes.template,
							value: this.input.slice(e.pos, pos)
						};
					} else {
						replace = false;
					}
				} else if (/invalid (unicode|regexp|number)|expecting unicode|octal literal|is reserved|directly after number|expected number in radix/i.test(msg)) {
					while (pos < this.input.length && !isSpace(this.input.charCodeAt(pos))) { ++pos; }
				} else if (/character escape|expected hexadecimal/i.test(msg)) {
					while (pos < this.input.length) {
						var ch = this.input.charCodeAt(pos++);
						if (ch === 34 || ch === 39 || acorn.isNewLine(ch)) { break }
					}
				} else if (/unexpected character/i.test(msg)) {
					pos++;
					replace = false;
				} else if (/regular expression/i.test(msg)) {
					replace = true;
				} else {
					throw e
				}
				this.resetTo(pos);
				if (replace === true) { replace = {start: pos, end: pos, type: acorn.tokTypes.name, value: dummyValue}; }
				if (replace) {
					if (this.options.locations)
						{ replace.loc = new acorn.SourceLocation(
							this.toks,
							acorn.getLineInfo(this.input, replace.start),
							acorn.getLineInfo(this.input, replace.end)); }
					return replace
				}
			}
		}
	};

	lp$2.resetTo = function(pos) {
		this.toks.pos = pos;
		var ch = this.input.charAt(pos - 1);
		this.toks.exprAllowed = !ch || /[[{(,;:?/*=+\-~!|&%^<>]/.test(ch) ||
			/[enwfd]/.test(ch) &&
			/\b(case|else|return|throw|new|in|(instance|type)?of|delete|void)$/.test(this.input.slice(pos - 10, pos));

		if (this.options.locations) {
			this.toks.curLine = 1;
			this.toks.lineStart = acorn.lineBreakG.lastIndex = 0;
			var match;
			while ((match = acorn.lineBreakG.exec(this.input)) && match.index < pos) {
				++this.toks.curLine;
				this.toks.lineStart = match.index + match[0].length;
			}
		}
	};

	lp$2.lookAhead = function(n) {
		while (n > this.ahead.length)
			{ this.ahead.push(this.readToken()); }
		return this.ahead[n - 1]
	};

	var lp$1 = LooseParser.prototype;

	lp$1.parseTopLevel = function() {
		var node = this.startNodeAt(this.options.locations ? [0, acorn.getLineInfo(this.input, 0)] : 0);
		node.body = [];
		while (this.tok.type !== acorn.tokTypes.eof) { node.body.push(this.parseStatement()); }
		this.toks.adaptDirectivePrologue(node.body);
		this.last = this.tok;
		node.sourceType = this.options.sourceType;
		return this.finishNode(node, "Program")
	};

	lp$1.parseStatement = function() {
		var starttype = this.tok.type, node = this.startNode(), kind;

		if (this.toks.isLet()) {
			starttype = acorn.tokTypes._var;
			kind = "let";
		}

		switch (starttype) {
		case acorn.tokTypes._break: case acorn.tokTypes._continue:
			this.next();
			var isBreak = starttype === acorn.tokTypes._break;
			if (this.semicolon() || this.canInsertSemicolon()) {
				node.label = null;
			} else {
				node.label = this.tok.type === acorn.tokTypes.name ? this.parseIdent() : null;
				this.semicolon();
			}
			return this.finishNode(node, isBreak ? "BreakStatement" : "ContinueStatement")

		case acorn.tokTypes._debugger:
			this.next();
			this.semicolon();
			return this.finishNode(node, "DebuggerStatement")

		case acorn.tokTypes._do:
			this.next();
			node.body = this.parseStatement();
			node.test = this.eat(acorn.tokTypes._while) ? this.parseParenExpression() : this.dummyIdent();
			this.semicolon();
			return this.finishNode(node, "DoWhileStatement")

		case acorn.tokTypes._for:
			this.next(); // `for` keyword
			var isAwait = this.options.ecmaVersion >= 9 && this.eatContextual("await");

			this.pushCx();
			this.expect(acorn.tokTypes.parenL);
			if (this.tok.type === acorn.tokTypes.semi) { return this.parseFor(node, null) }
			var isLet = this.toks.isLet();
			if (isLet || this.tok.type === acorn.tokTypes._var || this.tok.type === acorn.tokTypes._const) {
				var init$1 = this.parseVar(this.startNode(), true, isLet ? "let" : this.tok.value);
				if (init$1.declarations.length === 1 && (this.tok.type === acorn.tokTypes._in || this.isContextual("of"))) {
					if (this.options.ecmaVersion >= 9 && this.tok.type !== acorn.tokTypes._in) {
						node.await = isAwait;
					}
					return this.parseForIn(node, init$1)
				}
				return this.parseFor(node, init$1)
			}
			var init = this.parseExpression(true);
			if (this.tok.type === acorn.tokTypes._in || this.isContextual("of")) {
				if (this.options.ecmaVersion >= 9 && this.tok.type !== acorn.tokTypes._in) {
					node.await = isAwait;
				}
				return this.parseForIn(node, this.toAssignable(init))
			}
			return this.parseFor(node, init)

		case acorn.tokTypes._function:
			this.next();
			return this.parseFunction(node, true)

		case acorn.tokTypes._if:
			this.next();
			node.test = this.parseParenExpression();
			node.consequent = this.parseStatement();
			node.alternate = this.eat(acorn.tokTypes._else) ? this.parseStatement() : null;
			return this.finishNode(node, "IfStatement")

		case acorn.tokTypes._return:
			this.next();
			if (this.eat(acorn.tokTypes.semi) || this.canInsertSemicolon()) { node.argument = null; }
			else { node.argument = this.parseExpression(); this.semicolon(); }
			return this.finishNode(node, "ReturnStatement")

		case acorn.tokTypes._switch:
			var blockIndent = this.curIndent, line = this.curLineStart;
			this.next();
			node.discriminant = this.parseParenExpression();
			node.cases = [];
			this.pushCx();
			this.expect(acorn.tokTypes.braceL);

			var cur;
			while (!this.closes(acorn.tokTypes.braceR, blockIndent, line, true)) {
				if (this.tok.type === acorn.tokTypes._case || this.tok.type === acorn.tokTypes._default) {
					var isCase = this.tok.type === acorn.tokTypes._case;
					if (cur) { this.finishNode(cur, "SwitchCase"); }
					node.cases.push(cur = this.startNode());
					cur.consequent = [];
					this.next();
					if (isCase) { cur.test = this.parseExpression(); }
					else { cur.test = null; }
					this.expect(acorn.tokTypes.colon);
				} else {
					if (!cur) {
						node.cases.push(cur = this.startNode());
						cur.consequent = [];
						cur.test = null;
					}
					cur.consequent.push(this.parseStatement());
				}
			}
			if (cur) { this.finishNode(cur, "SwitchCase"); }
			this.popCx();
			this.eat(acorn.tokTypes.braceR);
			return this.finishNode(node, "SwitchStatement")

		case acorn.tokTypes._throw:
			this.next();
			node.argument = this.parseExpression();
			this.semicolon();
			return this.finishNode(node, "ThrowStatement")

		case acorn.tokTypes._try:
			this.next();
			node.block = this.parseBlock();
			node.handler = null;
			if (this.tok.type === acorn.tokTypes._catch) {
				var clause = this.startNode();
				this.next();
				if (this.eat(acorn.tokTypes.parenL)) {
					clause.param = this.toAssignable(this.parseExprAtom(), true);
					this.expect(acorn.tokTypes.parenR);
				} else {
					clause.param = null;
				}
				clause.body = this.parseBlock();
				node.handler = this.finishNode(clause, "CatchClause");
			}
			node.finalizer = this.eat(acorn.tokTypes._finally) ? this.parseBlock() : null;
			if (!node.handler && !node.finalizer) { return node.block }
			return this.finishNode(node, "TryStatement")

		case acorn.tokTypes._var:
		case acorn.tokTypes._const:
			return this.parseVar(node, false, kind || this.tok.value)

		case acorn.tokTypes._while:
			this.next();
			node.test = this.parseParenExpression();
			node.body = this.parseStatement();
			return this.finishNode(node, "WhileStatement")

		case acorn.tokTypes._with:
			this.next();
			node.object = this.parseParenExpression();
			node.body = this.parseStatement();
			return this.finishNode(node, "WithStatement")

		case acorn.tokTypes.braceL:
			return this.parseBlock()

		case acorn.tokTypes.semi:
			this.next();
			return this.finishNode(node, "EmptyStatement")

		case acorn.tokTypes._class:
			return this.parseClass(true)

		case acorn.tokTypes._import:
			if (this.options.ecmaVersion > 10) {
				var nextType = this.lookAhead(1).type;
				if (nextType === acorn.tokTypes.parenL || nextType === acorn.tokTypes.dot) {
					node.expression = this.parseExpression();
					this.semicolon();
					return this.finishNode(node, "ExpressionStatement")
				}
			}

			return this.parseImport()

		case acorn.tokTypes._export:
			return this.parseExport()

		default:
			if (this.toks.isAsyncFunction()) {
				this.next();
				this.next();
				return this.parseFunction(node, true, true)
			}
			var expr = this.parseExpression();
			if (isDummy(expr)) {
				this.next();
				if (this.tok.type === acorn.tokTypes.eof) { return this.finishNode(node, "EmptyStatement") }
				return this.parseStatement()
			} else if (starttype === acorn.tokTypes.name && expr.type === "Identifier" && this.eat(acorn.tokTypes.colon)) {
				node.body = this.parseStatement();
				node.label = expr;
				return this.finishNode(node, "LabeledStatement")
			} else {
				node.expression = expr;
				this.semicolon();
				return this.finishNode(node, "ExpressionStatement")
			}
		}
	};

	lp$1.parseBlock = function() {
		var node = this.startNode();
		this.pushCx();
		this.expect(acorn.tokTypes.braceL);
		var blockIndent = this.curIndent, line = this.curLineStart;
		node.body = [];
		while (!this.closes(acorn.tokTypes.braceR, blockIndent, line, true))
			{ node.body.push(this.parseStatement()); }
		this.popCx();
		this.eat(acorn.tokTypes.braceR);
		return this.finishNode(node, "BlockStatement")
	};

	lp$1.parseFor = function(node, init) {
		node.init = init;
		node.test = node.update = null;
		if (this.eat(acorn.tokTypes.semi) && this.tok.type !== acorn.tokTypes.semi) { node.test = this.parseExpression(); }
		if (this.eat(acorn.tokTypes.semi) && this.tok.type !== acorn.tokTypes.parenR) { node.update = this.parseExpression(); }
		this.popCx();
		this.expect(acorn.tokTypes.parenR);
		node.body = this.parseStatement();
		return this.finishNode(node, "ForStatement")
	};

	lp$1.parseForIn = function(node, init) {
		var type = this.tok.type === acorn.tokTypes._in ? "ForInStatement" : "ForOfStatement";
		this.next();
		node.left = init;
		node.right = this.parseExpression();
		this.popCx();
		this.expect(acorn.tokTypes.parenR);
		node.body = this.parseStatement();
		return this.finishNode(node, type)
	};

	lp$1.parseVar = function(node, noIn, kind) {
		node.kind = kind;
		this.next();
		node.declarations = [];
		do {
			var decl = this.startNode();
			decl.id = this.options.ecmaVersion >= 6 ? this.toAssignable(this.parseExprAtom(), true) : this.parseIdent();
			decl.init = this.eat(acorn.tokTypes.eq) ? this.parseMaybeAssign(noIn) : null;
			node.declarations.push(this.finishNode(decl, "VariableDeclarator"));
		} while (this.eat(acorn.tokTypes.comma))
		if (!node.declarations.length) {
			var decl$1 = this.startNode();
			decl$1.id = this.dummyIdent();
			node.declarations.push(this.finishNode(decl$1, "VariableDeclarator"));
		}
		if (!noIn) { this.semicolon(); }
		return this.finishNode(node, "VariableDeclaration")
	};

	lp$1.parseClass = function(isStatement) {
		var node = this.startNode();
		this.next();
		if (this.tok.type === acorn.tokTypes.name) { node.id = this.parseIdent(); }
		else if (isStatement === true) { node.id = this.dummyIdent(); }
		else { node.id = null; }
		node.superClass = this.eat(acorn.tokTypes._extends) ? this.parseExpression() : null;
		node.body = this.startNode();
		node.body.body = [];
		this.pushCx();
		var indent = this.curIndent + 1, line = this.curLineStart;
		this.eat(acorn.tokTypes.braceL);
		if (this.curIndent + 1 < indent) { indent = this.curIndent; line = this.curLineStart; }
		while (!this.closes(acorn.tokTypes.braceR, indent, line)) {
			var element = this.parseClassElement();
			if (element) { node.body.body.push(element); }
		}
		this.popCx();
		if (!this.eat(acorn.tokTypes.braceR)) {
			// If there is no closing brace, make the node span to the start
			// of the next token (this is useful for Tern)
			this.last.end = this.tok.start;
			if (this.options.locations) { this.last.loc.end = this.tok.loc.start; }
		}
		this.semicolon();
		this.finishNode(node.body, "ClassBody");
		return this.finishNode(node, isStatement ? "ClassDeclaration" : "ClassExpression")
	};

	lp$1.parseClassElement = function() {
		if (this.eat(acorn.tokTypes.semi)) { return null }

		var ref = this.options;
		var ecmaVersion = ref.ecmaVersion;
		var locations = ref.locations;
		var indent = this.curIndent;
		var line = this.curLineStart;
		var node = this.startNode();
		var keyName = "";
		var isGenerator = false;
		var isAsync = false;
		var kind = "method";
		var isStatic = false;

		if (this.eatContextual("static")) {
			// Parse static init block
			if (ecmaVersion >= 13 && this.eat(acorn.tokTypes.braceL)) {
				this.parseClassStaticBlock(node);
				return node
			}
			if (this.isClassElementNameStart() || this.toks.type === acorn.tokTypes.star) {
				isStatic = true;
			} else {
				keyName = "static";
			}
		}
		node.static = isStatic;
		if (!keyName && ecmaVersion >= 8 && this.eatContextual("async")) {
			if ((this.isClassElementNameStart() || this.toks.type === acorn.tokTypes.star) && !this.canInsertSemicolon()) {
				isAsync = true;
			} else {
				keyName = "async";
			}
		}
		if (!keyName) {
			isGenerator = this.eat(acorn.tokTypes.star);
			var lastValue = this.toks.value;
			if (this.eatContextual("get") || this.eatContextual("set")) {
				if (this.isClassElementNameStart()) {
					kind = lastValue;
				} else {
					keyName = lastValue;
				}
			}
		}

		// Parse element name
		if (keyName) {
			// 'async', 'get', 'set', or 'static' were not a keyword contextually.
			// The last token is any of those. Make it the element name.
			node.computed = false;
			node.key = this.startNodeAt(locations ? [this.toks.lastTokStart, this.toks.lastTokStartLoc] : this.toks.lastTokStart);
			node.key.name = keyName;
			this.finishNode(node.key, "Identifier");
		} else {
			this.parseClassElementName(node);

			// From https://github.com/acornjs/acorn/blob/7deba41118d6384a2c498c61176b3cf434f69590/acorn-loose/src/statement.js#L291
			// Skip broken stuff.
			if (isDummy(node.key)) {
				if (isDummy(this.parseMaybeAssign())) { this.next(); }
				this.eat(acorn.tokTypes.comma);
				return null
			}
		}

		// Parse element value
		if (ecmaVersion < 13 || this.toks.type === acorn.tokTypes.parenL || kind !== "method" || isGenerator || isAsync) {
			// Method
			var isConstructor =
				!node.computed &&
				!node.static &&
				!isGenerator &&
				!isAsync &&
				kind === "method" && (
					node.key.type === "Identifier" && node.key.name === "constructor" ||
					node.key.type === "Literal" && node.key.value === "constructor"
				);
			node.kind = isConstructor ? "constructor" : kind;
			node.value = this.parseMethod(isGenerator, isAsync);
			this.finishNode(node, "MethodDefinition");
		} else {
			// Field
			if (this.eat(acorn.tokTypes.eq)) {
				if (this.curLineStart !== line && this.curIndent <= indent && this.tokenStartsLine()) {
					// Estimated the next line is the next class element by indentations.
					node.value = null;
				} else {
					var oldInAsync = this.inAsync;
					var oldInGenerator = this.inGenerator;
					this.inAsync = false;
					this.inGenerator = false;
					node.value = this.parseMaybeAssign();
					this.inAsync = oldInAsync;
					this.inGenerator = oldInGenerator;
				}
			} else {
				node.value = null;
			}
			this.semicolon();
			this.finishNode(node, "PropertyDefinition");
		}

		return node
	};

	lp$1.parseClassStaticBlock = function(node) {
		var blockIndent = this.curIndent, line = this.curLineStart;
		node.body = [];
		this.pushCx();
		while (!this.closes(acorn.tokTypes.braceR, blockIndent, line, true))
			{ node.body.push(this.parseStatement()); }
		this.popCx();
		this.eat(acorn.tokTypes.braceR);

		return this.finishNode(node, "StaticBlock")
	};

	lp$1.isClassElementNameStart = function() {
		return this.toks.isClassElementNameStart()
	};

	lp$1.parseClassElementName = function(element) {
		if (this.toks.type === acorn.tokTypes.privateId) {
			element.computed = false;
			element.key = this.parsePrivateIdent();
		} else {
			this.parsePropertyName(element);
		}
	};

	lp$1.parseFunction = function(node, isStatement, isAsync) {
		var oldInAsync = this.inAsync, oldInGenerator = this.inGenerator, oldInFunction = this.inFunction;
		this.initFunction(node);
		if (this.options.ecmaVersion >= 6) {
			node.generator = this.eat(acorn.tokTypes.star);
		}
		if (this.options.ecmaVersion >= 8) {
			node.async = !!isAsync;
		}
		if (this.tok.type === acorn.tokTypes.name) { node.id = this.parseIdent(); }
		else if (isStatement === true) { node.id = this.dummyIdent(); }
		this.inAsync = node.async;
		this.inGenerator = node.generator;
		this.inFunction = true;
		node.params = this.parseFunctionParams();
		node.body = this.parseBlock();
		this.toks.adaptDirectivePrologue(node.body.body);
		this.inAsync = oldInAsync;
		this.inGenerator = oldInGenerator;
		this.inFunction = oldInFunction;
		return this.finishNode(node, isStatement ? "FunctionDeclaration" : "FunctionExpression")
	};

	lp$1.parseExport = function() {
		var node = this.startNode();
		this.next();
		if (this.eat(acorn.tokTypes.star)) {
			if (this.options.ecmaVersion >= 11) {
				if (this.eatContextual("as")) {
					node.exported = this.parseExprAtom();
				} else {
					node.exported = null;
				}
			}
			node.source = this.eatContextual("from") ? this.parseExprAtom() : this.dummyString();
			this.semicolon();
			return this.finishNode(node, "ExportAllDeclaration")
		}
		if (this.eat(acorn.tokTypes._default)) {
			// export default (function foo() {}) // This is FunctionExpression.
			var isAsync;
			if (this.tok.type === acorn.tokTypes._function || (isAsync = this.toks.isAsyncFunction())) {
				var fNode = this.startNode();
				this.next();
				if (isAsync) { this.next(); }
				node.declaration = this.parseFunction(fNode, "nullableID", isAsync);
			} else if (this.tok.type === acorn.tokTypes._class) {
				node.declaration = this.parseClass("nullableID");
			} else {
				node.declaration = this.parseMaybeAssign();
				this.semicolon();
			}
			return this.finishNode(node, "ExportDefaultDeclaration")
		}
		if (this.tok.type.keyword || this.toks.isLet() || this.toks.isAsyncFunction()) {
			node.declaration = this.parseStatement();
			node.specifiers = [];
			node.source = null;
		} else {
			node.declaration = null;
			node.specifiers = this.parseExportSpecifierList();
			node.source = this.eatContextual("from") ? this.parseExprAtom() : null;
			this.semicolon();
		}
		return this.finishNode(node, "ExportNamedDeclaration")
	};

	lp$1.parseImport = function() {
		var node = this.startNode();
		this.next();
		if (this.tok.type === acorn.tokTypes.string) {
			node.specifiers = [];
			node.source = this.parseExprAtom();
		} else {
			var elt;
			if (this.tok.type === acorn.tokTypes.name && this.tok.value !== "from") {
				elt = this.startNode();
				elt.local = this.parseIdent();
				this.finishNode(elt, "ImportDefaultSpecifier");
				this.eat(acorn.tokTypes.comma);
			}
			node.specifiers = this.parseImportSpecifiers();
			node.source = this.eatContextual("from") && this.tok.type === acorn.tokTypes.string ? this.parseExprAtom() : this.dummyString();
			if (elt) { node.specifiers.unshift(elt); }
		}
		this.semicolon();
		return this.finishNode(node, "ImportDeclaration")
	};

	lp$1.parseImportSpecifiers = function() {
		var elts = [];
		if (this.tok.type === acorn.tokTypes.star) {
			var elt = this.startNode();
			this.next();
			elt.local = this.eatContextual("as") ? this.parseIdent() : this.dummyIdent();
			elts.push(this.finishNode(elt, "ImportNamespaceSpecifier"));
		} else {
			var indent = this.curIndent, line = this.curLineStart, continuedLine = this.nextLineStart;
			this.pushCx();
			this.eat(acorn.tokTypes.braceL);
			if (this.curLineStart > continuedLine) { continuedLine = this.curLineStart; }
			while (!this.closes(acorn.tokTypes.braceR, indent + (this.curLineStart <= continuedLine ? 1 : 0), line)) {
				var elt$1 = this.startNode();
				if (this.eat(acorn.tokTypes.star)) {
					elt$1.local = this.eatContextual("as") ? this.parseModuleExportName() : this.dummyIdent();
					this.finishNode(elt$1, "ImportNamespaceSpecifier");
				} else {
					if (this.isContextual("from")) { break }
					elt$1.imported = this.parseModuleExportName();
					if (isDummy(elt$1.imported)) { break }
					elt$1.local = this.eatContextual("as") ? this.parseModuleExportName() : elt$1.imported;
					this.finishNode(elt$1, "ImportSpecifier");
				}
				elts.push(elt$1);
				this.eat(acorn.tokTypes.comma);
			}
			this.eat(acorn.tokTypes.braceR);
			this.popCx();
		}
		return elts
	};

	lp$1.parseExportSpecifierList = function() {
		var elts = [];
		var indent = this.curIndent, line = this.curLineStart, continuedLine = this.nextLineStart;
		this.pushCx();
		this.eat(acorn.tokTypes.braceL);
		if (this.curLineStart > continuedLine) { continuedLine = this.curLineStart; }
		while (!this.closes(acorn.tokTypes.braceR, indent + (this.curLineStart <= continuedLine ? 1 : 0), line)) {
			if (this.isContextual("from")) { break }
			var elt = this.startNode();
			elt.local = this.parseModuleExportName();
			if (isDummy(elt.local)) { break }
			elt.exported = this.eatContextual("as") ? this.parseModuleExportName() : elt.local;
			this.finishNode(elt, "ExportSpecifier");
			elts.push(elt);
			this.eat(acorn.tokTypes.comma);
		}
		this.eat(acorn.tokTypes.braceR);
		this.popCx();
		return elts
	};

	lp$1.parseModuleExportName = function() {
		return this.options.ecmaVersion >= 13 && this.tok.type === acorn.tokTypes.string
			? this.parseExprAtom()
			: this.parseIdent()
	};

	var lp = LooseParser.prototype;

	lp.checkLVal = function(expr) {
		if (!expr) { return expr }
		switch (expr.type) {
		case "Identifier":
		case "MemberExpression":
			return expr

		case "ParenthesizedExpression":
			expr.expression = this.checkLVal(expr.expression);
			return expr

		default:
			return this.dummyIdent()
		}
	};

	lp.parseExpression = function(noIn) {
		var start = this.storeCurrentPos();
		var expr = this.parseMaybeAssign(noIn);
		if (this.tok.type === acorn.tokTypes.comma) {
			var node = this.startNodeAt(start);
			node.expressions = [expr];
			while (this.eat(acorn.tokTypes.comma)) { node.expressions.push(this.parseMaybeAssign(noIn)); }
			return this.finishNode(node, "SequenceExpression")
		}
		return expr
	};

	lp.parseParenExpression = function() {
		this.pushCx();
		this.expect(acorn.tokTypes.parenL);
		var val = this.parseExpression();
		this.popCx();
		this.expect(acorn.tokTypes.parenR);
		return val
	};

	lp.parseMaybeAssign = function(noIn) {
		// `yield` should be an identifier reference if it's not in generator functions.
		if (this.inGenerator && this.toks.isContextual("yield")) {
			var node = this.startNode();
			this.next();
			if (this.semicolon() || this.canInsertSemicolon() || (this.tok.type !== acorn.tokTypes.star && !this.tok.type.startsExpr)) {
				node.delegate = false;
				node.argument = null;
			} else {
				node.delegate = this.eat(acorn.tokTypes.star);
				node.argument = this.parseMaybeAssign();
			}
			return this.finishNode(node, "YieldExpression")
		}

		var start = this.storeCurrentPos();
		var left = this.parseMaybeConditional(noIn);
		if (this.tok.type.isAssign) {
			var node$1 = this.startNodeAt(start);
			node$1.operator = this.tok.value;
			node$1.left = this.tok.type === acorn.tokTypes.eq ? this.toAssignable(left) : this.checkLVal(left);
			this.next();
			node$1.right = this.parseMaybeAssign(noIn);
			return this.finishNode(node$1, "AssignmentExpression")
		}
		return left
	};

	lp.parseMaybeConditional = function(noIn) {
		var start = this.storeCurrentPos();
		var expr = this.parseExprOps(noIn);
		if (this.eat(acorn.tokTypes.question)) {
			var node = this.startNodeAt(start);
			node.test = expr;
			node.consequent = this.parseMaybeAssign();
			node.alternate = this.expect(acorn.tokTypes.colon) ? this.parseMaybeAssign(noIn) : this.dummyIdent();
			return this.finishNode(node, "ConditionalExpression")
		}
		return expr
	};

	lp.parseExprOps = function(noIn) {
		var start = this.storeCurrentPos();
		var indent = this.curIndent, line = this.curLineStart;
		return this.parseExprOp(this.parseMaybeUnary(false), start, -1, noIn, indent, line)
	};

	lp.parseExprOp = function(left, start, minPrec, noIn, indent, line) {
		if (this.curLineStart !== line && this.curIndent < indent && this.tokenStartsLine()) { return left }
		var prec = this.tok.type.binop;
		if (prec != null && (!noIn || this.tok.type !== acorn.tokTypes._in)) {
			if (prec > minPrec) {
				var node = this.startNodeAt(start);
				node.left = left;
				node.operator = this.tok.value;
				this.next();
				if (this.curLineStart !== line && this.curIndent < indent && this.tokenStartsLine()) {
					node.right = this.dummyIdent();
				} else {
					var rightStart = this.storeCurrentPos();
					node.right = this.parseExprOp(this.parseMaybeUnary(false), rightStart, prec, noIn, indent, line);
				}
				this.finishNode(node, /&&|\|\||\?\?/.test(node.operator) 
					? "LogicalExpression" : "BinaryExpression");
				return this.parseExprOp(node, start, minPrec, noIn, indent, line)
			}
		}
		return left
	};

	lp.parseMaybeUnary = function(sawUnary) {
		var start = this.storeCurrentPos(), expr;
		if (this.options.ecmaVersion >= 8 && this.toks.isContextual("await") &&
				(this.inAsync || (this.toks.inModule && this.options.ecmaVersion >= 13) ||
				(!this.inFunction && this.options.allowAwaitOutsideFunction))) {
			expr = this.parseAwait();
			sawUnary = true;
		} else if (this.tok.type.prefix) {
			var node = this.startNode(), update = this.tok.type === acorn.tokTypes.incDec;
			if (!update) { sawUnary = true; }
			node.operator = this.tok.value;
			node.prefix = true;
			this.next();
			node.argument = this.parseMaybeUnary(true);
			if (update) { node.argument = this.checkLVal(node.argument); }
			expr = this.finishNode(node, update ? "UpdateExpression" : "UnaryExpression");
		} else if (this.tok.type === acorn.tokTypes.ellipsis) {
			var node$1 = this.startNode();
			this.next();
			node$1.argument = this.parseMaybeUnary(sawUnary);
			expr = this.finishNode(node$1, "SpreadElement");
		} else if (!sawUnary && this.tok.type === acorn.tokTypes.privateId) {
			expr = this.parsePrivateIdent();
		} else {
			expr = this.parseExprSubscripts();
			while (this.tok.type.postfix && !this.canInsertSemicolon()) {
				var node$2 = this.startNodeAt(start);
				node$2.operator = this.tok.value;
				node$2.prefix = false;
				node$2.argument = this.checkLVal(expr);
				this.next();
				expr = this.finishNode(node$2, "UpdateExpression");
			}
		}

		if (!sawUnary && this.eat(acorn.tokTypes.starstar)) {
			var node$3 = this.startNodeAt(start);
			node$3.operator = "**";
			node$3.left = expr;
			node$3.right = this.parseMaybeUnary(false);
			return this.finishNode(node$3, "BinaryExpression")
		}

		return expr
	};

	lp.parseExprSubscripts = function() {
		var start = this.storeCurrentPos();
		return this.parseSubscripts(this.parseExprAtom(), start, false, this.curIndent, this.curLineStart)
	};

	lp.parseSubscripts = function(base, start, noCalls, startIndent, line) {
		var optionalSupported = this.options.ecmaVersion >= 11;
		var optionalChained = false;
		for (;;) {
			if (this.curLineStart !== line && this.curIndent <= startIndent && this.tokenStartsLine()) {
				if (this.tok.type === acorn.tokTypes.dot && this.curIndent === startIndent)
					{ --startIndent; }
				else
					{ break }
			}

			var maybeAsyncArrow = base.type === "Identifier" && base.name === "async" && !this.canInsertSemicolon();
			var optional = optionalSupported && this.eat(acorn.tokTypes.questionDot);
			if (optional) {
				optionalChained = true;
			}

			if ((optional && this.tok.type !== acorn.tokTypes.parenL && this.tok.type !== acorn.tokTypes.bracketL && this.tok.type !== acorn.tokTypes.backQuote) || this.eat(acorn.tokTypes.dot)) {
				var node = this.startNodeAt(start);
				node.object = base;
				if (this.curLineStart !== line && this.curIndent <= startIndent && this.tokenStartsLine())
					{ node.property = this.dummyIdent(); }
				else
					{ node.property = this.parsePropertyAccessor() || this.dummyIdent(); }
				node.computed = false;
				if (optionalSupported) {
					node.optional = optional;
				}
				base = this.finishNode(node, "MemberExpression");
			} else if (this.tok.type === acorn.tokTypes.bracketL) {
				this.pushCx();
				this.next();
				var node$1 = this.startNodeAt(start);
				node$1.object = base;
				node$1.property = this.parseExpression();
				node$1.computed = true;
				if (optionalSupported) {
					node$1.optional = optional;
				}
				this.popCx();
				this.expect(acorn.tokTypes.bracketR);
				base = this.finishNode(node$1, "MemberExpression");
			} else if (!noCalls && this.tok.type === acorn.tokTypes.parenL) {
				var exprList = this.parseExprList(acorn.tokTypes.parenR);
				if (maybeAsyncArrow && this.eat(acorn.tokTypes.arrow))
					{ return this.parseArrowExpression(this.startNodeAt(start), exprList, true) }
				var node$2 = this.startNodeAt(start);
				node$2.callee = base;
				node$2.arguments = exprList;
				if (optionalSupported) {
					node$2.optional = optional;
				}
				base = this.finishNode(node$2, "CallExpression");
			} else if (this.tok.type === acorn.tokTypes.backQuote) {
				var node$3 = this.startNodeAt(start);
				node$3.tag = base;
				node$3.quasi = this.parseTemplate();
				base = this.finishNode(node$3, "TaggedTemplateExpression");
			} else {
				break
			}
		}

		if (optionalChained) {
			var chainNode = this.startNodeAt(start);
			chainNode.expression = base;
			base = this.finishNode(chainNode, "ChainExpression");
		}
		return base
	};

	lp.parseExprAtom = function() {
		var node;
		switch (this.tok.type) {
		case acorn.tokTypes._this:
		case acorn.tokTypes._super:
			var type = this.tok.type === acorn.tokTypes._this ? "ThisExpression" : "Super";
			node = this.startNode();
			this.next();
			return this.finishNode(node, type)

		case acorn.tokTypes.name:
			var start = this.storeCurrentPos();
			var id = this.parseIdent();
			var isAsync = false;
			if (id.name === "async" && !this.canInsertSemicolon()) {
				if (this.eat(acorn.tokTypes._function)) {
					this.toks.overrideContext(acorn.tokContexts.f_expr);
					return this.parseFunction(this.startNodeAt(start), false, true)
				}
				if (this.tok.type === acorn.tokTypes.name) {
					id = this.parseIdent();
					isAsync = true;
				}
			}
			return this.eat(acorn.tokTypes.arrow) ? this.parseArrowExpression(this.startNodeAt(start), [id], isAsync) : id

		case acorn.tokTypes.regexp:
			node = this.startNode();
			var val = this.tok.value;
			node.regex = {pattern: val.pattern, flags: val.flags};
			node.value = val.value;
			node.raw = this.input.slice(this.tok.start, this.tok.end);
			this.next();
			return this.finishNode(node, "Literal")

		case acorn.tokTypes.num: case acorn.tokTypes.string:
			node = this.startNode();
			node.value = this.tok.value;
			node.raw = this.input.slice(this.tok.start, this.tok.end);
			if (this.tok.type === acorn.tokTypes.num && node.raw.charCodeAt(node.raw.length - 1) === 110) { node.bigint = node.raw.slice(0, -1).replace(/_/g, ""); }
			this.next();
			return this.finishNode(node, "Literal")

		case acorn.tokTypes._null: case acorn.tokTypes._true: case acorn.tokTypes._false:
			node = this.startNode();
			node.value = this.tok.type === acorn.tokTypes._null ? null : this.tok.type === acorn.tokTypes._true;
			node.raw = this.tok.type.keyword;
			this.next();
			return this.finishNode(node, "Literal")

		case acorn.tokTypes.parenL:
			var parenStart = this.storeCurrentPos();
			this.next();
			var inner = this.parseExpression();
			this.expect(acorn.tokTypes.parenR);
			if (this.eat(acorn.tokTypes.arrow)) {
				// (a,)=>a // SequenceExpression makes dummy in the last hole. Drop the dummy.
				var params = inner.expressions || [inner];
				if (params.length && isDummy(params[params.length - 1]))
					{ params.pop(); }
				return this.parseArrowExpression(this.startNodeAt(parenStart), params)
			}
			if (this.options.preserveParens) {
				var par = this.startNodeAt(parenStart);
				par.expression = inner;
				inner = this.finishNode(par, "ParenthesizedExpression");
			}
			return inner

		case acorn.tokTypes.bracketL:
			node = this.startNode();
			node.elements = this.parseExprList(acorn.tokTypes.bracketR, true);
			return this.finishNode(node, "ArrayExpression")

		case acorn.tokTypes.braceL:
			this.toks.overrideContext(acorn.tokContexts.b_expr);
			return this.parseObj()

		case acorn.tokTypes._class:
			return this.parseClass(false)

		case acorn.tokTypes._function:
			node = this.startNode();
			this.next();
			return this.parseFunction(node, false)

		case acorn.tokTypes._new:
			return this.parseNew()

		case acorn.tokTypes.backQuote:
			return this.parseTemplate()

		case acorn.tokTypes._import:
			if (this.options.ecmaVersion >= 11) {
				return this.parseExprImport()
			} else {
				return this.dummyIdent()
			}

		default:
			return this.dummyIdent()
		}
	};

	lp.parseExprImport = function() {
		var node = this.startNode();
		var meta = this.parseIdent(true);
		switch (this.tok.type) {
		case acorn.tokTypes.parenL:
			return this.parseDynamicImport(node)
		case acorn.tokTypes.dot:
			node.meta = meta;
			return this.parseImportMeta(node)
		default:
			node.name = "import";
			return this.finishNode(node, "Identifier")
		}
	};

	lp.parseDynamicImport = function(node) {
		node.source = this.parseExprList(acorn.tokTypes.parenR)[0] || this.dummyString();
		return this.finishNode(node, "ImportExpression")
	};

	lp.parseImportMeta = function(node) {
		this.next(); // skip '.'
		node.property = this.parseIdent(true);
		return this.finishNode(node, "MetaProperty")
	};

	lp.parseNew = function() {
		var node = this.startNode(), startIndent = this.curIndent, line = this.curLineStart;
		var meta = this.parseIdent(true);
		if (this.options.ecmaVersion >= 6 && this.eat(acorn.tokTypes.dot)) {
			node.meta = meta;
			node.property = this.parseIdent(true);
			return this.finishNode(node, "MetaProperty")
		}
		var start = this.storeCurrentPos();
		node.callee = this.parseSubscripts(this.parseExprAtom(), start, true, startIndent, line);
		if (this.tok.type === acorn.tokTypes.parenL) {
			node.arguments = this.parseExprList(acorn.tokTypes.parenR);
		} else {
			node.arguments = [];
		}
		return this.finishNode(node, "NewExpression")
	};

	lp.parseTemplateElement = function() {
		var elem = this.startNode();

		// The loose parser accepts invalid unicode escapes even in untagged templates.
		if (this.tok.type === acorn.tokTypes.invalidTemplate) {
			elem.value = {
				raw: this.tok.value,
				cooked: null
			};
		} else {
			elem.value = {
				raw: this.input.slice(this.tok.start, this.tok.end).replace(/\r\n?/g, "\n"),
				cooked: this.tok.value
			};
		}
		this.next();
		elem.tail = this.tok.type === acorn.tokTypes.backQuote;
		return this.finishNode(elem, "TemplateElement")
	};

	lp.parseTemplate = function() {
		var node = this.startNode();
		this.next();
		node.expressions = [];
		var curElt = this.parseTemplateElement();
		node.quasis = [curElt];
		while (!curElt.tail) {
			this.next();
			node.expressions.push(this.parseExpression());
			if (this.expect(acorn.tokTypes.braceR)) {
				curElt = this.parseTemplateElement();
			} else {
				curElt = this.startNode();
				curElt.value = {cooked: "", raw: ""};
				curElt.tail = true;
				this.finishNode(curElt, "TemplateElement");
			}
			node.quasis.push(curElt);
		}
		this.expect(acorn.tokTypes.backQuote);
		return this.finishNode(node, "TemplateLiteral")
	};

	lp.parseObj = function() {
		var node = this.startNode();
		node.properties = [];
		this.pushCx();
		var indent = this.curIndent + 1, line = this.curLineStart;
		this.eat(acorn.tokTypes.braceL);
		if (this.curIndent + 1 < indent) { indent = this.curIndent; line = this.curLineStart; }
		while (!this.closes(acorn.tokTypes.braceR, indent, line)) {
			var prop = this.startNode(), isGenerator = (void 0), isAsync = (void 0), start = (void 0);
			if (this.options.ecmaVersion >= 9 && this.eat(acorn.tokTypes.ellipsis)) {
				prop.argument = this.parseMaybeAssign();
				node.properties.push(this.finishNode(prop, "SpreadElement"));
				this.eat(acorn.tokTypes.comma);
				continue
			}
			if (this.options.ecmaVersion >= 6) {
				start = this.storeCurrentPos();
				prop.method = false;
				prop.shorthand = false;
				isGenerator = this.eat(acorn.tokTypes.star);
			}
			this.parsePropertyName(prop);
			if (this.toks.isAsyncProp(prop)) {
				isAsync = true;
				isGenerator = this.options.ecmaVersion >= 9 && this.eat(acorn.tokTypes.star);
				this.parsePropertyName(prop);
			} else {
				isAsync = false;
			}
			if (isDummy(prop.key)) { if (isDummy(this.parseMaybeAssign())) { this.next(); } this.eat(acorn.tokTypes.comma); continue }
			if (this.eat(acorn.tokTypes.colon)) {
				prop.kind = "init";
				prop.value = this.parseMaybeAssign();
			} else if (this.options.ecmaVersion >= 6 && (this.tok.type === acorn.tokTypes.parenL || this.tok.type === acorn.tokTypes.braceL)) {
				prop.kind = "init";
				prop.method = true;
				prop.value = this.parseMethod(isGenerator, isAsync);
			} else if (this.options.ecmaVersion >= 5 && prop.key.type === "Identifier" &&
								!prop.computed && (prop.key.name === "get" || prop.key.name === "set") &&
								(this.tok.type !== acorn.tokTypes.comma && this.tok.type !== acorn.tokTypes.braceR && this.tok.type !== acorn.tokTypes.eq)) {
				prop.kind = prop.key.name;
				this.parsePropertyName(prop);
				prop.value = this.parseMethod(false);
			} else {
				prop.kind = "init";
				if (this.options.ecmaVersion >= 6) {
					if (this.eat(acorn.tokTypes.eq)) {
						var assign = this.startNodeAt(start);
						assign.operator = "=";
						assign.left = prop.key;
						assign.right = this.parseMaybeAssign();
						prop.value = this.finishNode(assign, "AssignmentExpression");
					} else {
						prop.value = prop.key;
					}
				} else {
					prop.value = this.dummyIdent();
				}
				prop.shorthand = true;
			}
			node.properties.push(this.finishNode(prop, "Property"));
			this.eat(acorn.tokTypes.comma);
		}
		this.popCx();
		if (!this.eat(acorn.tokTypes.braceR)) {
			// If there is no closing brace, make the node span to the start
			// of the next token (this is useful for Tern)
			this.last.end = this.tok.start;
			if (this.options.locations) { this.last.loc.end = this.tok.loc.start; }
		}
		return this.finishNode(node, "ObjectExpression")
	};

	lp.parsePropertyName = function(prop) {
		if (this.options.ecmaVersion >= 6) {
			if (this.eat(acorn.tokTypes.bracketL)) {
				prop.computed = true;
				prop.key = this.parseExpression();
				this.expect(acorn.tokTypes.bracketR);
				return
			} else {
				prop.computed = false;
			}
		}
		var key = (this.tok.type === acorn.tokTypes.num || this.tok.type === acorn.tokTypes.string) ? this.parseExprAtom() : this.parseIdent();
		prop.key = key || this.dummyIdent();
	};

	lp.parsePropertyAccessor = function() {
		if (this.tok.type === acorn.tokTypes.name || this.tok.type.keyword) { return this.parseIdent() }
		if (this.tok.type === acorn.tokTypes.privateId) { return this.parsePrivateIdent() }
	};

	lp.parseIdent = function() {
		var name = this.tok.type === acorn.tokTypes.name ? this.tok.value : this.tok.type.keyword;
		if (!name) { return this.dummyIdent() }
		var node = this.startNode();
		this.next();
		node.name = name;
		return this.finishNode(node, "Identifier")
	};

	lp.parsePrivateIdent = function() {
		var node = this.startNode();
		node.name = this.tok.value;
		this.next();
		return this.finishNode(node, "PrivateIdentifier")
	};

	lp.initFunction = function(node) {
		node.id = null;
		node.params = [];
		if (this.options.ecmaVersion >= 6) {
			node.generator = false;
			node.expression = false;
		}
		if (this.options.ecmaVersion >= 8)
			{ node.async = false; }
	};

	// Convert existing expression atom to assignable pattern
	// if possible.

	lp.toAssignable = function(node, binding) {
		if (!node || node.type === "Identifier" || (node.type === "MemberExpression" && !binding)) ; else if (node.type === "ParenthesizedExpression") {
			this.toAssignable(node.expression, binding);
		} else if (this.options.ecmaVersion < 6) {
			return this.dummyIdent()
		} else if (node.type === "ObjectExpression") {
			node.type = "ObjectPattern";
			for (var i = 0, list = node.properties; i < list.length; i += 1)
				{
				var prop = list[i];

				this.toAssignable(prop, binding);
			}
		} else if (node.type === "ArrayExpression") {
			node.type = "ArrayPattern";
			this.toAssignableList(node.elements, binding);
		} else if (node.type === "Property") {
			this.toAssignable(node.value, binding);
		} else if (node.type === "SpreadElement") {
			node.type = "RestElement";
			this.toAssignable(node.argument, binding);
		} else if (node.type === "AssignmentExpression") {
			node.type = "AssignmentPattern";
			delete node.operator;
		} else {
			return this.dummyIdent()
		}
		return node
	};

	lp.toAssignableList = function(exprList, binding) {
		for (var i = 0, list = exprList; i < list.length; i += 1)
			{
			var expr = list[i];

			this.toAssignable(expr, binding);
		}
		return exprList
	};

	lp.parseFunctionParams = function(params) {
		params = this.parseExprList(acorn.tokTypes.parenR);
		return this.toAssignableList(params, true)
	};

	lp.parseMethod = function(isGenerator, isAsync) {
		var node = this.startNode(), oldInAsync = this.inAsync, oldInGenerator = this.inGenerator, oldInFunction = this.inFunction;
		this.initFunction(node);
		if (this.options.ecmaVersion >= 6)
			{ node.generator = !!isGenerator; }
		if (this.options.ecmaVersion >= 8)
			{ node.async = !!isAsync; }
		this.inAsync = node.async;
		this.inGenerator = node.generator;
		this.inFunction = true;
		node.params = this.parseFunctionParams();
		node.body = this.parseBlock();
		this.toks.adaptDirectivePrologue(node.body.body);
		this.inAsync = oldInAsync;
		this.inGenerator = oldInGenerator;
		this.inFunction = oldInFunction;
		return this.finishNode(node, "FunctionExpression")
	};

	lp.parseArrowExpression = function(node, params, isAsync) {
		var oldInAsync = this.inAsync, oldInGenerator = this.inGenerator, oldInFunction = this.inFunction;
		this.initFunction(node);
		if (this.options.ecmaVersion >= 8)
			{ node.async = !!isAsync; }
		this.inAsync = node.async;
		this.inGenerator = false;
		this.inFunction = true;
		node.params = this.toAssignableList(params, true);
		node.expression = this.tok.type !== acorn.tokTypes.braceL;
		if (node.expression) {
			node.body = this.parseMaybeAssign();
		} else {
			node.body = this.parseBlock();
			this.toks.adaptDirectivePrologue(node.body.body);
		}
		this.inAsync = oldInAsync;
		this.inGenerator = oldInGenerator;
		this.inFunction = oldInFunction;
		return this.finishNode(node, "ArrowFunctionExpression")
	};

	lp.parseExprList = function(close, allowEmpty) {
		this.pushCx();
		var indent = this.curIndent, line = this.curLineStart, elts = [];
		this.next(); // Opening bracket
		while (!this.closes(close, indent + 1, line)) {
			if (this.eat(acorn.tokTypes.comma)) {
				elts.push(allowEmpty ? null : this.dummyIdent());
				continue
			}
			var elt = this.parseMaybeAssign();
			if (isDummy(elt)) {
				if (this.closes(close, indent, line)) { break }
				this.next();
			} else {
				elts.push(elt);
			}
			this.eat(acorn.tokTypes.comma);
		}
		this.popCx();
		if (!this.eat(close)) {
			// If there is no closing brace, make the node span to the start
			// of the next token (this is useful for Tern)
			this.last.end = this.tok.start;
			if (this.options.locations) { this.last.loc.end = this.tok.loc.start; }
		}
		return elts
	};

	lp.parseAwait = function() {
		var node = this.startNode();
		this.next();
		node.argument = this.parseMaybeUnary();
		return this.finishNode(node, "AwaitExpression")
	};

	// Acorn: Loose parser

	function parse(input, options) {
		return LooseParser.parse(input, options)
	}

	exports.LooseParser = LooseParser;
	exports.isDummy = isDummy;
	exports.parse = parse;

	Object.defineProperty(exports, '__esModule', { value: true });

}));







const DEFAULT_DELAY = 1000
const DEFAULT_SHORT_DELAY = 100






// return an array of evaluated expression to pass into the next function call
async function runParameters(params, runContext) {
	let result = []
	for(let i = 0; i < params.length; i++) {
		let arg = params[i]
		result.push(await runStatement(0, [arg], runContext))
		if(!isStillRunning(runContext)) {
			return // bubble up
		}
	}
	return result
}

// API calls are now embedded in web page and uploaded to backend.js
//   see driver/library.js
let WEBDRIVER_API = {
	exports: {}
}


// TODO: add 
// @Late
// Syntax to use late binding, store the AST assignment in localVariables
//   And when the variable is accesssed, check for the AST and runStatement()



async function runCall(runContext, functionName, parameterDefinition, body, ...callArgs) {
	// assign to param names in next context
	let startVars = Object.assign({}, runContext.localVariables)

	let beforeLine = runContext.bubbleLine - 1 // -1 for wrapper function
	runContext.bubbleStack.push(functionName + ' . ' + beforeLine)

	for(let l = 0; l < parameterDefinition.length; l++) {
		if(parameterDefinition[l].type != 'Identifier') {
			throw new Error('FunctionDeclaration: Not implemented!')
		}
		if(l == callArgs.length) {
			continue;
		}
		runContext.localVariables[parameterDefinition[l].name] = callArgs[l]
	}

	// run new command context
	let result = await runStatement(0, [body], runContext)

	//Object.assign(runContext.localVariables, startVars) // reset references
	// TODO: LEAKY SCOPE, remove unnamed variables from previous scope
	// TODO: FIX SCOPING WITH A RUNCONTEXT.CONTEXTS STACK
	//   This would help solve var/let, automatically drop var into top context
	//   This would help with static/public/friendly checking
	//   This would help languages with leaky scopes by purpose, LUA, PROLOG?
	//   This would fix scoping around parameter definitions
	// TODO: search the contexts stack for the variable

	runContext.bubbleStack.pop()

	return result
}


let functionCounter = 0


function doAssert() {

}


function runPrimitive(AST, runContext) {
	if(AST.type == 'Literal') {
		return AST.value
	} else 
	if(AST.type == 'Identifier') {
		if(runContext.localVariables.hasOwnProperty(AST.name)) {
			return runContext.localVariables[AST.name]
		} else
		if(runContext.localFunctions.hasOwnProperty(AST.name)) {
			return runContext.localFunctions[AST.name]
		} else {
			throw new Error('Identifier not defined: ' + AST.name)
		}
	} else {
		throw new Error(AST.type + ': Not implemented!')
	}
}

async function runThisAndThat(_this, _that, runContext) {
	let left = await runStatement(0, [_this], runContext)
	if(!isStillRunning(runContext)) {
		return
	}

	let right = await runStatement(0, [_that], runContext)
	if(!isStillRunning(runContext)) {
		return
	}
	return [left, right]
}


async function runBinary(AST, runContext) {
	// TODO: cannot modulo a float
	let thisAndThat = await runThisAndThat(AST.left, AST.right, runContext)
	if(!isStillRunning(runContext)) {
		return
	}
	let left = thisAndThat[0]
	let right = thisAndThat[1]

	// MATHS!
	if(AST.operator == '*') {
		return left * right
	} else
	if(AST.operator == '/') {
		return left / right
	} else
	if(AST.operator == '+') {
		return left + right
	} else
	if(AST.operator == '-') {
		return left - right
	} else
	if(AST.operator == '%') {
		return left % right
	} else
	if(AST.operator == '^') {
		return left ^ right
	} else
	if(AST.operator == '<') {
		return left < right
	} else
	if(AST.operator == '>') {
		return left > right
	} else
	if(AST.operator == '<=') {
		return left <= right
	} else
	if(AST.operator == '>=') {
		return left >= right
	} else {
		throw new Error(AST.operator + ': Not implemented!')
	}
}


let currentContext

async function runStatement(i, AST, runContext) {
	if(!isStillRunning(runContext)) {
		throw new Error('context ended!')
	}
	try {
		if(AST[i] && AST[i].loc) {
			runContext.bubbleColumn = AST[i].loc.start.column
			if(runContext.bubbleLine != AST[i].loc.start.line) {
				runContext.bubbleLine = AST[i].loc.start.line
				runContext.bubbleAST = AST
				await doStatus(runContext, (!AST[i].callee || AST[i].callee.name != 'sleep'))
			}
		}

		// HOW THE HELL DO I TEST IF A LANGUAGE IMPLEMENTATION IS FEATURE COMPLETE?
		//////////////////////////  PASS-THRU
		if(AST[i].type == 'Literal' || AST[i].type == 'Identifier') {
			return runPrimitive(AST[i], runContext)
		} else 
		if(AST[i].type == 'BlockStatement') {
			return await runBody(AST[i].body, runContext)
		} else
		// TODO: WHAT IS THIS? func(varName = default?)
		if(AST[i].type == 'AssignmentExpression') {
			return await runAssignment(AST[i].left, AST[i].right, runContext)
		} else
		if(AST[i].type == 'BinaryExpression') {
			return await runBinary(AST[i], runContext)
		} else
		// WTF I KEEP MISSING RETURN AWAIT?!!! NEED TO WRITE AN AST IN PROLOG
		//   THEN WRITE PROLOG PARSER IN JAVASCRIPT TO EVALUATE MATCHING AST
		//   TREE FROM ACORN/BISON/ANTLR
		if(AST[i].type == 'ForStatement') {
			return await runLoop(AST[i], runContext)
		} else
		if(AST[i].type == 'UpdateExpression') {
			return runUpdate(AST[i], runContext)
		} else 




		///////////////////////////////// RECURSIVE
		if(AST[i].type == 'ExpressionStatement') {
			return await runStatement(0, [AST[i].expression], runContext)
		} else
		// we are already awaiting for everything
		if(AST[i].type == 'AwaitExpression') {
			return await runStatement(0, [AST[i].argument], runContext)
		} else
		if(AST[i].type == 'ReturnStatement') {
			return await runStatement(0, [AST[i].argument], runContext)
		} else
		if(AST[i].type == 'VariableDeclaration') {
			let result
			// so context doesn't disappear
			for(let j = 0; j < AST[i].declarations.length; j++) {
				result = await runStatement(j, AST[i].declarations, runContext)
				if(!isStillRunning(runContext)) { // bubble up
					return
				}
			}
			return result
		} else
		if(AST[i].type == 'VariableDeclarator') {
			if(typeof runContext.localFunctions[AST[i].id.name] != 'undefined') {
				throw new Error('Function already declared! ' + AST[i].id.name)
			}
			if(!AST[i].id || AST[i].id.type != 'Identifier') {
				throw new Error(AST[i].type + ': Not implemented!')
			}
			// update client with variable informations
			// KEEP THE SAME BEFORE AND AFTER!
			let beforeLine = runContext.bubbleLine - 1
			let bubbleColumn = runContext.bubbleColumn
			// TODO: add late binding, don't eval until it's accessed
			// WOW! IMAGINE THAT! SHOW VARIABLES BEFORE AND AFTER ASSIGNMENT! GOOGLE CHROME DEBUGGER!
			doAssign(AST[i].id.name, beforeLine, bubbleColumn, runContext)
			let result = await runStatement(0, [AST[i].init], runContext)
			// TODO: ^^ intentionally leak here for reporting, global error handling overriding?
			runContext.localVariables[AST[i].id.name] = result
			if(!isStillRunning(runContext)) { // bubble up
				return
			}
			doAssign(AST[i].id.name, beforeLine, bubbleColumn, runContext)
			return result
		} else 


		if(AST[i].type == 'CallExpression' || AST[i].type == 'NewExpression') {
			// collect variables
			
			let params = await runParameters(AST[i].arguments, runContext)
			if(!isStillRunning(runContext)) {
				return // bubble up
			}

			let calleeFunc = await runStatement(0, [AST[i].callee], runContext)
			if(!isStillRunning(runContext)) {
				return // bubble up
			}

			if(calleeFunc) {

			} else
			// TODO: incase libraries aren't sent, preprocessed libs are used here
			if (WEBDRIVER_API[AST[i].callee.name]) {
				calleeFunc = WEBDRIVER_API[AST[i].callee.name]
			} else {
				throw new Error('Function not defined: ' + AST[i].callee.name)
			}
			if(!calleeFunc) {
				debugger
				throw new Error('CallExpression: Not implemented!')
			}

			let beforeLine = runContext.bubbleLine
			try {
				let result;
				currentContext = runContext
				if(AST[i].type == 'NewExpression') {
					if(calleeFunc == _Promise) {
						result = Promise.resolve().then(d => {
							runContext.asyncRunners++
							return d
						}).then(internalResolve).catch(e => {
							runContext.asyncRunners--
							throw e
						}).then(d => {
							runContext.asyncRunners--
							return d
						})
					} else {
						result = await (new calleeFunc(...params))
					}
				} else if (typeof calleeFunc == 'function') {
					result = await calleeFunc.apply(this, params)
				} else {
					throw new Error('Not a function! ' + AST[i].callee.name)
				}

				if(runContext.libraryLines == 0) {
					throw new Error('Library not loaded!')
				}

				// automatically pause for a second on user functions
				//   to allow users to observe the result of the API
				if(AST[i].callee.name != 'sleep'
					&& beforeLine > runContext.libraryLines) {
					console.log('LONG DELAY!!! ' + beforeLine)
					await new Promise(resolve => setTimeout(resolve, DEFAULT_DELAY))
				}
				return result
		
			} catch (e) {
				doError(e, runContext)
			}

		} else
		if(AST[i].type == 'FunctionExpression' 
			|| AST[i].type == 'ArrowFunctionExpression'
			|| AST[i].type == 'FunctionDeclaration') {
			
				let namePrefix = ''
			if(AST[i].type == 'FunctionExpression' 
			|| AST[i].type == 'ArrowFunctionExpression') {
				namePrefix = 'inline '
			}
			if(AST[i].id) {
				// don't add namePrefix!
				if(typeof runContext.localVariables[AST[i].id.name] != 'undefined') {
					throw new Error('Variable already declared! ' + AST[i].id.name)
				}
			} else {
				namePrefix += AST[i].type == 'ArrowFunctionExpression' ? 'lambda ' : 'func '
			}
			let funcName = namePrefix + (AST[i].id ? AST[i].id.name : functionCounter)
			++functionCounter
			let result = (runContext.localFunctions[funcName] 
				= runCall.bind(null, runContext, funcName, AST[i].params, AST[i].body))
			return result

		} else
		if(AST[i].type == 'MemberExpression') {
			if(!AST[i].property) {
				throw new Error('MemberExpression: Not implemented!')
			}
			let property
			if(AST[i].property.type == 'Literal') {
				property = AST[i].property.value
			} else
			if(AST[i].property.type == 'Identifier') {
				property = AST[i].property.name
			} else {
				throw new Error('MemberExpression: Not implemented!')
			}


			let parent = await runStatement(0, [AST[i].object], runContext)
			if(!isStillRunning(runContext)) {
				return // bubble up
			}

			if(typeof parent == 'object' && parent // BUG: null, whoops
				&& typeof parent._accessor != 'undefined') {
				return await parent._accessor(i, AST[i], AST, runContext)
			}

			if(!parent || (!parent.hasOwnProperty(property) && !parent[property])) {
				throw new Error('Member access error: ' + property)
			} else {
				return parent[property]
			}
		} else
		if(AST[i].type == 'ObjectExpression') {
			let newObject = {}
			for(let k = 0; k < AST[i].properties.length; k++) {
				let prop = AST[i].properties[k]
				if(prop.type != 'Property' || prop.key.type != 'Identifier') {
					throw new Error('ObjectExpression: Not implemented!')
				}
				// TODO: add late binding
				newObject[prop.key.name] = await runStatement(0, [prop.value], runContext)
				if(!isStillRunning(runContext)) {
					return
				}
			}
			return newObject
		} else
		if(AST[i].type == 'UnaryExpression') {
			if(AST[i].operator = 'void') {
				return void (await runStatement(0, [AST[i].argument], runContext))
			} else {
				throw new Error(AST[i].type + ': Not implemented!')
			}
		} else 
		if(AST[i].type == 'IfStatement') {
			let result = await runStatement(0, [AST[i].test], runContext)
			if(!isStillRunning(runContext)) {
				return
			}
			if(result) {
				return await runStatement(0, [AST[i].consequent], runContext)
			} else if (AST[i].alternate) {
				return await runStatement(0, [AST[i].alternate], runContext) 
			}
			return result
		}



		{
			debugger
			throw new Error(AST[i].type + ': Not implemented!')
		}

	} catch (e) {
		doError(e, runContext)
		return
	}
}


function runUpdate(AST, runContext) {
	if(!AST.argument || AST.argument.type != 'Identifier') {
		throw new Error(AST.type + ': Not implemented!')
	}
	if(!runContext.localVariables.hasOwnProperty(AST.argument.name)) {
		throw new Error('Identifier not found: ' + AST.argument.name)
	}

	let argVal = runContext.localVariables[AST.argument.name]
	if(AST.operator == '--') {
		if(AST.prefix) {
			argVal = --runContext.localVariables[AST.argument.name]
		} else {
			--runContext.localVariables[AST.argument.name]
		}
	} else
	if(AST.operator == '++') {
		if(AST.prefix) {
			argVal = ++runContext.localVariables[AST.argument.name]
		} else {
			++runContext.localVariables[AST.argument.name]
		}
	} else {
		throw new Error(AST.type + ': Not implemented!')
	}
	let beforeLine = runContext.bubbleLine - 1
	let bubbleColumn = runContext.bubbleColumn
	doAssign(AST.argument.name, beforeLine, bubbleColumn, runContext)
	return argVal

}



async function runLoop(init, test, update, body, runContext) {
	let result
	if(body.type != 'BlockStatement') {
		throw new Error('ForStatement: Not implemented!')
	}
	let initAndTest = await runThisAndThat(init, test, runContext)
	if(!isStillRunning(runContext)) {
		return
	}

	let testResults = initAndTest[1]
	// TODO: turn off safety feature with an attribute @LongLoops
	let safety = 10000
	for(;!testResults && safety > 0; safety--) {
		let thisAndThat = await runThisAndThat(body, update, runContext)
		result = thisAndThat[0]
		if(!isStillRunning(runContext)) {
			return
		}
		testResults = await runStatement(0, [test], runContext)
		if(!isStillRunning(runContext)) {
			return
		}
	}
	// SO I'M NOT A HYPOCRITE LETS PUT SOME REASONABLE BOUNDS!
	if(safety == 0) {
		throw new Error('Long running for loop!')
	}
	return result
}


// DO VARIABLE REASSIGNMENTS
async function runAssignment(left, right, runContext) {
	let beforeLine = runContext.bubbleLine - 1
	let bubbleColumn = runContext.bubbleColumn

	if(left.type == 'Literal') {
	// cannot assign value to primitive type
	throw new Error('Cannot override primitive.')
	}

	if (left.type == 'MemberExpression') {
		let parent = await runStatement(0, [left.object], runContext)
		if(!isStillRunning(runContext)) {
			return
		}

		let property
		if(left.property.type == 'Identifier') {
			property = left.property.name
		} else 
		if(left.property.type == 'Literal') {
			property = left.property.value
		} else {
			throw new Error('AssignmentExpression: Not implemented!')
		}

		// WOW! IMAGINE THAT! SHOW VARIABLES BEFORE AND AFTER ASSIGNMENT! GOOGLE CHROME DEBUGGER!
		doAssign(left.object.name + '.' + property, beforeLine, bubbleColumn, runContext)
		let result = await runStatement(0, [right], runContext)
		// LEAK ASSIGNMENT FOR GLOBAL DEBUGGING?
		if(!isStillRunning(runContext)) {
			return
		}

		// SNOOP ON MODULE EXPORTS
		if(parent === WEBDRIVER_API) {
			runContext.libraryLoaded = true
			runContext.libraryLines = runContext.bubbleLine
			Object.assign(WEBDRIVER_API, result)
		}

		parent[property] = result
		// notify clients
		doAssign(left.object.name + '.' + property, beforeLine, bubbleColumn, runContext)
		return result
	} else 
	// TODO: does expression evaluate even if there assignment error?
	// TODO: how does Chome roll this back? Primitives only?
	
	if(left.type == 'Identifier') {
		if(typeof runContext.localFunctions[left.name] != 'undefined') {
			throw new Error('Cannot override function: ' + left.name)
		} else if (!runContext.localVariables.hasOwnProperty(left.name)) {
			// TODO: LAZY, no var, only let
			throw new Error('Variable not defined: ' + left.name)
		} else {
			// WOW! IMAGINE THAT! SHOW VARIABLES BEFORE AND AFTER ASSIGNMENT! GOOGLE CHROME DEBUGGER!
			doAssign(left.name, beforeLine, bubbleColumn, runContext)
			let result = await runStatement(0, [right], runContext)
			// LEAK ASSIGNMENT FOR GLOBAL DEBUGGING?
			if(!isStillRunning(runContext)) {
				return
			}
			runContext.localVariables[left.name] = result
			doAssign(left.name, beforeLine, bubbleColumn, runContext)
			return result
		}
	} else {
		throw new Error('AssignmentExpression: Not implemented!')
	}
}


// find and run main
async function runBody(AST, runContext) {
	if(!isStillRunning(runContext)) {
		throw new Error('context ended!')
	}

	// restore outer scope when context was created
	//Object.assign(callStack, runContext.localFunctions)
	//Object.assign(callStack, outerContext.localVariables)
	// replace with current context
	//Object.assign(callStack, runContext.localVariables)


	// any time a setTimer is use the callStack will be reset
	//   which means error messaging must intercept here not to
	//   ruin out worker process
	try {
			// doesn't need to be fast, because async DevTools calls, are not fast
		let startFuncs = Object.assign({}, runContext.localFunctions)
		//runContext.localFunctions = 
		let startVars = Object.assign({}, runContext.localVariables)

		let result = await runParameters(AST, runContext)
		if(!isStillRunning(runContext)) {
			return
		}
		// remove anything created in the past context
		//Object.assign(runContext.localFunctions, startFuncs)
		//Object.assign(runContext.localVariables, startVars)
		// TODO: LEAKY SCOPE, this way we keep the same object the whole time
		//runContext.localFunctions = start
		//runContext.localVariables = startVars
		return result.pop()
	} catch (e) {
		doError(e, runContext)
	}
}

function doProperty(value, noRecurse) {
	// TODO: detect runCall symbols on function.AST and call code generation worker


	// LOL! GODDAMNIT GOOGLE, IT'S 2022, YOU CAN'T SHOW US YOUR OWN SOURCE CODE
	//   I MEAN WHEN YOU CLICK ON IT IN THE DEBUGGER OF COURSE, SINCE THIS IS A REPL
	// VISUAL STUDIO DOES THIS! YOU CAN EVEN FIND VISUAL STUDIO SOURCE CODE THROUGH
	//   THE SYMBOL SELECTOR
	if(typeof value == 'function') {
		return (value + '').replace(/\{.*\}/, ' [native code] ')
											 .replace(/|=>.*/, ' [native code] ')
	} else if (typeof value == 'object' && value !== null) {
		let prototypeName = (Object.getPrototypeOf(value).constructor + '')
				.replace(/function?\s*|\(.*$/gi, '')
				|| (Object.getPrototypeOf(value) + '')
				.replace(/^\[object |]$/gi, '')
		if(!noRecurse) {
			// HEY GOOGLE CHROME DEBUGGER, LOOK AT THIS! 1 EXTRA LEVEL OF OBJECT VALUES SO I DON'T
			//   HAVE TO SIT AROUND WAITING FOR THE STUPID IMMEDIATE BUBBLE TO POP UP
			let properties = Object.getOwnPropertyNames(value)
				.reduce((str, prop) => {
					return (str + (str.length ? ', ' : '') + prop + ': ' 
						+ doProperty(value[prop], true) + ' ')
				}, '')
			//let methods = Object.getPrototypeOf(valueString).methods
			return '[' + prototypeName + '] {' + properties + '}'
		} else {
			return '[object ' + prototypeName + ']'
		}
	} else {
		return value + ''
	}
}




function doConsole(tabId, ...args) {
	console.log(args)
	let consoleStrings = args.map(a => doProperty(a)).join ('\n')
	chrome.tabs.sendMessage(tabId, { console: consoleStrings }, function(response) {

	});
}



function doAssign(varName, lineNumber, bubbleColumn, runContext) {
	try {
		let valueString
		if(varName.includes('.')) {
			valueString = doProperty(runContext.localVariables[varName.split('.')[0]][varName.split('.')[1]])
		} else {
			valueString = doProperty(runContext.localVariables[varName])
		}
		chrome.tabs.sendMessage(runContext.senderId, { 
			assign: new Array(bubbleColumn).fill(' ').join('') + varName + ' = ' + valueString + '\n',
			// always subtract 1 because code is wrapping in a 1-line function above
			line: lineNumber,
		}, function(response) {
	
		});
	} catch (e) {
		if(e.message.includes('context invalidated')) {

		} else {
			debugger
		}
	}
}


async function doStatus(runContext, doSleep) {
	try {
		chrome.tabs.sendMessage(runContext.senderId, { 
			status: '.',
			// always subtract 1 because code is wrapping in a 1-line function above
			line: runContext.bubbleLine - 1,
		}, function(response) {
	
		});
		console.log(runContext.bubbleLine)
		// don't sleep on library functions
		if(doSleep
			&& runContext.libraryLoaded 
			&& runContext.bubbleLine > runContext.libraryLines) {
				console.log('DELAYING! ' + runContext.bubbleLine)
			await new Promise(resolve => setTimeout(resolve, DEFAULT_SHORT_DELAY))
		}
	} catch (e) {
		if(e.message.includes('context invalidated')) {

		} else {
			debugger
		}
	}
}

let morpheusPassTime
let temporaryDecrypter
let temporaryEncrypter

async function doMorpheusPass(required) {
	if(!required && temporaryEncrypter
		&& Date.now() - morpheusPassTime < 30 * 1000) {
		return
	}
	// chrome.storage.sync.set({ mytext: txtValue });
	let tryTimes = 15
	let response
	do {
		response = await chrome.tabs.sendMessage(
				sender.tab.id, { accessor: '_enterLogin' })
		if(response) {
			break
		}
	} while(--tryTimes > 0)
	if(!response) {
		throw new Error('Could\'t collect Morpheus password.')
	}
	
	// THIS SHIT IS IMPORTANT. CREATE A FUNCTIONAL CONTEXT
	//   INSTEAD OF LEAVING PASSWORDS LAYING AROUND IN VARIABLES
	//   FOR WINDOW.SOMETHING TO SNOOP ON. 
	// NO WAY TO ACCESS morpheusPass FROM OUTSIDE THIS FUNCTION
	morpheusPassTime = Date.now()
	temporaryDecrypter = (function (morpheusPass) {
		return async function (data) {
			// ask for password again
			if(Date.now() - morpheusPassTime > 30 * 1000) {
				debugger
			}
			return decrypt(morpheusPass, data)
		}
	})(response.pass)
	temporaryEncrypter = (function (morpheusPass) {
		return async function (data) {
			return crypt(morpheusPass, data)
		}
	})(response.pass)
	return response.user
}



async function doMorpheusKey() {
	// chrome.storage.sync.set({ mytext: txtValue });
	let tryTimes = 15
	let response
	do {
		response = await chrome.tabs.sendMessage(
				sender.tab.id, { accessor: '_morpheusKey' })
		if(response) {
			break
		}
	} while(--tryTimes > 0)
	if(!response) {
		throw new Error('Could\'t collect key file.')
	}

	keySettings = {}
	let user = await doMorpheusPass(true)
	keySettings[user] = temporaryEncrypter(response)
	let morphKey = await chrome.storage.sync.get('_morpheusKey')
	if(!morphKey) {
		morphKey = []
	} else {
		morphKey = JSON.parse(morphKey)
	}
	debugger
	morphKey.push(user)
	keySettings.morphKey = JSON.stringify(morphKey)
	await chrome.storage.sync.set(keySettings)
	// OKAY TECHNICAL BULLSHIT, THE GOAL IS TO KEEP PASSWORDS
	//   OUT OF THE HANDS OF OTHER EXTENSIONS, AND POSSIBLE XSS.
	//   I'M ASSUMING THIS PAGE SAYS SOMEWHERE THAT OTHER
	//   EXTENSIONS CAN'T ACCESS OTHER EXTENSIONS SETTINGS?????
	// https://developer.chrome.com/docs/extensions/reference/webRequest/#type-OnBeforeRequestOptions
	// IF I STORE A PRIVATE KEY IN MY EXTENSION FROM GENERATION
	//   THEN PASSWORDS CAN BE ENCRYPTED ON THE CLIENT SIDE WITH
	//   THE PUBLIC KEY AS SOON AS THEY ARE ENTERED AND NEVER TRANSFERED
	//   OUT OF THE CONTEXT OF FILE://MORPHEUS.HTML OR MORPHEUS.GITHUB
	// BUT THIS DOESN'T PREVENT EXTENSIONS FROM READING OTHER WEB PAGE'S
	//   DATA, HENCE THE CLIENT SIDE PUBLIC KEY ENCRPYTION. AN EXTENSION
	//   CAN'T ACCESS STORED PASSWORDS CLIENT SIDE.
	// PASSWORDS ARE ALSO WEAK ENCRYPTED WITH THE MORPHEUS KEY
	//   ENTERED BY THE USER AT THE BEGINNING OF KEY STORAGE
	// WHEN A PASSWORD REQUEST IS MADE, THE TIME ON THE CLIENT PAGE
	//   IF CHECKED FOR EXPIRATION SETTING, THE CLIENT REQUESTS MORPHEUS
	//   KEY AS A SAFETY CHECK
	// MORPHEUS KEY IS WEAK ENCRYPTED WITH A SESSION ID
	//   THE PRE-PUBLIC-KEY ENCRYPTED PASSWORD IS SENT TO THE BACKEND
	// THE BACKEND DECRYPTS THE MORPHEUS-KEY-ENCRYPTED RAW PASSWORD
	//   THE BACKEND SENDS THE MORPHEUS-KEY-ENCRYPTED PASSWORD
	//   AND THE SESSION ENCRYPTED MORPHEUS KEY TO THE CLIENT
	//   WITH THE DECRYPTION PROGRAM, TO EXECUTE THE DECRYPTION
	// PROCESSES IN THE CONTEXT OF THE PAGE, INSIDE A FUNCTION
	//   CONTEXT TO PREVENT VARIABLE LEAKAGE, WITH FORCED GARBAGE COLLECTION
	// THE THEORY BEING THE EXTRA LAYER OF ENCRYPTION WOULD PREVENT ANY
	//   ACCIDENTAL VARIABLE SNOOPING
	// THE SERVER IS NOT AWARE OF THE PAGE SESSION ID USED TO WEAK-ENCRYPT
	//   MORPHEUS-KEY, AND THE FRONT ENDS ARE NOT AWARE OF PASSWORD
	//   STORAGE DUE TO THE BACKEND PRIVATE KEY ENCRYPTION, THERE'S
	//   NO WAY FOR A PAGE OR AN EXTENSION TO SNOOP ON THE PROCESS
	//   RIGHT?????????????????????
	//   ??????????????????????????
	// OTHER STUFF, THE PRIVATE KEY IS WEAK ENCRYPTED WITH THE MORPHEUS
	//   KEY ON THE BACKEND FOR STORAGE.
	// THE USERNAME IS ENCODED WITH STARS AND WEAK ENCRYPTED WITH THE
	//   MORPHEUS KEY ON THE FRONT END AND AUTOMATICALLY SUPPLIED AS
	//   A PART OF A "PROFILE" STYLE UI, PASSWORD ENTERED AS NORMAL
	// USERNAME IS PRETTY MEANINGLESS EXCEPT TO LIST PRIVATE KEYS
	//   FOR SEPARATE PASSWORD PROFILES FOR SCRIPTS TO USE. I.E.
	//   TESTING / DEVELOPMENT / STAGING
	// COLLECTED USERNAMES ARE ENCODED LIKE, ALWAYS 4 STARS REGARDLESS.
	//   bjcullinan@gmail.com -> b****n@g****m
	//   PASSWORDS ARE ENCODED, ALWAYS SHOWING 10 STARS.
	//   *********a, LAST CHARACTER ONLY, TODO: CAN BE TURNED OFF
	// ENCODED DATA IS ENCRYPTYED WITH MORPHEUS KEY
}



let possibleBranches = [
	'left', 'right', 'body', 'params', 'argument',
	'expression', 'init', 'test', 'update', 'object',
	'declarations', 'callee'
]

function doAssignments(AST, runContext) {
	let assignments = {}
	for(let i = 0; i < AST.length; i++) {
		if(!AST[i].loc) {
			continue
		}
		let bubbleColumn = AST[i].loc.start.column
		if(AST[i] == 'AssignmentExpression') {
			let varName
			let valueString
			if(AST[i].left.type == 'Identifier') {
				varName = AST[i].left.name
				valueString = doProperty(runContext.localVariables[varName])
			} else if(AST[i].left.type == 'MemberExpression') {
				varName = AST[i].left.object.name
				let property = AST[i].left.property.name
				valueString = doProperty(runContext.localVariables[varName][property])
				varName += '.' + property
			}
			assignments[AST[i].loc.start.line] = new Array(bubbleColumn)
				.fill(' ').join('') + varName + ' = ' + valueString + '\n'
		} else {
			for(let j = 0; j < possibleBranches.length; ++j) {
				if(typeof AST[i][possibleBranches[j]] != 'undefined') {
					if(typeof AST[i][possibleBranches[j]].type) {
						let childAssigns = doAssignments([AST[i][possibleBranches[j]]], runContext)
						Object.assign(assignments, childAssigns)
					} else if (typeof AST[i][possibleBranches[j]].length != 0
						&& typeof AST[i][possibleBranches[j]][0].type != 'undefined') {
						let childAssigns = doAssignments(AST[i][possibleBranches[j]], runContext)
						Object.assign(assignments, childAssigns)
					} else {
						// don't know what to do
					}
				}
			}
		}
	}
	return assignments
}


function doError(err, runContext) {
	try {
		runContext.ended = true
		console.log('line: ' + (runContext.bubbleLine - 1), err)
		chrome.tabs.sendMessage(runContext.senderId, { 
			error: err.message + '',
			// always subtract 1 because code is wrapping in a 1-line function above
			line: runContext.bubbleLine - 1,
			stack: runContext.bubbleStack,
			// LOOK AT THIS FANCY SHIT GOOGLE CHROME DEBUGGER!
			//   MAKE A LIST OF ASSIGNMENTS NEARBY AND SEND THEIR CURRENT VALUE TO THE FRONTEND
			//   TO SAVE THE DEVELOPER TIME RERUNNING THEIR WHOLE PROGRAM JUST TO SET UP A BREAK
			//   POINT, JUST TO CHECK THE VALUE OF A LOOSELY TYPED VARIABLE. SEE THAT? LOOSE
			//   TYPING WORKS JUST FINE IF YOUR TOOLS SUPPORT YOU INSTEAD OF WORKING AGAINST YOU
			// SEE, IT'S A CATCH22, WHY WOULD I SPIN MY WHEELS FIXING CHROME DEBUGGER'S SOURCE CODE
			//   WHEN THE EXPECTATION IS THAT IF I DON'T LIKE IT, I CAN FIX IT MYSELF. THAT'S WHY
			//   IT SUCKS STILL. THE WHOLE "OPEN SOURCE DOESN'T OWE YOU ANYTHING", IS A SELF 
			//   DEFEATING PRINCINPAL, LIKE IF ALL THE AMERICAN FARMERS DECIDED TO LET PEOPLE STARVE
			//                                         (HUNGRY? FIX THE TRACTOR YOURSELF)
			//   THEY DON'T OWE YOU ANYTHING, NOT EVEN LIFE SUPPORT. FUCK OFF FOSS, FOSS OWES ME
			//   EVERYTHING BECAUSE I'LL BE THE ONE STUCK CLEANING THIS SHIT CODE UP.
			//   TECHNICAL DEBT APPLIES TO PUBLISHING INCORRECT CODE DO. CODE IS LIKE LITTER.
			locals: doAssignments(runContext.bubbleAST),
		}, function(response) {
	
		});
	} catch (e) {
		if(e.message.includes('context invalidated')) {

		} else {
			debugger
		}
	}
}





// WHY DO THIS? Because setTimeout bubbles up, we don't want run context to continue
// THIS WILL HELP WHEN IMPLEMENTING @Before, @After, @Done to see if end action
//  should evaluate yet
function _setTimeout(runContext, callback, msec) {
	runContext.async = true
	runContext.asyncRunners++
	let timerId
	timerId = setTimeout(function () {
		runContext.asyncRunners--
		delete runContext.timers[timerId] // keep track if timer triggers before it's counted
		callback()
	}, msec)
	runContext.timers[timerId] = false // reoccuring
	return timerId
}
function _setInterval(runContext, callback, msec) {
	runContext.async = true
	runContext.asyncRunners++
	let timerId = setInterval(function () {
		callback()
	}, msec)
	runContext.timers[timerId] = true // reoccuring
	return timerId
}
function _clearTimeout(runContext, id) {
	// keep track if timer triggers before it's counted
	if(typeof runContext.timers[id] != 'undefined') {
		runContext.asyncRunners--
		delete runContext.timers[id]
	}
	return clearInterval(id)
}
function _clearInterval(runContext, id) {
	runContext.asyncRunners-- // always subtracts because it was reoccurring
	return clearInterval(id)
}

// ChromeDriver does this inside the browser context, but because
//   Our runner is interpreted we don't need to override browser promise
//   This also prevents ChromeDriver from fucking up out Promise object,
//      in-case javascript is checking for a promise type in the application.
// TODO: _Promise counter to detect when process is off, for async:
function _Promise(runContext, resolve) {

}

async function createEnvironment(sender, runContext) {
	// TODO: this is where we add Chrome security model,
	//    this they decided "IT'S TOO DANGEROUS"
	// A nice design was never explored.
	let thisWindow = {
		_accessor: async function (i, member, AST, ctx, callback) {
			if(!member.object.name || !member.property.name
				|| member.object.name != 'window' /* safety? */) {
				throw new Error('MemberExpression: Not implemented!')
			}
			// TODO: call tree? multiple level? 
			let memberName = member.object.name + '.' + member.property.name
			let response = await chrome.tabs.sendMessage(sender.tab.id, { accessor: memberName })
			if(typeof response.function != 'undefined') {
				debugger
				return function () {
					debugger
				}
			} else if (typeof response.object != 'undefined') {
				// TODO: add an _accessor to Objects?
				debugger
			} else if (typeof response.result != 'undefined') {
				return response.result
			} else if (typeof response.fail != 'undefined') {
				throw new Error('Member access failed: ' + member)
			} else {
				throw new Error('Couldn\'t understand response.')
			}
		},
		// window.screenLeft, window.outerHeight
	}
	let env = {
		thisWindow: thisWindow,
		window: thisWindow,
		tabId: sender.tab.id,
		chrome: {
			tabs: {
				get: chrome.tabs.get
			},
			windows: {
				get: chrome.windows.get,
				create: createWindow,
			}
		},
		module: WEBDRIVER_API,
		console: {
			log: doConsole.bind(console, sender.tab.id)
		},
		// TODO: micro-manage garbage collection?
		Object: Object,
		setTimeout: _setTimeout.bind(null, runContext),
		setInterval: _setInterval.bind(null, runContext),
		Promise: _Promise.bind(null, runContext), // TODO: bind promise to something like chromedriver does
		setWindowBounds: setWindowBounds,
		navigateTo: navigateTo,
		doMorpheusKey: doMorpheusKey,
		clearTimeout: _clearTimeout.bind(null, runContext),
		clearInterval: _clearInterval.bind(null, runContext),
	}
	Object.assign(runContext, {
		timers: {},
		bubbleStack: [],
		bubbleLine: -1,
		bubbleColumn: 0,
		libraryLines: 0,
		libraryLoaded: false,
		localVariables: env,
		localFunctions: {},
		senderId: sender.tab.id,
		asyncRunners: 0,
		async: false,
		ended: false,
		paused: false,
		continue: false, // TODO: implement continuations / long jumps for debugger
		// I think by pushing runStatement(AST[i]) <- i onto a stack and restoring for()?
		// TODO: continuations, check for anonymous functions, variable/function declarations
		// TODO: allow moving cursor to any symbol using address of symbol in AST
	})
}

// ERROR: Refused to evaluate a string as JavaScript because 'unsafe-eval'
// ^- That's where most people give up, but I'll write an interpreter
//let targets = await chrome.debugger.getTargets()
//if(targets.filter(t => t.attached && t.tabId == sender.tab.id).length == 0) {


async function attachDebugger(tabId, initial) {
	try {
		await chrome.debugger.attach({tabId: tabId}, '1.3')
		// confirm it works
		let dom = await chrome.debugger.sendCommand({
			tabId: tabId
		}, 'DOM.getDocument')
		if(dom.root.children[1] && !initial) {
			return
		}
		let running = true
		if(initial) {
			let body = dom.root.children[1].children[1]
			running = !!body.attributes[1].includes('running')
		}
		// doesn't have a root node or is initial and not running
		if(!initial || !running) {
			chrome.tabs.sendMessage(tabId, { 
				warning: 'Tab not running.' 
			}, function(response) {

			});
		}
	} catch (e) {
		if(e.message.includes('Another debugger')) {
			// TODO: attach to another tab!
		} else
		throw new Error('Protocol error: attachDebugger')
	}

}


function createWindow(options) {
	currentContext.navationURL = options.url
	return chrome.windows.create(options)
}


async function setWindowBounds(windowId, tabs, x, y, w, h) {
	try {
		/*
		let targetTabs = await chrome.tabs.query({windowId: windowId})
		if(!targetTabs) {
			throw new Error('Window closed or doesn\'t exist')
		}
		let targetId = targetTabs[0].id
		*/
		let targetId = tabs[0].id
		let targets = (await chrome.debugger.getTargets())
			.filter(t => t.tabId == targetId)
		if(targets[0] && !targets[0].attached) {
			await attachDebugger(targetId)
		}
		if(typeof x != 'undefined' && typeof y != 'undefined') {
			await chrome.windows.update(windowId, {
				left: Math.round(x),
				top: Math.round(y),
			})
		}

		if(typeof w != 'undefined' && typeof h != 'undefined') {
			await chrome.windows.update(windowId, {
				height: Math.round(h),
				width: Math.round(w),
			})
		}
		//let processId = await chrome.processes.getProcessIdForTab(targetId)

		return await chrome.windows.get(windowId)
	} catch (e) {
		debugger
		console.log(e)
		throw new Error('Protocol error: setWindowBounds(...)')
	}
}


async function navigateTo(url, wait) {
	if(!currentContext) {
		throw new Error('Tab context not set.')
	}
	let targetId = currentContext.localVariables.tabId
	let targets = (await chrome.debugger.getTargets())
		.filter(t => t.tabId == targetId)
	if(targets[0] && !targets[0].attached) {
		await attachDebugger(targetId)
	}
	currentContext.navationURL = url
	let dom = await chrome.debugger.sendCommand({
		tabId: targetId
	}, 'Runtime.evaluate', {
//	}, 'Debugger.evaluateOnCallFrame', {
		expression: 'window.location = "' + url + '";'
	})
	// TODO: wait for network to settle, or duck out
	
}

let threads = {

}


// INTERESTING FOR CODE REVEIWS, HABIT OF EXTRACTING DOUBLE NEGATIVES?
function isStillRunning(runContext) {
	if(!runContext.paused && !runContext.ended) {
		return true
	}
	return false
}


// check on runner
function doStatusResponse(request, reply) {
	let runContext = threads[request.runId]
	if(typeof runContext == 'undefined') {
		return
	}
	
	if(runContext.ended) {
		reply({ 
			stopped: '.', 
			line: runContext.bubbleLine - 1
		})
		return
	} else

	if(typeof request.pause != 'undefined') {
		runContext.paused = request.pause
		if(request.pause) {
			reply({ 
				paused: '.', 
				line: runContext.bubbleLine - 1
			})
	
		} else {
				// TODO: continue
				debugger

		}
		return 
	}

	// now every status check will report on current line number also
	reply({ 
		status: '.', 
		line: runContext.bubbleLine - 1
	})
}


chrome.runtime.onMessage.addListener((request, sender, reply) => {
	let AST

	if(!request.script && request.runId) {
		doStatusResponse(request, reply)
		return
	}
	if(!request.script && typeof request.frontend != 'undefined') {
		reply({ stopped: '.' })
		return
	}
	if(!request.script || !request.script.length) {
		reply({ line: -1, error: 'No script!' })
		return
	}

	try {
		console.log('title:', sender.tab.title)
		console.log('url:', sender.tab.url)
		console.log('id:', request.runId)
		console.log('script:', request.script)
		AST = acorn.parse(
			'(function () {\n' + request.script + '\n})()\n'
			, {ecmaVersion: 2020, locations: true, onComment: []})
	} catch (e) {
		// return parser errors right away
		debugger
		console.log(e)
		reply({ error: e.message + '' })
		return
	}


	// TODO: authorization here

	setTimeout(async function () {
		let runContext = {
			body: AST.body,
			script: request.script,
			runId: request.runId,
		}
		try {
			await createEnvironment(sender, runContext)
			threads[request.runId] = runContext
			// attach debugger
			await attachDebugger(sender.tab.id)
			// run code from client
			let result = await runBody(runContext.body, runContext)
			if(!isStillRunning(runContext)) {
				// TODO: send async status?
			} else if (runContext.async) {
				chrome.tabs.sendMessage(sender.tab.id, { async: request.runId }, function(response) {

				});
			} else {
				chrome.tabs.sendMessage(sender.tab.id, { result: result + '' }, function(response) {

				});
			}
						
		} catch (e) {
			doError(e, runContext)
		}

	}, 300)


	reply({ started: request.runId })
})

self.addEventListener('install', function () {
	self.clients.matchAll(/* search options */).then( (clients) => {
		if (clients && clients.length) {
			// you need to decide which clients you want to send the message to..
			const client = clients[0];
			client.postMessage({service: 'Backend service started\n'});
		}
	})
	/*
	if (name === 'BrowserService.prototype.chrome') {
		let current = chrome;
		let command = domain.split('.');
		for (const d of command) {
				current = current[d];
		}
		if (typeof current === 'function') {
				return current.apply(chrome, [...options, (...args) => {
						client.emit.apply(client, [
								'result',
								'BrowserService.prototype.chrome',
								typeof chrome.extension.lastError !== 'undefined'
										? chrome.extension.lastError.message
										: null,
								JSON.stringify(args)]);
				}]);
		}
	}
	*/
})


// TODO: make optional with @attribute
let ALLOW_REDIRECT = true

//chrome.webNavigation.onBeforeNavigate.addListener(function(request, event) {

//})

chrome.webNavigation.onCommitted.addListener(function(details) {
  // IF THE USER DECIDES TO START MESSING AROUND IN THAT WINDOW
  //   PAUSE THE SCRIPT SO WE CAN DEBUG MISSING ELEMENTS!
  // WHY DID NO ONE AT JETBRAINS THINK OF THIS? SWITCHING WINDOWS IS FUN!
	// PAUSE THE SCRIPT!
	let runIds = Object.keys(threads)
	for(let i = 0; i < runIds.length; i++) {
		// check if the local tabId has been set
		if(threads[runIds[i]].localVariables.tabId == details.tabId) {
			// sometimes users type these in wrong and the browser fixes it automatically
			// DON'T USE THIS AS A REASON TO PAUSE FROM INTERFERENCE
			let leftStr = threads[runIds[i]].navationURL.replace(/https|http|\//ig, '')
			let rightStr = details.url.replace(/https|http|\//ig, '')
			if(!leftStr.localeCompare(rightStr)
				|| (ALLOW_REDIRECT 
					&& details.transitionQualifiers.includes('server_redirect'))
			) {
				// WE KNOW THE REQUEST CAME FROM A SCRIPT AND NOT FROM THE USER
				threads[runIds[i]].documentId = details.parentDocumentId || details.documentId
			} else if(details.documentId != threads[runIds[i]].documentId
				&& details.parentDocumentId != threads[runIds[i]].documentId) {
				debugger
				threads[runIds[i]].paused = true
				// ^ more important
				// send a paused status back to the frontend
				chrome.tabs.sendMessage(threads[runIds[i]].senderId, { 
					paused: details.timeStamp
				}, function(response) {

				})
			}
			break
		}
	}
})



let hasKey = false
chrome.storage.sync.get('_morpheusKey', function(data) {
	hasKey = true
  // just kidding, do nothing
})



// SOURCE: https://stackoverflow.com/questions/18279141/javascript-string-encryption-and-decryption

const crypt = (salt, text) => {
  const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
  const byteHex = (n) => ("0" + Number(n).toString(16)).substr(-2);
  const applySaltToChar = (code) => textToChars(salt).reduce((a, b) => a ^ b, code);

  return text
    .split("")
    .map(textToChars)
    .map(applySaltToChar)
    .map(byteHex)
    .join("");
};

const decrypt = (salt, encoded) => {
  const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
  const applySaltToChar = (code) => textToChars(salt).reduce((a, b) => a ^ b, code);
  return encoded
    .match(/.{1,2}/g)
    .map((hex) => parseInt(hex, 16))
    .map(applySaltToChar)
    .map((charCode) => String.fromCharCode(charCode))
    .join("");
};

